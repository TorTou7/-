<?php
/**
 * 任务队列管理类
 * 
 * 功能：
 * 1. 创建下载任务
 * 2. 获取待处理任务
 * 3. 更新任务状态
 * 4. 获取任务统计
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

class TaskQueue {
    private static $instance = null;
    private $db;
    private $conn;
    
    private function __construct() {
        $this->db = Database::getInstance();
        $this->conn = $this->db->getConnection();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 创建下载任务
     * 
     * @param int $videoId 视频ID
     * @param string $videoUrl 视频下载地址
     * @return int 任务ID
     */
    public function createTask($videoId, $videoUrl) {
        try {
            // 检查是否已存在待处理或处理中的任务
            $stmt = $this->conn->prepare("
                SELECT id, status FROM download_tasks 
                WHERE video_id = ? AND status IN ('pending', 'processing')
                LIMIT 1
            ");
            $stmt->execute([$videoId]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existing) {
                // 已存在任务，返回现有任务ID
                return $existing['id'];
            }
            
            // 创建新任务
            $stmt = $this->conn->prepare("
                INSERT INTO download_tasks (video_id, video_url, status, created_at)
                VALUES (?, ?, 'pending', NOW())
            ");
            $stmt->execute([$videoId, $videoUrl]);
            
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            error_log("创建下载任务失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取待处理任务
     * 
     * @param int $limit 获取数量
     * @return array 任务列表
     */
    public function getPendingTasks($limit = 10) {
        try {
            $stmt = $this->conn->prepare("
                SELECT * FROM download_tasks 
                WHERE status = 'pending'
                ORDER BY created_at ASC
                LIMIT :limit
            ");
            $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("获取待处理任务失败: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 获取单个任务
     * 
     * @param int $taskId 任务ID
     * @return array|null 任务信息
     */
    public function getTask($taskId) {
        try {
            $stmt = $this->conn->prepare("
                SELECT * FROM download_tasks WHERE id = ?
            ");
            $stmt->execute([$taskId]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("获取任务失败: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * 更新任务状态
     * 
     * @param int $taskId 任务ID
     * @param string $status 状态
     * @param array $data 额外数据
     * @return bool 是否成功
     */
    public function updateTaskStatus($taskId, $status, $data = []) {
        try {
            $updates = ["status = ?"];
            $params = [$status];
            
            // 处理额外字段
            if (isset($data['progress'])) {
                $updates[] = "progress = ?";
                $params[] = $data['progress'];
            }
            
            if (isset($data['file_size'])) {
                $updates[] = "file_size = ?";
                $params[] = $data['file_size'];
            }
            
            if (isset($data['downloaded_size'])) {
                $updates[] = "downloaded_size = ?";
                $params[] = $data['downloaded_size'];
            }
            
            if (isset($data['error_message'])) {
                $updates[] = "error_message = ?";
                $params[] = $data['error_message'];
            }
            
            if (isset($data['retry_count'])) {
                $updates[] = "retry_count = ?";
                $params[] = $data['retry_count'];
            }
            
            // 如果状态是completed，设置完成时间
            if ($status === 'completed') {
                $updates[] = "completed_at = NOW()";
            }
            
            $params[] = $taskId;
            
            $sql = "UPDATE download_tasks SET " . implode(', ', $updates) . " WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            
            return true;
        } catch (PDOException $e) {
            error_log("更新任务状态失败: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * 获取任务统计
     * 
     * @return array 统计信息
     */
    public function getTaskStats() {
        try {
            $stats = [
                'pending' => 0,
                'processing' => 0,
                'completed' => 0,
                'failed' => 0,
                'total' => 0
            ];
            
            $stmt = $this->conn->query("
                SELECT status, COUNT(*) as count 
                FROM download_tasks 
                GROUP BY status
            ");
            
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $stats[$row['status']] = (int)$row['count'];
                $stats['total'] += (int)$row['count'];
            }
            
            return $stats;
        } catch (PDOException $e) {
            error_log("获取任务统计失败: " . $e->getMessage());
            return [
                'pending' => 0,
                'processing' => 0,
                'completed' => 0,
                'failed' => 0,
                'total' => 0
            ];
        }
    }
    
    /**
     * 清理已完成的旧任务
     * 
     * @param int $days 保留天数
     * @return int 清理数量
     */
    public function cleanOldTasks($days = 7) {
        try {
            $stmt = $this->conn->prepare("
                DELETE FROM download_tasks 
                WHERE status = 'completed' 
                AND completed_at < DATE_SUB(NOW(), INTERVAL ? DAY)
            ");
            $stmt->execute([$days]);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log("清理旧任务失败: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * 重置超时任务
     * 
     * @param int $minutes 超时分钟数
     * @return int 重置数量
     */
    public function resetTimeoutTasks($minutes = 30) {
        try {
            $stmt = $this->conn->prepare("
                UPDATE download_tasks 
                SET status = 'pending', retry_count = retry_count + 1
                WHERE status = 'processing' 
                AND updated_at < DATE_SUB(NOW(), INTERVAL ? MINUTE)
                AND retry_count < 3
            ");
            $stmt->execute([$minutes]);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log("重置超时任务失败: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * 标记超时任务为失败
     * 
     * @param int $minutes 超时分钟数
     * @return int 标记数量
     */
    public function markTimeoutTasksAsFailed($minutes = 30) {
        try {
            $stmt = $this->conn->prepare("
                UPDATE download_tasks 
                SET status = 'failed', 
                    error_message = '任务超时，已达到最大重试次数'
                WHERE status = 'processing' 
                AND updated_at < DATE_SUB(NOW(), INTERVAL ? MINUTE)
                AND retry_count >= 3
            ");
            $stmt->execute([$minutes]);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log("标记超时任务失败: " . $e->getMessage());
            return 0;
        }
    }
}

