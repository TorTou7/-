<?php
/**
 * 后台任务处理器 - Cron版本 V2
 * 
 * 功能：
 * 1. 从任务队列获取待处理任务
 * 2. 使用大文件下载器下载视频
 * 3. 根据存储策略保存视频
 * 4. 更新任务状态和进度
 * 5. 支持大文件下载(5GB+)
 * 6. 进程锁防止重复执行
 * 
 * 使用方式：
 * 通过cron定时执行（每5分钟一次）
 * 每5分钟执行一次: cd /www/wwwroot/Cc.ziyuanqu.com && php task_processor_cron_v2.php
 */

// 设置执行时间限制为30分钟
set_time_limit(1800);
ini_set('max_execution_time', 1800);

// 设置内存限制
ini_set('memory_limit', '512M');

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/task_queue.php';
require_once __DIR__ . '/large_file_downloader.php';
require_once __DIR__ . '/local_storage.php';
require_once __DIR__ . '/r2storage.php';

class TaskProcessorCronV2 {
    private $taskQueue;
    private $db;
    private $downloader;
    private $maxTasks = 1; // 每次只处理1个任务,避免并发问题
    private $logFile;
    private $lockFile;
    private $lockHandle;
    
    public function __construct() {
        $this->taskQueue = TaskQueue::getInstance();
        $this->db = Database::getInstance();
        $this->downloader = new LargeFileDownloader();
        $this->logFile = __DIR__ . '/logs/task_processor.log';
        $this->lockFile = __DIR__ . '/logs/task_processor.lock';
        
        // 确保日志目录存在
        $logDir = dirname($this->logFile);
        if (!file_exists($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        // 设置下载参数 - 针对大文件优化
        $this->downloader->setChunkSize(5 * 1024 * 1024); // 5MB per chunk (更大的chunk)
        $this->downloader->setTimeout(1200); // 20 minutes per chunk (更长的超时)
        $this->downloader->setMaxRetries(5); // 更多重试次数
    }
    
    /**
     * 获取进程锁
     */
    private function acquireLock() {
        $this->lockHandle = fopen($this->lockFile, 'w');
        if (!flock($this->lockHandle, LOCK_EX | LOCK_NB)) {
            $this->log("另一个进程正在运行,退出");
            fclose($this->lockHandle);
            return false;
        }
        return true;
    }
    
    /**
     * 释放进程锁
     */
    private function releaseLock() {
        if ($this->lockHandle) {
            flock($this->lockHandle, LOCK_UN);
            fclose($this->lockHandle);
        }
    }
    
    /**
     * 记录日志
     */
    private function log($message) {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] $message\n";
        file_put_contents($this->logFile, $logMessage, FILE_APPEND);
        echo $logMessage;
    }
    
    /**
     * 运行任务处理器（单次执行）
     */
    public function run() {
        // 尝试获取锁
        if (!$this->acquireLock()) {
            return;
        }
        
        $this->log("任务处理器启动...");
        
        try {
            // 重置超时任务（超过60分钟仍在处理中的任务）
            $reset = $this->taskQueue->resetTimeoutTasks(60);
            if ($reset > 0) {
                $this->log("重置了 $reset 个超时任务");
            }
            
            // 标记超时失败任务（重试次数超过5次的任务）
            $failed = $this->taskQueue->markTimeoutTasksAsFailed(5);
            if ($failed > 0) {
                $this->log("标记了 $failed 个超时失败任务");
            }
            
            // 获取待处理任务
            $tasks = $this->taskQueue->getPendingTasks($this->maxTasks);
            
            if (empty($tasks)) {
                $this->log("无待处理任务");
                $this->releaseLock();
                return;
            }
            
            $this->log("获取到 " . count($tasks) . " 个待处理任务");
            
            // 处理每个任务
            foreach ($tasks as $task) {
                $this->processTask($task);
            }
            
            $this->log("任务处理完成");
            
        } catch (Exception $e) {
            $this->log("处理任务时发生错误: " . $e->getMessage());
        } finally {
            $this->releaseLock();
        }
    }
    
    /**
     * 处理单个任务
     * 
     * @param array $task 任务信息
     */
    private function processTask($task) {
        $taskId = $task['id'];
        $videoId = $task['video_id'];
        $videoUrl = $task['video_url'];
        
        $this->log("开始处理任务 #$taskId (视频 #$videoId)");
        $this->log("视频URL: $videoUrl");
        
        // 更新任务状态为处理中
        $this->taskQueue->updateTaskStatus($taskId, 'processing');
        
        try {
            // 重新获取视频信息，更新URL（因为拖音URL有时效性）
            $this->log("重新获取视频信息...");
            $conn = $this->db->getConnection();
            $stmt = $conn->prepare("SELECT original_url FROM videos WHERE id = ?");
            $stmt->execute([$videoId]);
            $videoInfo = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($videoInfo && !empty($videoInfo['original_url'])) {
                // 使用parseVideo重新解析
                require_once __DIR__ . '/functions.php';
                $parseResult = parseVideo($videoInfo['original_url']);
                
                if ($parseResult['code'] === 0 && !empty($parseResult['data']['video_url'])) {
                    $videoUrl = $parseResult['data']['video_url'];
                    $this->log("获取到新的视频URL");
                    
                    // 更新任务表中的video_url
                    $stmt = $conn->prepare("UPDATE download_tasks SET video_url = ? WHERE id = ?");
                    $stmt->execute([$videoUrl, $taskId]);
                } else {
                    $this->log("警告: 无法重新获取视频URL，使用原有URL");
                }
            }
            
            // 获取存储策略
            $strategy = $this->db->getSetting('storage_strategy') ?? 'none';
            $this->log("存储策略: $strategy");
            
            if ($strategy === 'none') {
                // 不保存策略，直接标记为完成
                $this->taskQueue->updateTaskStatus($taskId, 'completed', [
                    'progress' => 100
                ]);
                $this->log("任务 #$taskId 完成（不保存策略）");
                return;
            }
            
            // 下载视频
            $startTime = microtime(true);
            $result = $this->downloadVideo($taskId, $videoId, $videoUrl, $strategy);
            $duration = microtime(true) - $startTime;
            
            if ($result['success']) {
                // 更新任务状态为完成
                $this->taskQueue->updateTaskStatus($taskId, 'completed', [
                    'progress' => 100,
                    'file_size' => $result['file_size'] ?? 0
                ]);
                
                // 更新视频表的backup_status
                $conn = $this->db->getConnection();
                $stmt = $conn->prepare("UPDATE videos SET backup_status = 'completed' WHERE id = ?");
                $stmt->execute([$videoId]);
                
                $this->log("任务 #$taskId 完成, 耗时: " . number_format($duration, 2) . "秒");
                if (isset($result['file_size'])) {
                    $this->log("文件大小: " . $this->formatBytes($result['file_size']));
                }
            } else {
                // 更新任务状态为失败
                $retryCount = ($task['retry_count'] ?? 0) + 1;
                $this->taskQueue->updateTaskStatus($taskId, 'failed', [
                    'error_message' => $result['error'] ?? '未知错误',
                    'retry_count' => $retryCount
                ]);
                
                // 更新视频表的backup_status
                $conn = $this->db->getConnection();
                $stmt = $conn->prepare("UPDATE videos SET backup_status = 'failed' WHERE id = ?");
                $stmt->execute([$videoId]);
                
                $this->log("任务 #$taskId 失败 (重试次数: $retryCount): " . ($result['error'] ?? '未知错误'));
            }
            
        } catch (Exception $e) {
            // 更新任务状态为失败
            $retryCount = ($task['retry_count'] ?? 0) + 1;
            $this->taskQueue->updateTaskStatus($taskId, 'failed', [
                'error_message' => $e->getMessage(),
                'retry_count' => $retryCount
            ]);
            
            // 更新视频表的backup_status
            $conn = $this->db->getConnection();
            $stmt = $conn->prepare("UPDATE videos SET backup_status = 'failed' WHERE id = ?");
            $stmt->execute([$videoId]);
            
            $this->log("任务 #$taskId 发生异常 (重试次数: $retryCount): " . $e->getMessage());
        }
    }
    
    /**
     * 格式化字节数
     */
    private function formatBytes($bytes) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);
        return round($bytes, 2) . ' ' . $units[$pow];
    }
    
    /**
     * 下载视频
     * 
     * @param int $taskId 任务ID
     * @param int $videoId 视频ID
     * @param string $videoUrl 视频URL
     * @param string $strategy 存储策略
     * @return array 下载结果
     */
    private function downloadVideo($taskId, $videoId, $videoUrl, $strategy) {
        // 进度回调函数
        $progressCallback = function($progress, $downloaded, $total) use ($taskId) {
            $this->taskQueue->updateTaskStatus($taskId, 'processing', [
                'progress' => (int)$progress,
                'downloaded_size' => $downloaded,
                'file_size' => $total
            ]);
            $this->log("任务 #$taskId 进度: " . number_format($progress, 2) . "% (" . $this->formatBytes($downloaded) . " / " . $this->formatBytes($total) . ")");
        };
        
        // 根据策略下载
        if ($strategy === 'local') {
            return $this->downloadToLocal($videoId, $videoUrl, $progressCallback);
        } elseif ($strategy === 'r2') {
            return $this->downloadToR2Only($videoId, $videoUrl, $progressCallback);
        } elseif ($strategy === 'both') {
            return $this->downloadToBoth($videoId, $videoUrl, $progressCallback);
        }
        
        return ['success' => false, 'error' => '未知的存储策略'];
    }
    
    /**
     * 下载到本地
     */
    private function downloadToLocal($videoId, $videoUrl, $progressCallback) {
        try {
            $localStorage = new LocalStorage();
            $result = $localStorage->saveVideo($videoUrl, $videoId, $progressCallback);
            
            if ($result['success']) {
                // 更新数据库中的local_path
                $conn = $this->db->getConnection();
                $stmt = $conn->prepare("UPDATE videos SET local_path = ? WHERE id = ?");
                $stmt->execute([$result['local_path'], $videoId]);
            }
            
            return $result;
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 下载到R2（先下载到临时目录）
     */
    private function downloadToR2Only($videoId, $videoUrl, $progressCallback) {
        try {
            // 先下载到临时目录
            $tempDir = sys_get_temp_dir();
            $tempFile = $tempDir . '/video_' . $videoId . '_' . time() . '.mp4';
            
            $this->log("开始下载到临时文件: $tempFile");
            $result = $this->downloader->download($videoUrl, $tempFile, $progressCallback);
            
            if (!$result['success']) {
                return $result;
            }
            
            $this->log("下载完成,开始上传到R2...");
            
            // 上传到R2
            $r2Storage = new R2Storage();
            $extension = pathinfo($tempFile, PATHINFO_EXTENSION);
            $uploadResult = $r2Storage->uploadVideo($tempFile, $videoId, $extension);
            
            // 删除临时文件
            if (file_exists($tempFile)) {
                unlink($tempFile);
                $this->log("临时文件已删除");
            }
            
            if ($uploadResult['success']) {
                // 更新数据库中的r2_path
                $conn = $this->db->getConnection();
                $stmt = $conn->prepare("UPDATE videos SET r2_path = ? WHERE id = ?");
                $stmt->execute([$uploadResult['r2_path'], $videoId]);
                $this->log("R2上传成功: " . $uploadResult['r2_path']);
            }
            
            return $uploadResult;
        } catch (Exception $e) {
            if (isset($tempFile) && file_exists($tempFile)) {
                unlink($tempFile);
            }
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 下载到本地和R2
     */
    private function downloadToBoth($videoId, $videoUrl, $progressCallback) {
        try {
            // 先下载到本地
            $this->log("开始下载到本地存储...");
            $localStorage = new LocalStorage();
            $localResult = $localStorage->saveVideo($videoUrl, $videoId, $progressCallback);
            
            if (!$localResult['success']) {
                return $localResult;
            }
            
            $this->log("本地下载完成,开始上传到R2...");
            
            // 从本地上传到R2
            $r2Storage = new R2Storage();
            $extension = pathinfo($localResult['local_path'], PATHINFO_EXTENSION);
            
            // 构建完整的本地文件路径
            $localFilePath = $_SERVER['DOCUMENT_ROOT'] . $localResult['local_path'];
            
            $uploadResult = $r2Storage->uploadVideo($localFilePath, $videoId, $extension);
            
            if ($uploadResult['success']) {
                // 更新数据库
                $conn = $this->db->getConnection();
                $stmt = $conn->prepare("UPDATE videos SET local_path = ?, r2_path = ? WHERE id = ?");
                $stmt->execute([$localResult['local_path'], $uploadResult['r2_path'], $videoId]);
                
                $this->log("本地和R2都保存成功");
                
                return [
                    'success' => true,
                    'file_size' => $localResult['file_size'] ?? 0,
                    'local_path' => $localResult['local_path'],
                    'r2_path' => $uploadResult['r2_path']
                ];
            }
            
            // R2上传失败，但本地保存成功
            $conn = $this->db->getConnection();
            $stmt = $conn->prepare("UPDATE videos SET local_path = ? WHERE id = ?");
            $stmt->execute([$localResult['local_path'], $videoId]);
            
            $this->log("本地保存成功,但R2上传失败");
            
            return [
                'success' => true,
                'file_size' => $localResult['file_size'] ?? 0,
                'local_path' => $localResult['local_path'],
                'warning' => 'R2上传失败，仅保存到本地'
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}

// 运行任务处理器
$processor = new TaskProcessorCronV2();
$processor->run();

