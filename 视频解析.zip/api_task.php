<?php
/**
 * 异步任务API接口
 * 
 * 功能：
 * 1. 创建下载任务
 * 2. 查询任务状态
 * 3. 获取任务统计
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/task_queue.php';
require_once __DIR__ . '/csrf.php';

header('Content-Type: application/json; charset=utf-8');

// 处理请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // 验证CSRF Token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        jsonResponse(-1, 'CSRF验证失败');
    }
    
    $taskQueue = TaskQueue::getInstance();
    
    switch ($action) {
        case 'create':
            // 创建下载任务
            $videoId = $_POST['video_id'] ?? 0;
            $videoUrl = $_POST['video_url'] ?? '';
            
            if (!$videoId || !$videoUrl) {
                jsonResponse(-1, '参数错误');
            }
            
            $taskId = $taskQueue->createTask($videoId, $videoUrl);
            
            if ($taskId) {
                jsonResponse(0, '任务创建成功', ['task_id' => $taskId]);
            } else {
                jsonResponse(-1, '任务创建失败');
            }
            break;
            
        case 'status':
            // 查询任务状态
            $taskId = $_POST['task_id'] ?? 0;
            
            if (!$taskId) {
                jsonResponse(-1, '参数错误');
            }
            
            $task = $taskQueue->getTask($taskId);
            
            if ($task) {
                jsonResponse(0, '查询成功', $task);
            } else {
                jsonResponse(-1, '任务不存在');
            }
            break;
            
        case 'stats':
            // 获取任务统计
            $stats = $taskQueue->getTaskStats();
            jsonResponse(0, '查询成功', $stats);
            break;
            
        default:
            jsonResponse(-1, '未知操作');
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    
    $taskQueue = TaskQueue::getInstance();
    
    switch ($action) {
        case 'stats':
            // 获取任务统计（GET方式，用于管理后台）
            $stats = $taskQueue->getTaskStats();
            
            // 获取文件统计
            $db = Database::getInstance();
            $conn = $db->getConnection();
            
            $strategy = $db->getSetting('storage_strategy') ?? 'none';
            
            $fileStats = [
                'local_count' => 0,
                'r2_count' => 0,
                'total_count' => 0
            ];
            
            if ($strategy === 'local' || $strategy === 'both') {
                $stmt = $conn->query("SELECT COUNT(*) FROM videos WHERE local_path IS NOT NULL AND local_path != ''");
                $fileStats['local_count'] = (int)$stmt->fetchColumn();
            }
            
            if ($strategy === 'r2' || $strategy === 'both') {
                $stmt = $conn->query("SELECT COUNT(*) FROM videos WHERE r2_path IS NOT NULL AND r2_path != ''");
                $fileStats['r2_count'] = (int)$stmt->fetchColumn();
            }
            
            if ($strategy === 'both') {
                $fileStats['total_count'] = max($fileStats['local_count'], $fileStats['r2_count']);
            } else {
                $fileStats['total_count'] = $fileStats['local_count'] + $fileStats['r2_count'];
            }
            
            jsonResponse(0, '查询成功', [
                'tasks' => $stats,
                'files' => $fileStats,
                'strategy' => $strategy
            ]);
            break;
            
        default:
            jsonResponse(-1, '未知操作');
    }
} else {
    jsonResponse(-1, '不支持的请求方法');
}

function jsonResponse($code, $message, $data = null) {
    echo json_encode([
        'code' => $code,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

