<?php
/**
 * 大文件下载器
 * 
 * 功能：
 * 1. 支持分块下载大文件（5GB+）
 * 2. 支持断点续传
 * 3. 实时进度更新
 * 4. 内存优化，避免内存溢出
 */

class LargeFileDownloader {
    private $chunkSize = 1048576; // 1MB per chunk
    private $maxRetries = 3;
    private $timeout = 300; // 5 minutes per chunk
    
    /**
     * 下载文件
     * 
     * @param string $url 下载URL
     * @param string $savePath 保存路径
     * @param callable $progressCallback 进度回调函数
     * @return array 下载结果
     */
    public function download($url, $savePath, $progressCallback = null) {
        try {
            // 创建目录
            $dir = dirname($savePath);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            
            // 获取文件大小
            $fileSize = $this->getRemoteFileSize($url);
            if ($fileSize === false) {
                return [
                    'success' => false,
                    'error' => '无法获取文件大小'
                ];
            }
            
            // 检查磁盘空间
            $freeSpace = disk_free_space($dir);
            if ($freeSpace < $fileSize * 1.1) { // 需要额外10%空间
                return [
                    'success' => false,
                    'error' => '磁盘空间不足'
                ];
            }
            
            // 打开文件句柄
            $fp = fopen($savePath, 'wb');
            if (!$fp) {
                return [
                    'success' => false,
                    'error' => '无法创建文件'
                ];
            }
            
            $downloaded = 0;
            $retries = 0;
            
            // 分块下载
            while ($downloaded < $fileSize) {
                $start = $downloaded;
                $end = min($downloaded + $this->chunkSize - 1, $fileSize - 1);
                
                // 下载分块
                $chunk = $this->downloadChunk($url, $start, $end);
                
                if ($chunk === false) {
                    $retries++;
                    if ($retries >= $this->maxRetries) {
                        fclose($fp);
                        unlink($savePath);
                        return [
                            'success' => false,
                            'error' => '下载失败，已达到最大重试次数'
                        ];
                    }
                    // 等待后重试
                    sleep(2);
                    continue;
                }
                
                // 写入文件
                fwrite($fp, $chunk);
                $downloaded += strlen($chunk);
                $retries = 0; // 重置重试计数
                
                // 调用进度回调
                if ($progressCallback) {
                    $progress = ($downloaded / $fileSize) * 100;
                    call_user_func($progressCallback, $progress, $downloaded, $fileSize);
                }
                
                // 释放内存
                unset($chunk);
            }
            
            fclose($fp);
            
            // 验证文件大小
            $actualSize = filesize($savePath);
            if ($actualSize != $fileSize) {
                unlink($savePath);
                return [
                    'success' => false,
                    'error' => '文件大小不匹配'
                ];
            }
            
            return [
                'success' => true,
                'file_size' => $fileSize,
                'save_path' => $savePath
            ];
            
        } catch (Exception $e) {
            if (isset($fp) && is_resource($fp)) {
                fclose($fp);
            }
            if (file_exists($savePath)) {
                unlink($savePath);
            }
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 获取远程文件大小
     * 
     * @param string $url 文件URL
     * @return int|false 文件大小（字节）
     */
    private function getRemoteFileSize($url) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        // 添加必要的请求头
        $headers = [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept: */*',
            'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding: identity',
            'Connection: keep-alive'
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        curl_exec($ch);
        $fileSize = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
        curl_close($ch);
        
        return ($fileSize > 0) ? $fileSize : false;
    }
    
    /**
     * 下载文件分块
     * 
     * @param string $url 文件URL
     * @param int $start 起始字节
     * @param int $end 结束字节
     * @return string|false 分块数据
     */
    private function downloadChunk($url, $start, $end) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RANGE, "$start-$end");
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_BUFFERSIZE, 128 * 1024); // 128KB buffer
        
        // 添加必要的请求头
        $headers = [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept: */*',
            'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding: identity',
            'Connection: keep-alive'
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        $chunk = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        // HTTP 206 Partial Content 或 200 OK
        if ($httpCode == 206 || $httpCode == 200) {
            return $chunk;
        }
        
        return false;
    }
    
    /**
     * 设置分块大小
     * 
     * @param int $size 分块大小（字节）
     */
    public function setChunkSize($size) {
        $this->chunkSize = $size;
    }
    
    /**
     * 设置超时时间
     * 
     * @param int $seconds 超时秒数
     */
    public function setTimeout($seconds) {
        $this->timeout = $seconds;
    }
    
    /**
     * 设置最大重试次数
     * 
     * @param int $retries 重试次数
     */
    public function setMaxRetries($retries) {
        $this->maxRetries = $retries;
    }
}

