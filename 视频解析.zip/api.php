<?php
/**
 * 随机视频API
 * 
 * 功能：返回随机视频的直接链接地址（无样式）
 * 访问后自动跳转到视频地址
 */

require_once 'config.php';
require_once 'database.php';

// 检查是否是专属链接
$customCode = $_GET['code'] ?? '';

try {
    $db = Database::getInstance();
    
    // 如果有自定义代码，从专属链接中随机
    if (!empty($customCode)) {
        $video = getCustomVideo($db->getConnection(), $customCode);
    } else {
        $video = $db->getRandomVideo();
    }
    
    if ($video && $video['url']) {
        // 增加浏览次数
        $db->incrementViews($video['id']);
        
        // 直接跳转到视频地址
        header('Location: ' . $video['url']);
        exit;
    } else {
        // 没有视频，返回错误信息
        header('Content-Type: text/plain; charset=utf-8');
        echo '暂无视频，请先解析视频';
        exit;
    }
} catch (Exception $e) {
    header('Content-Type: text/plain; charset=utf-8');
    echo '错误: ' . $e->getMessage();
    exit;
}

/**
 * 从专属链接中获取随机视频
 */
function getCustomVideo($pdo, $customCode) {
    // 查询专属链接
    $stmt = $pdo->prepare("SELECT video_ids FROM custom_links WHERE custom_code = ?");
    $stmt->execute([$customCode]);
    $link = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$link) {
        throw new Exception('专属链接不存在');
    }
    
    if (empty($link['video_ids'])) {
        throw new Exception('无视频');
    }
    
    // 解析视频ID列表
    $videoIds = array_map('intval', explode(',', $link['video_ids']));
    $videoIds = array_filter($videoIds, function($id) { return $id > 0; });
    
    if (empty($videoIds)) {
        return null;
    }
    
    // 随机选择一个ID
    $randomId = $videoIds[array_rand($videoIds)];
    
    // 查询视频
    $stmt = $pdo->prepare("SELECT * FROM videos WHERE id = ?");
    $stmt->execute([$randomId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

