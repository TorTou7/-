<?php
/**
 * Cloudflare R2 对象存储操作类 (修复版)
 * 
 * 修复了AWS S3签名v4算法的问题
 */

class R2Storage {
    private $endpoint;
    private $accessKeyId;
    private $secretAccessKey;
    private $bucketName;
    private $publicUrl;
    private $basePath;
    private $region = 'auto'; // R2使用auto作为region
    
    public function __construct($endpoint, $accessKeyId, $secretAccessKey, $bucketName, $publicUrl, $basePath = '/') {
        $this->endpoint = rtrim($endpoint, '/');
        $this->accessKeyId = $accessKeyId;
        $this->secretAccessKey = $secretAccessKey;
        $this->bucketName = $bucketName;
        $this->publicUrl = rtrim($publicUrl, '/');
        $this->basePath = $basePath;
    }
    
    public static function fromConfig() {
        require_once 'database.php';
        $db = Database::getInstance();
        
        $endpoint = $db->getSetting('r2_endpoint');
        $accessKeyId = $db->getSetting('r2_access_key_id');
        $secretAccessKey = $db->getSetting('r2_secret_access_key'); // 直接使用，不解密
        $bucketName = $db->getSetting('r2_bucket_name');
        $publicUrl = $db->getSetting('r2_public_url');
        $basePath = $db->getSetting('r2_storage_path') ?? '/';
        
        if (empty($endpoint) || empty($accessKeyId) || empty($secretAccessKey) || empty($bucketName)) {
            throw new Exception('R2 存储未配置');
        }
        
        return new self($endpoint, $accessKeyId, $secretAccessKey, $bucketName, $publicUrl, $basePath);
    }
    
    private function generateDatePath($pathTemplate) {
        $path = str_replace(
            ['{Y}', '{m}', '{d}'],
            [date('Y'), date('m'), date('d')],
            $pathTemplate
        );
        
        if (empty($path) || $path === '/') {
            $path = '';
        }
        
        $path = ltrim($path, '/');
        
        return $path;
    }
    
    /**
     * 保存文件到R2（通用方法）
     * @param string $localPath 本地文件路径
     * @param string $filename 目标文件名
     * @return string R2路径
     */
    public function save($localPath, $filename) {
        if (!file_exists($localPath)) {
            throw new Exception('本地文件不存在: ' . $localPath);
        }
        
        $datePath = $this->generateDatePath($this->basePath);
        $r2Path = $datePath ? "{$datePath}/{$filename}" : $filename;
        
        $fileContent = file_get_contents($localPath);
        $mimeType = $this->getMimeType($localPath);
        
        $url = "{$this->endpoint}/{$this->bucketName}/{$r2Path}";
        $this->sendRequest('PUT', $url, $fileContent, ['Content-Type' => $mimeType]);
        
        return '/' . $r2Path;
    }
    
    public function uploadVideo($localPath, $videoId, $extension = 'mp4') {
        try {
            if (!file_exists($localPath)) {
                throw new Exception('本地文件不存在');
            }
            
            $datePath = $this->generateDatePath($this->basePath);
            $filename = "{$videoId}_" . time() . ".{$extension}";
            $r2Path = $datePath ? "{$datePath}/{$filename}" : $filename;
            
            $fileContent = file_get_contents($localPath);
            $mimeType = $this->getMimeType($localPath);
            
            $url = "{$this->endpoint}/{$this->bucketName}/{$r2Path}";
            $this->sendRequest('PUT', $url, $fileContent, ['Content-Type' => $mimeType]);
            
            $fileSize = filesize($localPath);
            
            return [
                'success' => true,
                'r2_path' => '/' . $r2Path,
                'size' => $fileSize,
                'message' => 'R2上传成功'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'R2上传失败: ' . $e->getMessage()
            ];
        }
    }
    
    public function testConnection() {
        try {
            $url = "{$this->endpoint}/{$this->bucketName}?max-keys=1";
            $response = $this->sendRequest('GET', $url);
            
            return [
                'success' => true,
                'message' => 'R2 连接测试成功'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'R2 连接失败: ' . $e->getMessage()
            ];
        }
    }
    
    public function deleteFile($r2Path) {
        try {
            $r2Path = ltrim($r2Path, '/');
            
            $url = "{$this->endpoint}/{$this->bucketName}/{$r2Path}";
            $this->sendRequest('DELETE', $url);
            
            return [
                'success' => true,
                'message' => '文件删除成功'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 发送HTTP请求 - 修复版AWS S3签名v4
     */
    private function sendRequest($method, $url, $body = '', $headers = []) {
        $parsedUrl = parse_url($url);
        $host = $parsedUrl['host'];
        $path = $parsedUrl['path'];
        $query = isset($parsedUrl['query']) ? $parsedUrl['query'] : '';
        
        // 时间戳
        $datetime = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        
        // Payload hash
        $payloadHash = hash('sha256', $body);
        
        // 构建规范请求
        // 注意：query string需要按字母顺序排序
        $canonicalQueryString = '';
        if ($query) {
            parse_str($query, $params);
            ksort($params);
            $canonicalQueryString = http_build_query($params, '', '&', PHP_QUERY_RFC3986);
        }
        
        // 规范头部（必须按字母顺序排序）
        $canonicalHeaders = "host:{$host}\n";
        $canonicalHeaders .= "x-amz-content-sha256:{$payloadHash}\n";
        $canonicalHeaders .= "x-amz-date:{$datetime}\n";
        
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
        
        // 规范请求
        $canonicalRequest = implode("\n", [
            $method,
            $path,
            $canonicalQueryString,
            $canonicalHeaders,
            $signedHeaders,
            $payloadHash
        ]);
        
        // 构建待签名字符串
        $credentialScope = "{$date}/{$this->region}/s3/aws4_request";
        $stringToSign = implode("\n", [
            'AWS4-HMAC-SHA256',
            $datetime,
            $credentialScope,
            hash('sha256', $canonicalRequest)
        ]);
        
        // 计算签名
        $kDate = hash_hmac('sha256', $date, 'AWS4' . $this->secretAccessKey, true);
        $kRegion = hash_hmac('sha256', $this->region, $kDate, true);
        $kService = hash_hmac('sha256', 's3', $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);
        
        // 构建授权头
        $authorization = "AWS4-HMAC-SHA256 Credential={$this->accessKeyId}/{$credentialScope}, SignedHeaders={$signedHeaders}, Signature={$signature}";
        
        // 发送请求
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        // SSL/TLS 配置
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        
        // 超时设置
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        
        $curlHeaders = [
            "Host: {$host}",
            "x-amz-content-sha256: {$payloadHash}",
            "x-amz-date: {$datetime}",
            "Authorization: {$authorization}"
        ];
        
        // 添加额外的头部
        foreach ($headers as $key => $value) {
            $curlHeaders[] = "{$key}: {$value}";
        }
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, $curlHeaders);
        
        if ($method === 'PUT' || $method === 'POST') {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new Exception("cURL 错误: {$error}");
        }
        
        if ($httpCode >= 400) {
            throw new Exception("HTTP 错误 {$httpCode}: {$response}");
        }
        
        return $response;
    }
    
    private function getMimeType($filePath) {
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        
        $mimeTypes = [
            'mp4' => 'video/mp4',
            'avi' => 'video/x-msvideo',
            'mov' => 'video/quicktime',
            'wmv' => 'video/x-ms-wmv',
            'flv' => 'video/x-flv',
            'webm' => 'video/webm',
            'mkv' => 'video/x-matroska'
        ];
        
        return $mimeTypes[$extension] ?? 'application/octet-stream';
    }
    
    /**
     * 加密密钥
     */
    public static function encryptKey($key) {
        $method = 'AES-256-CBC';
        $ivLength = openssl_cipher_iv_length($method);
        $iv = openssl_random_pseudo_bytes($ivLength);
        $encryptionKey = substr(hash('sha256', 'r2_storage_secret_key_2024'), 0, 32);
        $encrypted = openssl_encrypt($key, $method, $encryptionKey, 0, $iv);
        return base64_encode($iv . $encrypted);
    }
    
    /**
     * 解密密钥
     */
    public static function decryptKey($encryptedKey) {
        if (empty($encryptedKey)) {
            return '';
        }
        
        $method = 'AES-256-CBC';
        $ivLength = openssl_cipher_iv_length($method);
        $encryptionKey = substr(hash('sha256', 'r2_storage_secret_key_2024'), 0, 32);
        
        $data = base64_decode($encryptedKey);
        $iv = substr($data, 0, $ivLength);
        $encrypted = substr($data, $ivLength);
        
        return openssl_decrypt($encrypted, $method, $encryptionKey, 0, $iv);
    }
    
    /**
     * 生成完整的公开访问URL
     */
    public function getPublicUrl($r2Path) {
        $r2Path = ltrim($r2Path, '/');
        return $this->publicUrl . '/' . $r2Path;
    }
}

