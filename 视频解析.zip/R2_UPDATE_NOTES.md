# R2 对象存储功能更新说明

## 版本信息

- **版本号**: V12.0 (R2 集成版)
- **更新日期**: 2025-10-25
- **功能名称**: Cloudflare R2 对象存储集成

---

## 更新内容

### 一、新增文件

#### 核心功能文件 (3个)

1. **r2storage.php** (8.7KB)
   - Cloudflare R2 对象存储操作类
   - 支持文件上传、删除、连接测试
   - 使用 AWS S3 兼容 API
   - 密钥加密存储

2. **video_backup.php** (6.2KB)
   - 视频备份处理类
   - 自动下载视频到临时目录
   - 上传到 R2 存储
   - 更新数据库记录

3. **get_video_url.php** (3.0KB)
   - 智能视频链接获取 API
   - 自动检测原链接有效性
   - 失效时切换到 R2 备份
   - 记录切换日志

#### 数据库更新脚本 (2个)

4. **install/scripts/update_r2_tables.php** (2.2KB)
   - 数据库结构更新脚本
   - 为 videos 表添加 R2 字段
   - 添加 R2 配置项

5. **user/r2_tables.sql** (701B)
   - SQL 更新语句
   - 可手动执行

---

### 二、修改文件

#### 1. database.php
**修改内容:**
- 修改 `saveVideo()` 函数
- 添加 `backup_status` 字段初始化
- 集成自动备份逻辑

**代码变更:**
```php
// 新增: 检查是否启用自动备份
if (file_exists(__DIR__ . '/video_backup.php')) {
    require_once __DIR__ . '/video_backup.php';
    $backup = new VideoBackup();
    
    if ($backup->isAutoBackupEnabled() && $backup->isR2Configured()) {
        $backup->backupVideoAsync($videoId, $videoUrl);
    }
}
```

#### 2. user/pages/admin.php
**修改内容:**
- 添加 "Cloudflare R2 对象存储配置" 区域
- 添加 R2 配置表单(6个配置项)
- 添加 "视频备份管理" 卡片
- 添加测试连接和保存配置功能
- 添加手动备份视频功能

**新增配置项:**
- Account ID
- Access Key ID
- Secret Access Key
- Bucket Name
- Public Domain
- 启用自动备份开关

#### 3. user/api.php
**修改内容:**
- 添加 3 个新 API 接口:
  - `save_r2_config` - 保存 R2 配置
  - `test_r2_connection` - 测试 R2 连接
  - `backup_video` - 手动备份视频

---

### 三、数据库变更

#### videos 表新增字段

| 字段名 | 类型 | 说明 |
|--------|------|------|
| `r2_url` | VARCHAR(500) | R2 存储的视频URL |
| `r2_uploaded_at` | DATETIME | R2 上传时间 |
| `r2_file_size` | BIGINT | R2 文件大小(字节) |
| `backup_status` | ENUM | 备份状态(pending/uploading/completed/failed) |

#### settings 表新增配置

| 配置键 | 说明 |
|--------|------|
| `r2_account_id` | Cloudflare R2 账户ID |
| `r2_access_key_id` | API Token 访问密钥ID |
| `r2_secret_access_key` | API Token 访问密钥(加密) |
| `r2_bucket_name` | 存储桶名称 |
| `r2_public_domain` | 公开访问域名 |
| `r2_auto_backup` | 是否启用自动备份(1/0) |

---

## 升级步骤

### 方法一: 自动升级(推荐)

1. 备份现有代码和数据库
2. 上传新版本文件
3. 访问 `http://your-domain.com/install/scripts/update_r2_tables.php`
4. 等待数据库更新完成
5. 在管理后台配置 R2 存储

### 方法二: 手动升级

1. 备份现有代码和数据库
2. 上传新版本文件
3. 手动执行 SQL:
   ```sql
   ALTER TABLE `videos` 
   ADD COLUMN `r2_url` VARCHAR(500) DEFAULT NULL COMMENT 'R2存储的视频URL',
   ADD COLUMN `r2_uploaded_at` DATETIME DEFAULT NULL COMMENT 'R2上传时间',
   ADD COLUMN `r2_file_size` BIGINT DEFAULT NULL COMMENT 'R2文件大小(字节)',
   ADD COLUMN `backup_status` ENUM('pending', 'uploading', 'completed', 'failed') DEFAULT 'pending' COMMENT '备份状态';
   ```
4. 在管理后台配置 R2 存储

---

## 功能特性

### 1. 自动备份
- 视频解析成功后自动上传到 R2
- 后台开关控制
- 异步处理,不影响用户体验

### 2. 智能链接切换
- 优先使用原始视频链接
- 检测到原链接失效时自动切换到 R2
- 记录切换日志

### 3. 手动备份
- 管理员可手动备份指定视频
- 实时显示备份状态
- 支持重新备份失败的视频

### 4. 安全性
- API 密钥加密存储
- 只有管理员可配置
- 权限严格控制

---

## 兼容性

- ✅ 兼容现有所有功能
- ✅ 不影响未配置 R2 的用户
- ✅ 可选功能,不强制使用
- ✅ 支持新安装和升级安装

---

## 注意事项

1. **PHP 扩展要求**: 需要 `curl` 和 `openssl` 扩展
2. **内存限制**: 建议 PHP 内存限制至少 256MB
3. **超时设置**: 建议 `max_execution_time` 至少 300秒
4. **临时目录**: 系统会使用 `sys_get_temp_dir()` 作为临时目录
5. **日志目录**: 会自动创建 `logs/` 目录存储切换日志

---

## 成本估算

Cloudflare R2 定价:
- 存储: $0.015/GB/月
- 操作: 免费
- 出站流量: 免费

**示例**: 1000个视频(每个50MB) = 50GB = $0.75/月

---

## 技术支持

如遇到问题,请查看:
1. `logs/link_switch.log` - 链接切换日志
2. PHP 错误日志
3. 数据库 `backup_status` 字段

---

**更新完成,祝使用愉快! 🎉**

