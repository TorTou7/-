<?php
/**
 * 视频下载处理
 * 
 * 接收视频URL，下载并返回给用户
 */

require_once 'config.php';

// 获取视频URL
$videoUrl = $_GET['url'] ?? '';

if (empty($videoUrl)) {
    header('Content-Type: text/plain; charset=utf-8');
    echo '错误: 缺少视频URL参数';
    exit;
}

// 验证URL格式
if (!filter_var($videoUrl, FILTER_VALIDATE_URL)) {
    header('Content-Type: text/plain; charset=utf-8');
    echo '错误: 无效的视频URL';
    exit;
}

try {
    // 使用CURL获取视频信息
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $videoUrl,
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        ],
        CURLOPT_HEADERFUNCTION => function($curl, $header) {
            $len = strlen($header);
            $header = explode(':', $header, 2);
            
            if (count($header) < 2) {
                return $len;
            }
            
            $name = strtolower(trim($header[0]));
            $value = trim($header[1]);
            
            // 转发必要的响应头
            if ($name === 'content-type') {
                header('Content-Type: ' . $value);
            } elseif ($name === 'content-length') {
                header('Content-Length: ' . $value);
            }
            
            return $len;
        }
    ]);
    
    // 设置下载文件名
    $filename = 'video_' . time() . '.mp4';
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: no-cache');
    
    // 执行请求并输出
    curl_exec($ch);
    
    $error = curl_error($ch);
    $errno = curl_errno($ch);
    curl_close($ch);
    
    if ($errno !== 0) {
        throw new Exception('下载失败: ' . $error);
    }
    
} catch (Exception $e) {
    header('Content-Type: text/plain; charset=utf-8');
    echo '错误: ' . $e->getMessage();
    exit;
}

