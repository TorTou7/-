<?php
/**
 * 异步任务处理触发器
 * 
 * 功能：在后台异步处理单个任务
 * 调用方式：通过exec()在后台执行
 */

// 禁用输出缓冲
if (ob_get_level()) {
    ob_end_clean();
}

// 关闭连接，让PHP继续在后台运行
ignore_user_abort(true);
set_time_limit(0);

// 设置内存限制
ini_set('memory_limit', '512M');

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/task_queue.php';
require_once __DIR__ . '/large_file_downloader.php';
require_once __DIR__ . '/local_storage.php';
require_once __DIR__ . '/r2storage.php';
require_once __DIR__ . '/functions.php';

// 获取任务ID
$taskId = $argv[1] ?? null;

if (!$taskId) {
    error_log("异步任务处理器: 未提供任务ID");
    exit(1);
}

try {
    $taskQueue = TaskQueue::getInstance();
    $db = Database::getInstance();
    
    // 获取任务信息
    $task = $taskQueue->getTaskById($taskId);
    
    if (!$task) {
        error_log("异步任务处理器: 任务不存在 ID={$taskId}");
        exit(1);
    }
    
    // 检查任务状态
    if ($task['status'] !== 'pending') {
        error_log("异步任务处理器: 任务状态不是pending ID={$taskId} status={$task['status']}");
        exit(0);
    }
    
    // 更新任务状态为processing
    $taskQueue->updateTaskStatus($taskId, 'processing');
    
    $videoId = $task['video_id'];
    
    // 获取视频信息
    $video = $db->getVideoById($videoId);
    
    if (!$video) {
        throw new Exception("视频不存在 ID={$videoId}");
    }
    
    // 获取视频URL
    $videoUrl = $video['video_url'];
    $inputUrl = $video['input_url'];
    
    if (empty($videoUrl)) {
        throw new Exception("视频URL为空");
    }
    
    // 获取存储策略
    $strategy = $db->getSetting('storage_strategy');
    
    if ($strategy === 'none') {
        $taskQueue->updateTaskStatus($taskId, 'completed');
        exit(0);
    }
    
    // 处理本地存储或双重存储
    if ($strategy === 'local' || $strategy === 'both') {
        // 创建本地存储实例
        $localPath = $db->getSetting('local_storage_path');
        $localStorage = new LocalStorage($localPath);
        
        // 生成文件名
        $filename = "video_{$videoId}_" . time() . ".mp4";
        
        // 下载文件
        $downloader = new LargeFileDownloader();
        $tempFile = sys_get_temp_dir() . '/' . $filename;
        
        $result = $downloader->download($videoUrl, $tempFile);
        
        // 如果下载失败，尝试重新解析视频获取新URL
        if (!$result['success'] && !empty($inputUrl)) {
            // 调用API重新解析
            $parseResult = callApi($inputUrl);
            
            if ($parseResult['success'] && !empty($parseResult['data']['url'])) {
                $newVideoUrl = $parseResult['data']['url'];
                
                // 更新数据库中的video_url
                $stmt = $db->getConnection()->prepare("UPDATE videos SET video_url = ? WHERE id = ?");
                $stmt->execute([$newVideoUrl, $videoId]);
                
                // 使用新URL重试下载
                $result = $downloader->download($newVideoUrl, $tempFile);
            }
        }
        
        if (!$result['success']) {
            throw new Exception("下载失败: " . $result['error']);
        }
        
        // 保存到本地存储
        $localResult = $localStorage->save($tempFile, $filename);
        
        if (!$localResult['success']) {
            throw new Exception("本地保存失败: " . $localResult['error']);
        }
        
        // 更新数据库
        $stmt = $db->getConnection()->prepare("UPDATE videos SET local_path = ? WHERE id = ?");
        $stmt->execute([$localResult['path'], $videoId]);
        
        // 删除临时文件
        @unlink($tempFile);
        
        // 如果是双重存储，继续上传到R2
        if ($strategy === 'both') {
            try {
                // 创建R2存储实例
                $endpoint = $db->getSetting('r2_endpoint');
                $accessKeyId = $db->getSetting('r2_access_key_id');
                $secretAccessKey = $db->getSetting('r2_secret_access_key');
                $bucketName = $db->getSetting('r2_bucket_name');
                $publicUrl = $db->getSetting('r2_public_url');
                $r2Path = $db->getSetting('r2_storage_path');
                
                $r2Storage = new R2Storage($endpoint, $accessKeyId, $secretAccessKey, $bucketName, $publicUrl, $r2Path);
                
                // 上传文件
                $fullPath = $_SERVER['DOCUMENT_ROOT'] . $localResult['path'];
                $r2ResultPath = $r2Storage->save($fullPath, $filename);
                
                // 更新数据库
                $stmt = $db->getConnection()->prepare("UPDATE videos SET r2_path = ?, backup_status = 'completed' WHERE id = ?");
                $stmt->execute([$r2ResultPath, $videoId]);
            } catch (Exception $e) {
                // R2上传失败不影响任务完成（本地已保存）
                error_log("异步任务处理器: R2上传失败 ID={$taskId} error={$e->getMessage()}");
                $stmt = $db->getConnection()->prepare("UPDATE videos SET backup_status = 'failed' WHERE id = ?");
                $stmt->execute([$videoId]);
            }
        }
    }
    
    // 标记任务完成
    $taskQueue->updateTaskStatus($taskId, 'completed');
    
} catch (Exception $e) {
    error_log("异步任务处理器: 任务失败 ID={$taskId} error={$e->getMessage()}");
    $taskQueue->updateTaskStatus($taskId, 'failed', $e->getMessage());
    exit(1);
}

