<?php
/**
 * 初始化用户中心数据库表
 */

require_once '../config.php';
require_once '../database.php';

try {
    $db = Database::getInstance()->getConnection();
    
    echo "<h2>开始初始化数据库表...</h2>";
    
    // 1. 为users表添加is_admin字段
    echo "<p>1. 检查users表的is_admin字段...</p>";
    try {
        $db->exec("ALTER TABLE `users` ADD COLUMN `is_admin` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否管理员' AFTER `email`");
        echo "<p style='color: green;'>✓ is_admin字段添加成功</p>";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false) {
            echo "<p style='color: blue;'>✓ is_admin字段已存在</p>";
        } else {
            throw $e;
        }
    }
    
    // 2. 创建user_videos表
    echo "<p>2. 创建user_videos表...</p>";
    $db->exec("CREATE TABLE IF NOT EXISTS `user_videos` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` int(11) NOT NULL COMMENT '用户ID',
      `video_id` int(11) NOT NULL COMMENT '视频ID',
      `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
      PRIMARY KEY (`id`),
      UNIQUE KEY `unique_user_video` (`user_id`, `video_id`),
      KEY `idx_user_id` (`user_id`),
      KEY `idx_video_id` (`video_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户视频关联表'");
    echo "<p style='color: green;'>✓ user_videos表创建成功</p>";
    
    // 3. 创建user_favorites表
    echo "<p>3. 创建user_favorites表...</p>";
    $db->exec("CREATE TABLE IF NOT EXISTS `user_favorites` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` int(11) NOT NULL COMMENT '用户ID',
      `video_id` int(11) NOT NULL COMMENT '视频ID',
      `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
      PRIMARY KEY (`id`),
      UNIQUE KEY `unique_user_favorite` (`user_id`, `video_id`),
      KEY `idx_user_id` (`user_id`),
      KEY `idx_video_id` (`video_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户收藏表'");
    echo "<p style='color: green;'>✓ user_favorites表创建成功</p>";
    
    // 4. 创建custom_links表
    echo "<p>4. 创建custom_links表...</p>";
    $db->exec("CREATE TABLE IF NOT EXISTS `custom_links` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` int(11) NOT NULL COMMENT '用户ID',
      `custom_code` varchar(50) NOT NULL COMMENT '自定义代码',
      `remark` varchar(200) DEFAULT NULL COMMENT '备注说明',
      `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (`id`),
      UNIQUE KEY `unique_custom_code` (`custom_code`),
      KEY `idx_user_id` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='专属定制链接表'");
    echo "<p style='color: green;'>✓ custom_links表创建成功</p>";
    
    // 5. 创建custom_link_videos表
    echo "<p>5. 创建custom_link_videos表...</p>";
    $db->exec("CREATE TABLE IF NOT EXISTS `custom_link_videos` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `link_id` int(11) NOT NULL COMMENT '定制链接ID',
      `video_id` int(11) NOT NULL COMMENT '视频ID',
      `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
      `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
      PRIMARY KEY (`id`),
      UNIQUE KEY `unique_link_video` (`link_id`, `video_id`),
      KEY `idx_link_id` (`link_id`),
      KEY `idx_video_id` (`video_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='定制链接视频关联表'");
    echo "<p style='color: green;'>✓ custom_link_videos表创建成功</p>";
    
    echo "<h2 style='color: green;'>✓ 所有表初始化完成！</h2>";
    echo "<p><a href='/user/'>返回用户中心</a></p>";
    
} catch (Exception $e) {
    echo "<h2 style='color: red;'>✗ 初始化失败</h2>";
    echo "<p style='color: red;'>错误信息: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}
?>

