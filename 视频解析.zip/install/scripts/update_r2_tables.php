<?php
/**
 * 视频存储功能数据库更新脚本
 * 
 * 功能:
 * 1. 在 videos 表中添加本地存储和 R2 相关字段
 * 2. 在 settings 表中添加存储配置项
 */

require_once '../../config.php';
require_once '../../database.php';

try {
    $db = Database::getInstance()->getConnection();
    
    echo "开始更新数据库结构...\n\n";
    
    // 1. 检查并添加 videos 表的本地存储字段
    echo "1. 添加本地存储字段...\n";
    
    $localColumns = [
        'local_url' => "VARCHAR(500) DEFAULT NULL COMMENT '本地存储的视频URL'",
        'local_uploaded_at' => "DATETIME DEFAULT NULL COMMENT '本地上传时间'",
        'local_file_size' => "BIGINT DEFAULT NULL COMMENT '本地文件大小(字节)'"
    ];
    
    foreach ($localColumns as $columnName => $columnDef) {
        $stmt = $db->query("SHOW COLUMNS FROM videos LIKE '{$columnName}'");
        if ($stmt->rowCount() == 0) {
            $sql = "ALTER TABLE videos ADD COLUMN {$columnName} {$columnDef}";
            $db->exec($sql);
            echo "  - 添加字段: {$columnName} ✓\n";
        } else {
            echo "  - 字段已存在: {$columnName} (跳过)\n";
        }
    }
    
    // 2. 检查并添加 videos 表的 R2 字段
    echo "\n2. 添加 R2 存储字段...\n";
    
    $r2Columns = [
        'r2_url' => "VARCHAR(500) DEFAULT NULL COMMENT 'R2存储的视频URL'",
        'r2_uploaded_at' => "DATETIME DEFAULT NULL COMMENT 'R2上传时间'",
        'r2_file_size' => "BIGINT DEFAULT NULL COMMENT 'R2文件大小(字节)'",
        'backup_status' => "ENUM('pending', 'uploading', 'completed', 'failed') DEFAULT 'pending' COMMENT '备份状态'"
    ];
    
    foreach ($r2Columns as $columnName => $columnDef) {
        $stmt = $db->query("SHOW COLUMNS FROM videos LIKE '{$columnName}'");
        if ($stmt->rowCount() == 0) {
            $sql = "ALTER TABLE videos ADD COLUMN {$columnName} {$columnDef}";
            $db->exec($sql);
            echo "  - 添加字段: {$columnName} ✓\n";
        } else {
            echo "  - 字段已存在: {$columnName} (跳过)\n";
        }
    }
    
    // 3. 添加存储配置项到 settings 表
    echo "\n3. 添加存储配置项...\n";
    
    $dbInstance = Database::getInstance();
    $settings = [
        // 存储策略
        'storage_strategy' => 'local',
        // 本地存储配置
        'local_storage_path' => '/uploads/videos',
        'local_storage_url' => '',
        // R2 存储配置
        'r2_account_id' => '',
        'r2_access_key_id' => '',
        'r2_secret_access_key' => '',
        'r2_bucket_name' => '',
        'r2_public_domain' => ''
    ];
    
    foreach ($settings as $key => $defaultValue) {
        $existing = $dbInstance->getSetting($key);
        if ($existing === null) {
            $dbInstance->setSetting($key, $defaultValue);
            echo "  - 添加配置: {$key} = {$defaultValue} ✓\n";
        } else {
            echo "  - 配置已存在: {$key} (跳过)\n";
        }
    }
    
    echo "\n✓ 数据库更新完成！\n";
    echo "\n提示: 请在管理后台配置存储策略和相关参数\n";
    
} catch (Exception $e) {
    echo "\n✗ 错误: " . $e->getMessage() . "\n";
    exit(1);
}

