<?php
/**
 * 数据库更新脚本
 * 添加会员系统相关表
 */

require_once 'config.php';
require_once 'database.php';

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>\n";
echo "<html><head><meta charset='UTF-8'><title>数据库更新</title></head><body>\n";
echo "<h1>数据库更新脚本</h1>\n";
echo "<pre>\n";

try {
    $db = Database::getInstance()->getConnection();
    
    echo "开始更新数据库...\n\n";
    
    // 用户表
    echo "创建 users 表...\n";
    $sql_users = "
        CREATE TABLE IF NOT EXISTS `users` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
            `username` VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
            `email` VARCHAR(100) NOT NULL UNIQUE COMMENT '邮箱',
            `password` VARCHAR(255) NOT NULL COMMENT '密码哈希',
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
            `last_login` DATETIME DEFAULT NULL COMMENT '最后登录时间',
            INDEX `idx_username` (`username`),
            INDEX `idx_email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';
    ";
    $db->exec($sql_users);
    echo "✓ users 表创建成功\n\n";
    
    // 用户视频记录表
    echo "创建 user_videos 表...\n";
    $sql_user_videos = "
        CREATE TABLE IF NOT EXISTS `user_videos` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL COMMENT '用户ID',
            `video_id` INT UNSIGNED NOT NULL COMMENT '视频ID',
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
            UNIQUE KEY `unique_user_video` (`user_id`, `video_id`),
            INDEX `idx_user_id` (`user_id`),
            INDEX `idx_video_id` (`video_id`),
            INDEX `idx_created_at` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户视频记录表';
    ";
    $db->exec($sql_user_videos);
    echo "✓ user_videos 表创建成功\n\n";
    
    // 用户收藏表
    echo "创建 user_favorites 表...\n";
    $sql_favorites = "
        CREATE TABLE IF NOT EXISTS `user_favorites` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL COMMENT '用户ID',
            `video_id` INT UNSIGNED NOT NULL COMMENT '视频ID',
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
            UNIQUE KEY `unique_user_favorite` (`user_id`, `video_id`),
            INDEX `idx_user_id` (`user_id`),
            INDEX `idx_video_id` (`video_id`),
            INDEX `idx_created_at` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户收藏表';
    ";
    $db->exec($sql_favorites);
    echo "✓ user_favorites 表创建成功\n\n";
    
    // 专属链接表
    echo "创建 custom_links 表...\n";
    $sql_custom_links = "
        CREATE TABLE IF NOT EXISTS `custom_links` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT UNSIGNED NOT NULL COMMENT '用户ID',
            `custom_code` VARCHAR(20) NOT NULL UNIQUE COMMENT '自定义代码',
            `remark` VARCHAR(200) DEFAULT NULL COMMENT '备注',
            `video_ids` TEXT DEFAULT NULL COMMENT '视频ID列表，逗号分隔',
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
            `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
            INDEX `idx_user_id` (`user_id`),
            INDEX `idx_custom_code` (`custom_code`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='专属链接表';
    ";
    $db->exec($sql_custom_links);
    echo "✓ custom_links 表创建成功\n\n";
    
    echo "\n========================================\n";
    echo "数据库更新完成！\n";
    echo "========================================\n\n";
    echo "已创建以下表：\n";
    echo "- users (用户表)\n";
    echo "- user_videos (用户视频记录表)\n";
    echo "- user_favorites (用户收藏表)\n";
    echo "- custom_links (专属链接表)\n\n";
    echo "现在可以正常使用会员功能了！\n";
    
} catch (Exception $e) {
    echo "\n❌ 错误: " . $e->getMessage() . "\n";
}

echo "</pre>\n";
echo "<p><a href='/'>返回首页</a> | <a href='/register.php'>注册账户</a></p>\n";
echo "</body></html>\n";

