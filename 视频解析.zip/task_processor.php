<?php
/**
 * 后台任务处理器
 * 
 * 功能：
 * 1. 从任务队列获取待处理任务
 * 2. 使用大文件下载器下载视频
 * 3. 根据存储策略保存视频
 * 4. 更新任务状态和进度
 * 
 * 使用方式：
 * php task_processor.php
 * 或通过cron定时执行
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/task_queue.php';
require_once __DIR__ . '/large_file_downloader.php';
require_once __DIR__ . '/local_storage.php';
require_once __DIR__ . '/r2storage.php';

class TaskProcessor {
    private $taskQueue;
    private $db;
    private $downloader;
    private $maxConcurrent = 3; // 最大并发任务数
    private $sleepTime = 5; // 无任务时休眠秒数
    
    public function __construct() {
        $this->taskQueue = TaskQueue::getInstance();
        $this->db = Database::getInstance();
        $this->downloader = new LargeFileDownloader();
        
        // 设置下载参数
        $this->downloader->setChunkSize(2 * 1024 * 1024); // 2MB per chunk
        $this->downloader->setTimeout(600); // 10 minutes per chunk
        $this->downloader->setMaxRetries(3);
    }
    
    /**
     * 运行任务处理器
     */
    public function run() {
        echo "任务处理器启动...\n";
        
        while (true) {
            try {
                // 重置超时任务
                $reset = $this->taskQueue->resetTimeoutTasks(30);
                if ($reset > 0) {
                    echo "重置了 $reset 个超时任务\n";
                }
                
                // 标记超时失败任务
                $failed = $this->taskQueue->markTimeoutTasksAsFailed(30);
                if ($failed > 0) {
                    echo "标记了 $failed 个超时失败任务\n";
                }
                
                // 获取待处理任务
                $tasks = $this->taskQueue->getPendingTasks($this->maxConcurrent);
                
                if (empty($tasks)) {
                    echo "无待处理任务，休眠 {$this->sleepTime} 秒...\n";
                    sleep($this->sleepTime);
                    continue;
                }
                
                echo "获取到 " . count($tasks) . " 个待处理任务\n";
                
                // 处理每个任务
                foreach ($tasks as $task) {
                    $this->processTask($task);
                }
                
            } catch (Exception $e) {
                echo "处理任务时发生错误: " . $e->getMessage() . "\n";
                sleep($this->sleepTime);
            }
        }
    }
    
    /**
     * 处理单个任务
     * 
     * @param array $task 任务信息
     */
    private function processTask($task) {
        $taskId = $task['id'];
        $videoId = $task['video_id'];
        $videoUrl = $task['video_url'];
        
        echo "开始处理任务 #$taskId (视频 #$videoId)\n";
        
        // 更新任务状态为处理中
        $this->taskQueue->updateTaskStatus($taskId, 'processing');
        
        try {
            // 获取存储策略
            $strategy = $this->db->getSetting('storage_strategy') ?? 'none';
            
            if ($strategy === 'none') {
                // 不保存策略，直接标记为完成
                $this->taskQueue->updateTaskStatus($taskId, 'completed', [
                    'progress' => 100
                ]);
                echo "任务 #$taskId 完成（不保存策略）\n";
                return;
            }
            
            // 下载视频
            $result = $this->downloadVideo($taskId, $videoId, $videoUrl, $strategy);
            
            if ($result['success']) {
                // 更新任务状态为完成
                $this->taskQueue->updateTaskStatus($taskId, 'completed', [
                    'progress' => 100,
                    'file_size' => $result['file_size'] ?? 0
                ]);
                echo "任务 #$taskId 完成\n";
            } else {
                // 更新任务状态为失败
                $this->taskQueue->updateTaskStatus($taskId, 'failed', [
                    'error_message' => $result['error'] ?? '未知错误',
                    'retry_count' => $task['retry_count'] + 1
                ]);
                echo "任务 #$taskId 失败: " . ($result['error'] ?? '未知错误') . "\n";
            }
            
        } catch (Exception $e) {
            // 更新任务状态为失败
            $this->taskQueue->updateTaskStatus($taskId, 'failed', [
                'error_message' => $e->getMessage(),
                'retry_count' => $task['retry_count'] + 1
            ]);
            echo "任务 #$taskId 发生异常: " . $e->getMessage() . "\n";
        }
    }
    
    /**
     * 下载视频
     * 
     * @param int $taskId 任务ID
     * @param int $videoId 视频ID
     * @param string $videoUrl 视频URL
     * @param string $strategy 存储策略
     * @return array 下载结果
     */
    private function downloadVideo($taskId, $videoId, $videoUrl, $strategy) {
        // 进度回调函数
        $progressCallback = function($progress, $downloaded, $total) use ($taskId) {
            $this->taskQueue->updateTaskStatus($taskId, 'processing', [
                'progress' => (int)$progress,
                'downloaded_size' => $downloaded,
                'file_size' => $total
            ]);
            echo "任务 #$taskId 进度: " . number_format($progress, 2) . "% ($downloaded / $total)\n";
        };
        
        // 根据策略下载
        if ($strategy === 'local') {
            return $this->downloadToLocal($videoId, $videoUrl, $progressCallback);
        } elseif ($strategy === 'r2') {
            return $this->downloadToR2Only($videoId, $videoUrl, $progressCallback);
        } elseif ($strategy === 'both') {
            return $this->downloadToBoth($videoId, $videoUrl, $progressCallback);
        }
        
        return ['success' => false, 'error' => '未知的存储策略'];
    }
    
    /**
     * 下载到本地
     */
    private function downloadToLocal($videoId, $videoUrl, $progressCallback) {
        try {
            $localStorage = new LocalStorage();
            $result = $localStorage->saveVideo($videoUrl, $videoId, $progressCallback);
            
            if ($result['success']) {
                // 更新数据库中的local_path
                $conn = $this->db->getConnection();
                $stmt = $conn->prepare("UPDATE videos SET local_path = ? WHERE id = ?");
                $stmt->execute([$result['local_path'], $videoId]);
            }
            
            return $result;
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 下载到R2（先下载到临时目录）
     */
    private function downloadToR2Only($videoId, $videoUrl, $progressCallback) {
        try {
            // 先下载到临时目录
            $tempDir = sys_get_temp_dir();
            $tempFile = $tempDir . '/video_' . $videoId . '_' . time() . '.mp4';
            
            $result = $this->downloader->download($videoUrl, $tempFile, $progressCallback);
            
            if (!$result['success']) {
                return $result;
            }
            
            // 上传到R2
            $r2Storage = new R2Storage();
            $extension = pathinfo($tempFile, PATHINFO_EXTENSION);
            $uploadResult = $r2Storage->uploadVideo($tempFile, $videoId, $extension);
            
            // 删除临时文件
            unlink($tempFile);
            
            if ($uploadResult['success']) {
                // 更新数据库中的r2_path
                $conn = $this->db->getConnection();
                $stmt = $conn->prepare("UPDATE videos SET r2_path = ? WHERE id = ?");
                $stmt->execute([$uploadResult['r2_path'], $videoId]);
            }
            
            return $uploadResult;
        } catch (Exception $e) {
            if (isset($tempFile) && file_exists($tempFile)) {
                unlink($tempFile);
            }
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * 下载到本地和R2
     */
    private function downloadToBoth($videoId, $videoUrl, $progressCallback) {
        try {
            // 先下载到本地
            $localStorage = new LocalStorage();
            $localResult = $localStorage->saveVideo($videoUrl, $videoId, $progressCallback);
            
            if (!$localResult['success']) {
                return $localResult;
            }
            
            // 从本地上传到R2
            $r2Storage = new R2Storage();
            $extension = pathinfo($localResult['local_path'], PATHINFO_EXTENSION);
            
            // 构建完整的本地文件路径
            $localFilePath = $_SERVER['DOCUMENT_ROOT'] . $localResult['local_path'];
            
            $uploadResult = $r2Storage->uploadVideo($localFilePath, $videoId, $extension);
            
            if ($uploadResult['success']) {
                // 更新数据库
                $conn = $this->db->getConnection();
                $stmt = $conn->prepare("UPDATE videos SET local_path = ?, r2_path = ? WHERE id = ?");
                $stmt->execute([$localResult['local_path'], $uploadResult['r2_path'], $videoId]);
                
                return [
                    'success' => true,
                    'file_size' => $localResult['file_size'] ?? 0,
                    'local_path' => $localResult['local_path'],
                    'r2_path' => $uploadResult['r2_path']
                ];
            }
            
            // R2上传失败，但本地保存成功
            $conn = $this->db->getConnection();
            $stmt = $conn->prepare("UPDATE videos SET local_path = ? WHERE id = ?");
            $stmt->execute([$localResult['local_path'], $videoId]);
            
            return [
                'success' => true,
                'file_size' => $localResult['file_size'] ?? 0,
                'local_path' => $localResult['local_path'],
                'warning' => 'R2上传失败，仅保存到本地'
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}

// 如果直接运行此脚本
if (php_sapi_name() === 'cli') {
    $processor = new TaskProcessor();
    $processor->run();
}

