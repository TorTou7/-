<?php
/**
 * 视频详细页面 - article.php
 * 显示视频的详细信息
 */

require_once 'config.php';
require_once 'database.php';
require_once 'functions.php';
require_once 'csrf.php';

// 获取视频ID
$videoId = intval($_GET['id'] ?? 0);

if ($videoId <= 0) {
    header('Location: /');
    exit;
}

// 获取数据库连接
$db = Database::getInstance()->getConnection();

// 先增加浏览次数
$stmt = $db->prepare("UPDATE videos SET views = views + 1 WHERE id = ?");
$stmt->execute([$videoId]);

// 再获取视频信息（包含更新后的浏览次数）
$stmt = $db->prepare("SELECT * FROM videos WHERE id = ?");
$stmt->execute([$videoId]);
$video = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$video) {
    header('Location: /');
    exit;
}

// 获取视频的发布者信息
$stmt = $db->prepare("
    SELECT u.username 
    FROM users u
    INNER JOIN user_videos uv ON u.id = uv.user_id
    WHERE uv.video_id = ?
    LIMIT 1
");
$stmt->execute([$videoId]);
$userInfo = $stmt->fetch(PDO::FETCH_ASSOC);
$publisher = $userInfo ? htmlspecialchars($userInfo['username']) : '未知';

// 检查是否已收藏
$isFavorited = false;
if (isset($_SESSION['user_id'])) {
    $stmt = $db->prepare("
        SELECT id FROM user_favorites 
        WHERE user_id = ? AND video_id = ?
    ");
    $stmt->execute([$_SESSION['user_id'], $videoId]);
    $isFavorited = (bool)$stmt->fetch();
}

// 判断备份状态
$backupStatus = '无';
if (!empty($video['local_path']) && !empty($video['r2_path'])) {
    $backupStatus = '本地/云端';
} elseif (!empty($video['r2_path'])) {
    $backupStatus = '云端(R2)';
} elseif (!empty($video['local_path'])) {
    $backupStatus = '本地';
}

// 生成CSRF Token
$csrfToken = generateCsrfToken();

// 输出HTML
htmlHeader('视频详情');
?>

<div class="header">
    <h1><i class="fas fa-video"></i> <?php echo APP_NAME; ?></h1>
    <p><?php echo SITE_DESCRIPTION; ?></p>
</div>

<?php htmlNav(''); ?>

<div class="content">
    <!-- 使用result-table样式 -->
    <div class="result-table">
        <!-- ID -->
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                ID
            </div>
            <div class="result-value">
                <span><?php echo htmlspecialchars($video['id']); ?></span>
            </div>
        </div>
        
        <!-- 标题 -->
        <?php if (!empty($video['title'])): ?>
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                标题
            </div>
            <div class="result-value">
                <span><?php echo htmlspecialchars($video['title']); ?></span>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- 原址 -->
        <?php if (!empty($video['input_url'])): ?>
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                原址
            </div>
            <div class="result-value">
                <span><?php echo htmlspecialchars($video['input_url']); ?></span>
                <div class="action-buttons">
                    <button class="btn-action" onclick="openPreview('<?php echo htmlspecialchars($video['input_url'], ENT_QUOTES); ?>')">
                        <i class="fas fa-eye"></i> 预览
                    </button>
                    <button class="btn-action" onclick="copyToClipboard('<?php echo htmlspecialchars($video['input_url'], ENT_QUOTES); ?>')">
                        <i class="fas fa-copy"></i> 复制
                    </button>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- 封面 -->
        <?php if (!empty($video['cover'])): ?>
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                封面
            </div>
            <div class="result-value">
                <span><?php echo htmlspecialchars($video['cover']); ?></span>
                <div class="action-buttons">
                    <button class="btn-action" onclick="openPreview('<?php echo htmlspecialchars($video['cover'], ENT_QUOTES); ?>')">
                        <i class="fas fa-eye"></i> 预览
                    </button>
                    <button class="btn-action" onclick="copyToClipboard('<?php echo htmlspecialchars($video['cover'], ENT_QUOTES); ?>')">
                        <i class="fas fa-copy"></i> 复制
                    </button>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- 视频 -->
        <?php if (!empty($video['url'])): ?>
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                视频
            </div>
            <div class="result-value">
                <span><?php echo htmlspecialchars($video['url']); ?></span>
                <div class="action-buttons">
                    <button class="btn-action" onclick="openPreview('<?php echo htmlspecialchars($video['url'], ENT_QUOTES); ?>')">
                        <i class="fas fa-eye"></i> 预览
                    </button>
                    <button class="btn-action" onclick="copyToClipboard('<?php echo htmlspecialchars($video['url'], ENT_QUOTES); ?>')">
                        <i class="fas fa-copy"></i> 复制
                    </button>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- 操作 -->
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                操作
            </div>
            <div class="result-value">
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <?php if (isset($_SESSION['user_id'])): ?>
                    <button class="btn-action <?php echo $isFavorited ? 'btn-favorited' : ''; ?>" id="favoriteBtn" onclick="toggleFavorite()">
                        <i class="fas fa-heart"></i> <span id="favoriteText"><?php echo $isFavorited ? '已收藏' : '收藏'; ?></span>
                    </button>
                    <?php else: ?>
                    <button class="btn-action" onclick="window.location.href='/user/login.php'">
                        <i class="fas fa-sign-in-alt"></i> 登录后收藏
                    </button>
                    <?php endif; ?>
                    
                    <?php if (!empty($video['url'])): ?>
                    <button class="btn-action btn-download" onclick="downloadVideo('<?php echo htmlspecialchars($video['url'], ENT_QUOTES); ?>')">
                        <i class="fas fa-download"></i> 下载视频
                    </button>
                    <?php endif; ?>
                    
                    <button class="btn-action" onclick="refreshVideo(<?php echo $video['id']; ?>)">
                        <i class="fas fa-sync-alt"></i> 重新获取
                    </button>
                </div>
            </div>
        </div>
        
        <!-- 会员 -->
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                会员
            </div>
            <div class="result-value">
                <span><?php echo $publisher; ?></span>
            </div>
        </div>
        
        <!-- 日期 -->
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                日期
            </div>
            <div class="result-value">
                <span><?php echo date('Y-m-d H:i:s', strtotime($video['created_at'])); ?></span>
            </div>
        </div>
        
        <!-- 浏览 -->
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                浏览
            </div>
            <div class="result-value">
                <span><?php echo htmlspecialchars($video['views']); ?> 次</span>
            </div>
        </div>
        
        <!-- 备份 -->
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                备份
            </div>
            <div class="result-value">
                <span style="<?php 
                    if ($backupStatus === '本地/云端') {
                        echo 'color: #27ae60; font-weight: bold;';
                    } elseif ($backupStatus === '云端(R2)') {
                        echo 'color: #3498db; font-weight: bold;';
                    } elseif ($backupStatus === '本地') {
                        echo 'color: #f39c12; font-weight: bold;';
                    } else {
                        echo 'color: #999;';
                    }
                ?>"><?php echo $backupStatus; ?></span>
            </div>
        </div>
    </div>
    
    <!-- 视频播放器 -->
    <?php 
    // 播放优先级：R2 > 本地 > 解析地址
    $videoSrc = '';
    if (!empty($video['r2_path'])) {
        // 优先使用R2链接
        $dbInstance = Database::getInstance();
        $r2PublicUrl = $dbInstance->getSetting('r2_public_url');
        $videoSrc = $r2PublicUrl . $video['r2_path'];
    } elseif (!empty($video['local_path'])) {
        // 其次使用本地链接
        $videoSrc = $video['local_path'];
    } elseif (!empty($video['url'])) {
        // 最后使用解析地址
        $videoSrc = $video['url'];
    }
    ?>
    <?php if ($videoSrc): ?>
    <div class="video-player" style="margin-top: 20px;">
        <video controls style="width: 100%; max-width: 800px; border: 3px solid #333; box-shadow: 6px 6px 0 #333;">
            <source src="<?php echo htmlspecialchars($videoSrc); ?>" type="video/mp4">
            您的浏览器不支持视频播放
        </video>
    </div>
    <?php endif; ?>
    
    <!-- 返回按钮 -->
    <div style="margin-top: 20px;">
        <button class="btn btn-secondary" onclick="window.location.href='/'">
            <i class="fas fa-arrow-left"></i> 返回首页
        </button>
    </div>
</div>

<script>
// 下载视频
function downloadVideo(url) {
    window.location.href = '/download.php?url=' + encodeURIComponent(url);
}

// 打开预览
function openPreview(url) {
    window.open(url, '_blank');
}

// 复制到剪贴板
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showToast('✓ 复制成功！');
    } catch (error) {
        // 备用方案
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('✓ 复制成功！');
    }
}

// 显示提示
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #333; color: #fff; padding: 12px 20px; border-radius: 4px; z-index: 10000; animation: slideIn 0.3s ease;';
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 2000);
}

<?php if (isset($_SESSION['user_id'])): ?>
// 收藏/取消收藏
let isFavorited = <?php echo $isFavorited ? 'true' : 'false'; ?>;

async function toggleFavorite() {
    try {
        const formData = new FormData();
        formData.append('action', isFavorited ? 'unfavorite' : 'favorite');
        formData.append('video_id', <?php echo $videoId; ?>);
        formData.append('csrf_token', '<?php echo $csrfToken; ?>');
        
        const response = await fetch('/user/api.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.code === 0) {
            const btn = document.getElementById('favoriteBtn');
            const text = document.getElementById('favoriteText');
            
            if (isFavorited) {
                btn.classList.remove('btn-favorited');
                text.textContent = '收藏';
                isFavorited = false;
            } else {
                btn.classList.add('btn-favorited');
                text.textContent = '已收藏';
                isFavorited = true;
            }
            
            showToast(data.message || (isFavorited ? '收藏成功' : '取消收藏成功'));
        } else {
            showToast(data.message || '操作失败');
        }
    } catch (error) {
        console.error('收藏操作失败:', error);
        showToast('网络请求失败');
    }
}
<?php endif; ?>

// 重新获取视频数据
async function refreshVideo(id) {
    if (!confirm('确定要重新获取该视频的数据吗？这将消耗一次刷新次数（每天最多3次）。')) {
        return;
    }
    
    showToast('正在刷新...');
    
    try {
        const formData = new FormData();
        formData.append('action', 'refresh');
        formData.append('id', id);
        formData.append('csrf_token', '<?php echo $csrfToken; ?>');
        
        const response = await fetch('/random.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.code === 0) {
            showToast(data.message || '刷新成功');
            // 刷新页面以显示最新数据
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showToast(data.message || '刷新失败');
        }
    } catch (error) {
        console.error('刷新失败:', error);
        showToast('网络请求失败');
    }
}
</script>

<style>
@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOut {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}
</style>

<?php htmlFooter(); ?>

