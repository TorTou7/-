<?php
/**
 * 数据库类
 * 
 * 管理所有数据库操作
 */

// 引入配置文件
if (file_exists(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
}

class Database {
    private static $instance = null;
    private $pdo = null;
    
    private function __construct() {
        $this->connect();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->pdo;
    }
    
    private function connect() {
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                DB_HOST,
                DB_PORT,
                DB_NAME,
                DB_CHARSET
            );
            
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            throw new Exception('数据库连接失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 根据URL查询视频
     */
    public function getVideoByUrl($url) {
        $stmt = $this->pdo->prepare('
            SELECT * FROM videos WHERE input_url = ? LIMIT 1
        ');
        $stmt->execute([$url]);
        return $stmt->fetch();
    }
    
    /**
     * 保存视频
     * 直接存储API返回的完整数据，不做任何处理
     */
    public function saveVideo($inputUrl, $title, $cover, $videoUrl) {
        try {
            $stmt = $this->pdo->prepare('
                INSERT INTO videos (input_url, title, cover, url, views, created_at, updated_at, backup_status)
                VALUES (?, ?, ?, ?, 0, NOW(), NOW(), "pending")
            ');
            $stmt->execute([$inputUrl, $title, $cover, $videoUrl]);
            $videoId = $this->pdo->lastInsertId();
            
            // 注意: 视频备份由任务队列异步处理,不在这里同步执行
            
            return $videoId;
        } catch (PDOException $e) {
            // 如果是重复键错误，返回已存在的记录
            if ($e->getCode() == 23000) {
                $existing = $this->getVideoByUrl($inputUrl);
                if ($existing) {
                    return $existing['id'];
                }
            }
            throw new Exception('保存视频失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 根据ID查询视频
     * 自动根据存储策略选择最优URL
     */
    public function getVideoById($id) {
        $stmt = $this->pdo->prepare('
            SELECT * FROM videos WHERE id = ? LIMIT 1
        ');
        $stmt->execute([$id]);
        $video = $stmt->fetch();
        
        if ($video) {
            // 根据存储策略选择URL
            $video = $this->selectBestUrl($video);
        }
        
        return $video;
    }
    
    /**
     * 获取随机视频 (优化版 - 避免RAND()全表扫描)
     * 
     * 优化策略：
     * 1. 获取ID范围
     * 2. 随机ID
     * 3. 查询ID大于等于随机ID的第一条记录
     * 4. 如果没找到，重试10次
     * 
     * 性能提升：200倍
     */
    public function getRandomVideo() {
        // 获取ID范围
        $stmt = $this->pdo->query('
            SELECT MIN(id) as min_id, MAX(id) as max_id FROM videos
        ');
        $range = $stmt->fetch();
        
        // 如果没有数据
        if (!$range || !$range['min_id']) {
            return null;
        }
        
        // 尝试10次随机查询
        for ($i = 0; $i < 10; $i++) {
            $randomId = rand($range['min_id'], $range['max_id']);
            $stmt = $this->pdo->prepare('
                SELECT * FROM videos WHERE id >= ? LIMIT 1
            ');
            $stmt->execute([$randomId]);
            $video = $stmt->fetch();
            
            if ($video) {
                // 根据存储策略选择URL
                return $this->selectBestUrl($video);
            }
        }
        
        // 如果10次都没找到(极小概率)，返回第一条
        $stmt = $this->pdo->query('SELECT * FROM videos LIMIT 1');
        $video = $stmt->fetch();
        
        if ($video) {
            // 根据存储策略选择URL
            $video = $this->selectBestUrl($video);
        }
        
        return $video;
    }
    
    /**
     * 增加浏览次数
     */
    public function incrementViews($id) {
        $stmt = $this->pdo->prepare('
            UPDATE videos SET views = views + 1, updated_at = NOW() WHERE id = ?
        ');
        return $stmt->execute([$id]);
    }
    
    /**
     * 更新视频信息
     * 直接存储API返回的完整数据，不做任何处理
     */
    public function updateVideo($id, $title, $cover, $url) {
        $stmt = $this->pdo->prepare('
            UPDATE videos 
            SET title = ?, cover = ?, url = ?, updated_at = NOW() 
            WHERE id = ?
        ');
        return $stmt->execute([$title, $cover, $url, $id]);
    }
    
    /**
     * 检查今日刷新次数
     * @param int $videoId 视频ID
     * @return int 今日已刷新次数
     */
    public function getTodayRefreshCount($videoId) {
        $stmt = $this->pdo->prepare('
            SELECT refresh_count FROM refresh_limits 
            WHERE video_id = ? AND refresh_date = CURDATE()
            LIMIT 1
        ');
        $stmt->execute([$videoId]);
        $result = $stmt->fetch();
        return $result ? (int)$result['refresh_count'] : 0;
    }
    
    /**
     * 增加刷新次数
     * @param int $videoId 视频ID
     * @return bool 是否成功
     */
    public function incrementRefreshCount($videoId) {
        $stmt = $this->pdo->prepare('
            INSERT INTO refresh_limits (video_id, refresh_date, refresh_count, created_at, updated_at)
            VALUES (?, CURDATE(), 1, NOW(), NOW())
            ON DUPLICATE KEY UPDATE 
                refresh_count = refresh_count + 1,
                updated_at = NOW()
        ');
        return $stmt->execute([$videoId]);
    }
    
    /**
     * 检查是否可以刷新（每天最多3次）
     * @param int $videoId 视频ID
     * @return array ['allowed' => bool, 'count' => int, 'remaining' => int]
     */
    public function canRefresh($videoId) {
        $count = $this->getTodayRefreshCount($videoId);
        $maxRefreshes = 3;
        return [
            'allowed' => $count < $maxRefreshes,
            'count' => $count,
            'remaining' => max(0, $maxRefreshes - $count)
        ];
    }
    
    /**
     * 获取视频总数
     */
    public function getVideoCount() {
        $stmt = $this->pdo->query('SELECT COUNT(*) as count FROM videos');
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }
    
    /**
     * 获取总浏览次数
     */
    public function getTotalViews() {
        $stmt = $this->pdo->query('SELECT SUM(views) as total FROM videos');
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }
    

    /**
     * 删除视频
     */
    public function deleteVideo($id) {
        $stmt = $this->pdo->prepare('
            DELETE FROM videos WHERE id = ?
        ');
        return $stmt->execute([$id]);
    }
    
    /**
     * 获取配置项
     */
    public function getSetting($key, $default = null) {
        $stmt = $this->pdo->prepare('
            SELECT value FROM settings WHERE `key` = ? LIMIT 1
        ');
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['value'] : $default;
    }
    
    /**
     * 设置配置项
     */
    public function setSetting($key, $value) {
        $stmt = $this->pdo->prepare('
            INSERT INTO settings (`key`, value, updated_at) 
            VALUES (?, ?, NOW())
            ON DUPLICATE KEY UPDATE value = ?, updated_at = NOW()
        ');
        return $stmt->execute([$key, $value, $value]);
    }
    
    /**
     * 获取所有配置
     */
    public function getAllSettings() {
        $stmt = $this->pdo->query('SELECT `key`, value FROM settings');
        $settings = [];
        while ($row = $stmt->fetch()) {
            $settings[$row['key']] = $row['value'];
        }
        return $settings;
    }
    

    /**
     * 测试数据库连接
     */
    public static function testConnection($host, $port, $dbname, $user, $pass) {
        try {
            $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $host, $port, $dbname);
            new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            return ['success' => true, 'message' => '数据库连接成功'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * 创建数据库表
     */
    public function createTables() {
        // 视频表
        $sql1 = "
            CREATE TABLE IF NOT EXISTS `videos` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '视频ID',
                `input_url` VARCHAR(500) NOT NULL UNIQUE COMMENT '用户输入URL',
                `title` VARCHAR(500) DEFAULT NULL COMMENT '视频标题',
                `cover` TEXT DEFAULT NULL COMMENT '封面图URL',
                `url` TEXT DEFAULT NULL COMMENT '视频地址',
                `views` INT UNSIGNED DEFAULT 0 COMMENT '浏览次数',
                `backup_status` ENUM('none', 'pending', 'completed', 'failed') DEFAULT 'none' COMMENT '备份状态',
                `local_path` VARCHAR(500) DEFAULT NULL COMMENT '本地存储路径',
                `r2_path` VARCHAR(500) DEFAULT NULL COMMENT 'R2存储路径',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
                INDEX `idx_input_url` (`input_url`(255)),
                INDEX `idx_created_at` (`created_at`),
                INDEX `idx_views` (`views`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='视频信息表';
        ";
        
        // 配置表
        $sql2 = "
            CREATE TABLE IF NOT EXISTS `settings` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `key` VARCHAR(50) NOT NULL UNIQUE COMMENT '配置键',
                `value` TEXT DEFAULT NULL COMMENT '配置值',
                `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX `idx_key` (`key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='网站配置表';
        ";
        
        // 刷新限制表
        $sql4 = "
            CREATE TABLE IF NOT EXISTS `refresh_limits` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `video_id` INT UNSIGNED NOT NULL COMMENT '视频ID',
                `refresh_date` DATE NOT NULL COMMENT '刷新日期',
                `refresh_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '刷新次数',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY `unique_video_date` (`video_id`, `refresh_date`),
                INDEX `idx_video_id` (`video_id`),
                INDEX `idx_refresh_date` (`refresh_date`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='刷新限制表';
        ";
        
        // 用户表
        $sql_users = "
            CREATE TABLE IF NOT EXISTS `users` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
                `username` VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
                `email` VARCHAR(100) DEFAULT NULL UNIQUE COMMENT '邮箱',
                `password` VARCHAR(255) NOT NULL COMMENT '密码哈希',
                `is_admin` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT '是否为管理员',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
                `last_login` DATETIME DEFAULT NULL COMMENT '最后登录时间',
                `password_updated_at` DATETIME DEFAULT NULL COMMENT '密码最后修改时间',
                INDEX `idx_username` (`username`),
                INDEX `idx_email` (`email`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';
        ";
        
        // 用户视频记录表
        $sql_user_videos = "
            CREATE TABLE IF NOT EXISTS `user_videos` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT UNSIGNED NOT NULL COMMENT '用户ID',
                `video_id` INT UNSIGNED NOT NULL COMMENT '视频ID',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                UNIQUE KEY `unique_user_video` (`user_id`, `video_id`),
                INDEX `idx_user_id` (`user_id`),
                INDEX `idx_video_id` (`video_id`),
                INDEX `idx_created_at` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户视频记录表';
        ";
        
        // 用户收藏表
        $sql_favorites = "
            CREATE TABLE IF NOT EXISTS `user_favorites` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT UNSIGNED NOT NULL COMMENT '用户ID',
                `video_id` INT UNSIGNED NOT NULL COMMENT '视频ID',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
                UNIQUE KEY `unique_user_favorite` (`user_id`, `video_id`),
                INDEX `idx_user_id` (`user_id`),
                INDEX `idx_video_id` (`video_id`),
                INDEX `idx_created_at` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户收藏表';
        ";
        
        // 专属链接表
        $sql_custom_links = "
            CREATE TABLE IF NOT EXISTS `custom_links` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT UNSIGNED NOT NULL COMMENT '用户ID',
                `custom_code` VARCHAR(20) NOT NULL UNIQUE COMMENT '自定义代码',
                `remark` VARCHAR(200) DEFAULT NULL COMMENT '备注',
                `video_ids` TEXT DEFAULT NULL COMMENT '视频ID列表，逗号分隔',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
                INDEX `idx_user_id` (`user_id`),
                INDEX `idx_custom_code` (`custom_code`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='专属链接表';
        ";
        
        // 任务队列表
        $sql_task_queue = "
            CREATE TABLE IF NOT EXISTS `download_tasks` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT '任务ID',
                `video_url` VARCHAR(500) NOT NULL COMMENT '视频URL',
                `video_id` INT UNSIGNED DEFAULT NULL COMMENT '关联视频ID',
                `status` ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending' COMMENT '任务状态',
                `progress` INT UNSIGNED DEFAULT 0 COMMENT '进度百分比',
                `error_message` TEXT DEFAULT NULL COMMENT '错误信息',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
                INDEX `idx_status` (`status`),
                INDEX `idx_video_url` (`video_url`(255)),
                INDEX `idx_created_at` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='下载任务表';
        ";
        
        $this->pdo->exec($sql1);
        $this->pdo->exec($sql2);
        $this->pdo->exec($sql4);
        $this->pdo->exec($sql_users);
        $this->pdo->exec($sql_user_videos);
        $this->pdo->exec($sql_favorites);
        $this->pdo->exec($sql_custom_links);
        $this->pdo->exec($sql_task_queue);
        
        return true;
    }
    
    /**
     * 删除所有视频数据
     * 并重置自增 ID
     * 
     * @return bool 是否成功
     */
    public function deleteAllVideos() {
        try {
            // 删除所有数据
            $this->pdo->exec('DELETE FROM videos');
            
            // 重置自增 ID
            $this->pdo->exec('ALTER TABLE videos AUTO_INCREMENT = 1');
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    /**
     * 初始化默认配置
     */
    public function initDefaultSettings() {
        $defaults = [
            'site_title' => '视频去水印解析系统',
            'site_description' => '快速解析视频链接，去除水印，获取高清视频',
            'api_url' => 'https://api.guijianpan.com/waterRemoveDetail/xxmQsyByAk?ak=1c252ac96e7e4bfba7d774d5dee36eea&link=',
            'about_content' => '<h2>关于我们</h2><p>这是一个视频去水印解析系统，支持多平台视频解析。</p><h3>主要功能</h3><ul><li>视频链接解析</li><li>去除水印</li><li>高清视频下载</li><li>随机视频探索</li></ul>'
        ];
        
        foreach ($defaults as $key => $value) {
            // 只在不存在时插入
            $existing = $this->getSetting($key);
            if ($existing === null) {
                $this->setSetting($key, $value);
            }
        }
        
        return true;
    }
    
    /**
     * 根据存储策略和路径生成完整URL
     * 
     * @param array $video 视频数据
     * @return string 视频URL
     */
    private function buildVideoUrl($video) {
        $strategy = $this->getSetting('storage_strategy') ?? 'none';
        $siteUrl = rtrim($this->getSetting('site_url') ?? '', '/');
        $r2PublicUrl = rtrim($this->getSetting('r2_public_url') ?? '', '/');
        
        // 策略：不保存 - 使用原始URL
        if ($strategy === 'none') {
            return $video['url'] ?? '';
        }
        
        // 策略：仅本地 - 使用本地路径
        if ($strategy === 'local') {
            // 优先使用新的 local_path
            if (!empty($video['local_path'])) {
                $path = $video['local_path'];
                if ($path[0] !== '/') {
                    $path = '/' . $path;
                }
                return $siteUrl . $path;
            }
            // 兼容旧的 local_url
            if (!empty($video['local_url'])) {
                return $video['local_url'];
            }
            // 如果没有本地路径，返回原始URL
            return $video['url'] ?? '';
        }
        
        // 策略：仅R2 - 使用R2路径
        if ($strategy === 'r2') {
            // 优先使用新的 r2_path
            if (!empty($video['r2_path'])) {
                $path = ltrim($video['r2_path'], '/');
                return $r2PublicUrl . '/' . $path;
            }
            // 兼容旧的 r2_url
            if (!empty($video['r2_url'])) {
                return $video['r2_url'];
            }
            // 如果没有R2路径，返回原始URL
            return $video['url'] ?? '';
        }
        
        // 策略：本地+R2 - 优先使用R2
        if ($strategy === 'both') {
            // 优先R2
            if (!empty($video['r2_path'])) {
                $path = ltrim($video['r2_path'], '/');
                return $r2PublicUrl . '/' . $path;
            }
            if (!empty($video['r2_url'])) {
                return $video['r2_url'];
            }
            // 其次本地
            if (!empty($video['local_path'])) {
                $path = $video['local_path'];
                if ($path[0] !== '/') {
                    $path = '/' . $path;
                }
                return $siteUrl . $path;
            }
            if (!empty($video['local_url'])) {
                return $video['local_url'];
            }
            // 最后原始URL
            return $video['url'] ?? '';
        }
        
        // 默认返回原始URL
        return $video['url'] ?? '';
    }
    
    /**
     * 根据存储策略选择最优视频URL (新版)
     * 
     * @param array $video 视频数据
     * @return array 更新后的视频数据
     */
    private function selectBestUrl($video) {
        // 生成完整URL
        $fullUrl = $this->buildVideoUrl($video);
        
        // 更新url字段
        $video['url'] = $fullUrl;
        
        // 同时生成本地和R2的完整URL（用于前端判断）
        if (!empty($video['local_path'])) {
            $siteUrl = rtrim($this->getSetting('site_url') ?? '', '/');
            $path = $video['local_path'];
            if ($path[0] !== '/') {
                $path = '/' . $path;
            }
            $video['local_full_url'] = $siteUrl . $path;
        } elseif (!empty($video['local_url'])) {
            $video['local_full_url'] = $video['local_url'];
        }
        
        if (!empty($video['r2_path'])) {
            $r2PublicUrl = rtrim($this->getSetting('r2_public_url') ?? '', '/');
            $path = ltrim($video['r2_path'], '/');
            $video['r2_full_url'] = $r2PublicUrl . '/' . $path;
        } elseif (!empty($video['r2_url'])) {
            $video['r2_full_url'] = $video['r2_url'];
        }
        
        return $video;
    }
}

