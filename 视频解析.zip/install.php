<?php
/**
 * 安装向导 - 水墨画风格
 * 
 * 功能：
 * 1. 环境检测
 * 2. 数据库配置
 * 3. 创建数据库表
 * 4. 生成安装锁定文件
 * 5. 初始化默认配置
 */

// 如果已安装，跳转到首页
if (file_exists(__DIR__ . '/install.lock')) {
    header('Location: /');
    exit;
}

require_once 'functions.php';

$step = $_GET['step'] ?? 1;
$error = '';
$success = '';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // 测试数据库连接
    if ($action === 'test') {
        $host = $_POST['db_host'] ?? 'localhost';
        $port = $_POST['db_port'] ?? 3306;
        $dbname = $_POST['db_name'] ?? 'ceshi';
        $user = $_POST['db_user'] ?? 'ceshi';
        $pass = $_POST['db_pass'] ?? '123456';
        
        require_once 'database.php';
        $result = Database::testConnection($host, $port, $dbname, $user, $pass);
        
        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }
    
    // 安装
    if ($action === 'install') {
        $host = $_POST['db_host'] ?? 'localhost';
        $port = $_POST['db_port'] ?? 3306;
        $dbname = $_POST['db_name'] ?? 'video_parser';
        $user = $_POST['db_user'] ?? 'root';
        $pass = $_POST['db_pass'] ?? '';
        $apiUrl = $_POST['api_url'] ?? 'https://api.guijianpan.com/waterRemoveDetail/xxmQsyByAk?ak=1c252ac96e7e4bfba7d774d5dee36eea&link=';
        $adminUsername = trim($_POST['admin_username'] ?? 'admin');
        $adminPassword = $_POST['admin_password'] ?? '';
        $adminEmail = trim($_POST['admin_email'] ?? 'admin@example.com');
        
        // 验证管理员信息
        if (empty($adminUsername) || empty($adminPassword)) {
            $error = '请设置管理员账号和密码';
        } else if (strlen($adminPassword) < 6) {
            $error = '管理员密码至少需要6位';
        } else {
        
        try {
            // 测试连接
            require_once 'database.php';
            $testResult = Database::testConnection($host, $port, $dbname, $user, $pass);
            
            if (!$testResult['success']) {
                throw new Exception($testResult['message']);
            }
            
            // 保存配置到install.lock
            $config = [
                'db_host' => $host,
                'db_port' => (int)$port,
                'db_name' => $dbname,
                'db_user' => $user,
                'db_pass' => $pass,
                'api_url' => $apiUrl,
                'install_time' => date('Y-m-d H:i:s')
            ];
            
            file_put_contents(__DIR__ . '/install.lock', json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            
            // 重新加载配置
            define('DB_HOST', $host);
            define('DB_PORT', $port);
            define('DB_NAME', $dbname);
            define('DB_USER', $user);
            define('DB_PASS', $pass);
            define('DB_CHARSET', 'utf8mb4');
            
            // 创建表
            $db = Database::getInstance();
            $db->createTables();
            
            // 初始化默认配置
            $db->initDefaultSettings();
            
            // 创建管理员账户
            $conn = $db->getConnection();
            $hashedPassword = password_hash($adminPassword, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("
                INSERT INTO users (username, email, password, is_admin, created_at, last_login)
                VALUES (?, ?, ?, 1, NOW(), NOW())
            ");
            $stmt->execute([$adminUsername, $adminEmail, $hashedPassword]);

            $success = '安装成功！管理员账户：' . $adminUsername . '，正在跳转...';
            header('Refresh: 3; URL=/');
        } catch (Exception $e) {
            $error = '安装失败: ' . $e->getMessage();
        }
        }
    }
}

// 环境检测
$checks = checkEnvironment();
$allPassed = true;
foreach ($checks as $check) {
    if (!$check['status']) {
        $allPassed = false;
        break;
    }
}

// 应用配置
define('APP_NAME', '视频去水印解析系统');
define('APP_VERSION', '7.5');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>安装向导 - <?php echo APP_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="/assets/install.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-cog"></i> 安装向导</h1>
            <p><?php echo APP_NAME; ?> v<?php echo APP_VERSION; ?></p>
        </div>
        
        <div class="content">
            <!-- 步骤指示器 -->
            <div class="step-indicator">
                <div class="step <?php echo $step == 1 ? 'active' : ''; ?>">
                    <i class="fas fa-check-circle"></i>
                    <span>环境检测</span>
                </div>
                <div class="step <?php echo $step == 2 ? 'active' : ''; ?>">
                    <i class="fas fa-database"></i>
                    <span>数据库配置</span>
                </div>
                <div class="step <?php echo $step == 3 ? 'active' : ''; ?>">
                    <i class="fas fa-check"></i>
                    <span>完成安装</span>
                </div>
            </div>
            
            <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
            </div>
            <?php endif; ?>
            
            <?php if ($step == 1): ?>
            <!-- 步骤1：环境检测 -->
            <h2>环境检测</h2>
            
            <table class="check-table">
                <thead>
                    <tr>
                        <th>检测项</th>
                        <th>要求</th>
                        <th>当前</th>
                        <th>状态</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($checks as $check): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($check['name']); ?></td>
                        <td><?php echo htmlspecialchars($check['required']); ?></td>
                        <td><?php echo htmlspecialchars($check['current']); ?></td>
                        <td>
                            <?php if ($check['status']): ?>
                            <i class="fas fa-check-circle status-icon success"></i>
                            <?php else: ?>
                            <i class="fas fa-times-circle status-icon error"></i>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if (!$allPassed): ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i> 环境检测未通过，请先解决上述问题
            </div>
            <?php endif; ?>
            
            <div class="button-group">
                <a href="?step=2" class="btn btn-primary" <?php echo !$allPassed ? 'style="pointer-events: none; opacity: 0.6;"' : ''; ?>>
                    下一步 <i class="fas fa-arrow-right"></i>
                </a>
            </div>
            
            <?php elseif ($step == 2): ?>
            <!-- 步骤2：数据库配置 -->
            <h2>数据库配置</h2>
            
            <form id="installForm" method="POST" action="">
                <input type="hidden" name="action" value="install">
                
                <div class="form-group">
                    <label class="form-label">数据库主机</label>
                    <input type="text" name="db_host" class="form-input" value="localhost" required>
                    <div class="form-help">通常为 localhost 或 127.0.0.1</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">数据库端口</label>
                    <input type="number" name="db_port" class="form-input" value="3306" required>
                    <div class="form-help">MySQL默认端口为 3306</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">数据库名称</label>
                    <input type="text" name="db_name" class="form-input" value="ceshi" required>
                    <div class="form-help">请确保数据库已创建</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">数据库用户名</label>
                    <input type="text" name="db_user" class="form-input" value="ceshi" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">数据库密码</label>
                    <input type="password" name="db_pass" class="form-input" value="123456">
                    <div class="form-help">如无密码可留空</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">API地址</label>
                    <input type="url" name="api_url" class="form-input" value="https://api.guijianpan.com/waterRemoveDetail/xxmQsyByAk?ak=1c252ac96e7e4bfba7d774d5dee36eea&link=" required>
                    <div class="form-help">视频解析API接口地址</div>
                </div>
                
                <hr style="margin: 30px 0; border: 1px solid var(--border-color);">
                <h3 style="margin-bottom: 20px;">管理员账户配置</h3>
                
                <div class="form-group">
                    <label class="form-label">管理员用户名</label>
                    <input type="text" name="admin_username" class="form-input" value="admin" required>
                    <div class="form-help">管理员登录用户名</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">管理员密码</label>
                    <input type="password" name="admin_password" class="form-input" required minlength="6">
                    <div class="form-help">密码至少需要6位</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">管理员邮箱</label>
                    <input type="email" name="admin_email" class="form-input" value="admin@example.com" required>
                    <div class="form-help">用于接收系统通知</div>
                </div>

                <div class="button-group">
                    <button type="button" class="btn btn-secondary" id="testBtn">
                        <i class="fas fa-vial"></i> 测试连接
                    </button>
                    <button type="submit" class="btn btn-primary" id="installBtn">
                        <i class="fas fa-check"></i> 开始安装
                    </button>
                </div>
            </form>
            
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    // 测试数据库连接
    document.getElementById('testBtn')?.addEventListener('click', async function() {
        const form = document.getElementById('installForm');
        const formData = new FormData(form);
        formData.set('action', 'test');
        
        this.disabled = true;
        this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 测试中...';
        
        try {
            const response = await fetch('', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('✓ ' + result.message);
            } else {
                alert('✗ ' + result.message);
            }
        } catch (error) {
            alert('✗ 测试失败: ' + error.message);
        } finally {
            this.disabled = false;
            this.innerHTML = '<i class="fas fa-vial"></i> 测试连接';
        }
    });
    
    // 安装表单提交
    document.getElementById('installForm')?.addEventListener('submit', function() {
        const installBtn = document.getElementById('installBtn');
        installBtn.disabled = true;
        installBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 安装中...';
    });
    </script>
</body>
</html>

