<?php
/**
 * 配置文件
 * 
 * 存储数据库配置和API配置
 * 安装后会创建 install.lock 文件防止重复安装
 */

// 启动Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 检查是否已安装
define('INSTALL_LOCK', __DIR__ . '/install.lock');
define('IS_INSTALLED', file_exists(INSTALL_LOCK));

// 如果未安装且不是安装页面，跳转到安装页面
if (!IS_INSTALLED && basename($_SERVER['PHP_SELF']) !== 'install.php') {
    header('Location: /install.php');
    exit;
}

// 默认配置
$defaultConfig = [
    'db_host' => 'localhost',
    'db_port' => 3306,
    'db_name' => 'video_parser',
    'db_user' => 'root',
    'db_pass' => '',
    'api_url' => 'https://api.guijianpan.com/waterRemoveDetail/xxmQsyByAk?ak=1c252ac96e7e4bfba7d774d5dee36eea&link=',
    'site_title' => '视频去水印解析系统',
    'site_description' => '快速解析视频链接，去除水印，获取高清视频'
];

// 加载安装配置
if (IS_INSTALLED) {
    $config = json_decode(file_get_contents(INSTALL_LOCK), true);
    if (!is_array($config)) {
        $config = $defaultConfig;
    }
    
    // 数据库配置
    define('DB_HOST', $config['db_host'] ?? $defaultConfig['db_host']);
    define('DB_PORT', $config['db_port'] ?? $defaultConfig['db_port']);
    define('DB_NAME', $config['db_name'] ?? $defaultConfig['db_name']);
    define('DB_USER', $config['db_user'] ?? $defaultConfig['db_user']);
    define('DB_PASS', $config['db_pass'] ?? $defaultConfig['db_pass']);
    define('DB_CHARSET', 'utf8mb4');
    
    // 加载数据库类
    require_once __DIR__ . '/database.php';
    
    // 从数据库读取动态配置
    try {
        $db = Database::getInstance();
        $settings = $db->getAllSettings();
        
        // API配置(优先从数据库读取)
        define('API_URL', $settings['api_url'] ?? $config['api_url'] ?? $defaultConfig['api_url']);
        
        // 网站配置
        define('SITE_TITLE', $settings['site_title'] ?? $config['site_title'] ?? $defaultConfig['site_title']);
        define('SITE_DESCRIPTION', $settings['site_description'] ?? $config['site_description'] ?? $defaultConfig['site_description']);
    } catch (Exception $e) {
        // 数据库连接失败时使用默认配置
        define('API_URL', $config['api_url'] ?? $defaultConfig['api_url']);
        define('SITE_TITLE', $config['site_title'] ?? $defaultConfig['site_title']);
        define('SITE_DESCRIPTION', $config['site_description'] ?? $defaultConfig['site_description']);
    }
} else {
    // 默认配置（用于安装页面）
    define('DB_HOST', $defaultConfig['db_host']);
    define('DB_PORT', $defaultConfig['db_port']);
    define('DB_NAME', $defaultConfig['db_name']);
    define('DB_USER', $defaultConfig['db_user']);
    define('DB_PASS', $defaultConfig['db_pass']);
    define('DB_CHARSET', 'utf8mb4');
    define('API_URL', $defaultConfig['api_url']);
    define('SITE_TITLE', $defaultConfig['site_title']);
    define('SITE_DESCRIPTION', $defaultConfig['site_description']);
}

// 应用配置
define('APP_NAME', SITE_TITLE);
define('APP_VERSION', '10.0'); // 修复收藏按钮+代码优化+清理冗余文件
define('APP_DEBUG', false);
define('APP_TIMEOUT', 20); // 减少超时时间，避免PHP-FPM终止进程

// 时区设置
date_default_timezone_set('Asia/Shanghai');

// 错误报告和日志配置
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/data/php_errors.log');
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/data/php_errors.log');
}

// 会话安全配置
if (session_status() === PHP_SESSION_NONE) {
    // 设置安全的Cookie参数
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
                || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
                || (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
    
    session_set_cookie_params([
        'lifetime' => 7200,  // 2小时
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'] ?? '',
        'secure' => $isHttps,  // 仅HTTPS
        'httponly' => true,  // 防止XSS
        'samesite' => 'Lax'  // 防止CSRF
    ]);
}

