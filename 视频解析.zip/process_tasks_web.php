<?php
/**
 * Web版任务处理器
 * 通过HTTP访问来处理待处理的任务
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300); // 5分钟超时

require_once 'config.php';
require_once 'database.php';
require_once 'task_queue.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $taskQueue = TaskQueue::getInstance();
    $db = Database::getInstance();
    
    // 获取待处理任务
    $pdo = $db->getConnection();
    $stmt = $pdo->query("SELECT * FROM task_queue WHERE status = 'pending' ORDER BY created_at ASC LIMIT 10");
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $results = [];
    $processed = 0;
    $failed = 0;
    
    foreach ($tasks as $task) {
        try {
            $taskId = $task['id'];
            $videoUrl = $task['video_url'];
            
            // 更新任务状态为处理中
            $updateStmt = $pdo->prepare("UPDATE task_queue SET status = 'processing', updated_at = NOW() WHERE id = ?");
            $updateStmt->execute([$taskId]);
            
            // 这里应该调用实际的视频下载和处理逻辑
            // 由于我们现在的存储策略是"不保存",所以直接标记为完成
            $strategy = $db->getSetting('storage_strategy') ?? 'none';
            
            if ($strategy === 'none') {
                // 不需要下载,直接标记为完成
                $updateStmt = $pdo->prepare("UPDATE task_queue SET status = 'completed', updated_at = NOW() WHERE id = ?");
                $updateStmt->execute([$taskId]);
                
                $results[] = [
                    'task_id' => $taskId,
                    'video_url' => $videoUrl,
                    'status' => 'completed',
                    'message' => '存储策略为"不保存",任务已完成'
                ];
                $processed++;
            } else {
                // 需要下载和存储
                // 这里需要实现实际的下载逻辑
                $results[] = [
                    'task_id' => $taskId,
                    'video_url' => $videoUrl,
                    'status' => 'pending',
                    'message' => '需要后台任务处理器处理'
                ];
            }
            
        } catch (Exception $e) {
            $failed++;
            $results[] = [
                'task_id' => $task['id'],
                'video_url' => $task['video_url'],
                'status' => 'failed',
                'error' => $e->getMessage()
            ];
            
            // 更新任务状态为失败
            $updateStmt = $pdo->prepare("UPDATE task_queue SET status = 'failed', error_message = ?, updated_at = NOW() WHERE id = ?");
            $updateStmt->execute([$e->getMessage(), $task['id']]);
        }
    }
    
    echo json_encode([
        'success' => true,
        'total_tasks' => count($tasks),
        'processed' => $processed,
        'failed' => $failed,
        'results' => $results
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

