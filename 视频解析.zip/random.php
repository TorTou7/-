<?php
/**
 * 探索视频页面
 * 
 * 功能：
 * 1. 按ID搜索视频
 * 2. 随机播放视频
 */

require_once 'config.php';
require_once 'database.php';
require_once 'functions.php';
require_once 'csrf.php';

// Session已在config.php中启动,无需重复调用

$db = Database::getInstance();
$video = null;
$searchId = null;

// 处理AJAX请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // 验证CSRF Token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        jsonResponse(-1, 'CSRF验证失败');
    }
    
    $action = $_POST['action'];
    
    if ($action === 'get') {
        $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
        
        if ($id && $id > 0) {
            $video = $db->getVideoById($id);
            if ($video) {
                $db->incrementViews($id);
                
                // 检查是否已收藏
                if (isset($_SESSION['user_id'])) {
                    $dbConn = $db->getConnection();
                    $stmt = $dbConn->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND video_id = ?");
                    $stmt->execute([$_SESSION['user_id'], $id]);
                    $video['is_favorited'] = (bool)$stmt->fetch();
                } else {
                    $video['is_favorited'] = false;
                }
                
                jsonResponse(0, '获取成功', $video);
            } else {
                jsonResponse(-1, '视频不存在');
            }
        } else {
            jsonResponse(-1, 'ID无效');
        }
    } elseif ($action === 'random') {
        $video = $db->getRandomVideo();
        if ($video) {
            $db->incrementViews($video['id']);
            
            // 检查是否已收藏
            if (isset($_SESSION['user_id'])) {
                $dbConn = $db->getConnection();
                $stmt = $dbConn->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND video_id = ?");
                $stmt->execute([$_SESSION['user_id'], $video['id']]);
                $video['is_favorited'] = (bool)$stmt->fetch();
            } else {
                $video['is_favorited'] = false;
            }
            
            jsonResponse(0, '获取成功', $video);
        } else {
            jsonResponse(-1, '暂无视频');
        }
    } elseif ($action === 'refresh') {
        // 重新获取数据（异常处理）
        $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
        
        if ($id && $id > 0) {
            $video = $db->getVideoById($id);
            if ($video) {
                // 检查今日刷新次数（每天最多3次）
                $refreshStatus = $db->canRefresh($id);
                
                if (!$refreshStatus['allowed']) {
                    jsonResponse(-1, '今日刷新次数已用完（' . $refreshStatus['count'] . '/3），请明天再试');
                }
                
                // 调用API重新解析
                require_once 'functions.php';
                $result = callApi($video['input_url']);
                
                if ($result['success']) {
                    // 更新数据库
                    $db->updateVideo(
                        $id,
                        $result['data']['title'],
                        $result['data']['cover'],
                        $result['data']['url']
                    );
                    
                    // 增加刷新次数
                    $db->incrementRefreshCount($id);
                    
                    // 返回更新后的数据
                    $video = $db->getVideoById($id);
                    
                    // 检查是否已收藏
                    if (isset($_SESSION['user_id'])) {
                        $dbConn = $db->getConnection();
                        $stmt = $dbConn->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND video_id = ?");
                        $stmt->execute([$_SESSION['user_id'], $id]);
                        $video['is_favorited'] = (bool)$stmt->fetch();
                    } else {
                        $video['is_favorited'] = false;
                    }
                    
                    $newStatus = $db->canRefresh($id);
                    jsonResponse(0, '刷新成功！今日还可刷新 ' . $newStatus['remaining'] . ' 次', $video);
                } else {
                    jsonResponse(-1, '刷新失败: ' . $result['error']);
                }
            } else {
                jsonResponse(-1, '视频不存在');
            }
        } else {
            jsonResponse(-1, 'ID无效');
        }
    }
}

// 页面加载时获取视频
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $searchId = $_GET['id'] ?? null;
    
    if ($searchId) {
        $video = $db->getVideoById($searchId);
        if ($video) {
            $db->incrementViews($searchId);
        }
    } else {
        $video = $db->getRandomVideo();
        if ($video) {
            $db->incrementViews($video['id']);
        }
    }
}

// 生成CSRF Token
$csrfToken = generateCsrfToken();

// 输出HTML
htmlHeader('探索视频');
?>

<div class="header">
    <h1><i class="fas fa-random"></i> 探索视频</h1>
    <p>搜索视频ID或随机播放视频</p>
</div>

<?php htmlNav('random'); ?>

<div class="content">
    <!-- 搜索表单 -->
        <div class="input-group">
            <label class="input-label">
                <i class="fas fa-search"></i> 视频ID（留空则随机播放）
            </label>
            <div class="input-wrapper">
                <input type="number" id="videoId" placeholder="输入视频ID，如：1" value="<?php echo htmlspecialchars($searchId ?? ''); ?>" min="1">
                <button class="btn btn-primary" onclick="searchVideo()">
                    <i class="fas fa-search"></i> 搜索
                </button>
                <button class="btn btn-secondary" onclick="randomVideo()">
                    <i class="fas fa-random"></i> 随机
                </button>
            </div>
        </div>
        
        <!-- 视频信息 -->
        <div id="videoInfo">
            <?php if ($video): ?>
                <div class="result-table">
                    <!-- ID -->
                    <div class="result-row">
                        <div class="result-label">
                            <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                            ID
                        </div>
                        <div class="result-value">
                            <span><?php echo htmlspecialchars($video['id']); ?></span>
                        </div>
                    </div>
                    
                    <!-- 标题 -->
                    <?php if ($video['title']): ?>
                    <div class="result-row">
                        <div class="result-label">
                            <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                            标题
                        </div>
                        <div class="result-value">
                            <span><?php echo htmlspecialchars($video['title']); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- 封面 -->
                    <?php if (!empty($video['cover'])): ?>
                    <div class="result-row">
                        <div class="result-label">
                            <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                            封面
                        </div>
                        <div class="result-value">
                            <span><?php echo htmlspecialchars($video['cover']); ?></span>
                            <div class="action-buttons">
                                <button class="btn-action" onclick="openPreview('<?php echo htmlspecialchars($video['cover'], ENT_QUOTES); ?>')">
                                    <i class="fas fa-eye"></i> 预览
                                </button>
                                <button class="btn-action" onclick="copyToClipboard('<?php echo htmlspecialchars($video['cover'], ENT_QUOTES); ?>')">
                                    <i class="fas fa-copy"></i> 复制
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- 视频 -->
                    <?php if (!empty($video['url'])): ?>
                    <div class="result-row">
                        <div class="result-label">
                            <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                            视频
                        </div>
                        <div class="result-value">
                            <span><?php echo htmlspecialchars($video['url']); ?></span>
                            <div class="action-buttons">
                                <button class="btn-action" onclick="openPreview('<?php echo htmlspecialchars($video['url'], ENT_QUOTES); ?>')">
                                    <i class="fas fa-eye"></i> 预览
                                </button>
                                <button class="btn-action" onclick="copyToClipboard('<?php echo htmlspecialchars($video['url'], ENT_QUOTES); ?>')">
                                    <i class="fas fa-copy"></i> 复制
                                </button>
                                <button class="btn-action btn-download" onclick="downloadVideo('<?php echo htmlspecialchars($video['url'], ENT_QUOTES); ?>')">
                                    <i class="fas fa-download"></i> 下载
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- 操作按钮 -->
                    <div class="result-row">
                        <div class="result-label">
                            <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                            操作
                        </div>
                        <div class="result-value" style="align-items: center;justify-content: center;">
                            <div >
                                <?php if (isset($_SESSION['user_id'])): ?>
                                <?php
                                    $dbConn = Database::getInstance()->getConnection();
                                    $checkStmt = $dbConn->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND video_id = ?");
                                    $checkStmt->execute([$_SESSION['user_id'], $video['id']]);
                                    $isFavorited = $checkStmt->fetch() ? true : false;
                                ?>
                                <button class="btn-action <?php echo $isFavorited ? 'btn-favorited' : ''; ?>" id="favoriteBtn" onclick="toggleFavorite(<?php echo $video['id']; ?>, <?php echo $isFavorited ? 'true' : 'false'; ?>)">
                                    <i class="fas fa-heart"></i> <span id="favoriteText"><?php echo $isFavorited ? '已收藏' : '收藏'; ?></span>
                                </button>
                                <?php endif; ?>
                                <button class="btn-action" onclick="window.location.href='/article.php?id=<?php echo $video['id']; ?>'" title="查看详细页面">
                                    <i class="fas fa-info-circle"></i> 详细页面
                                </button>
                                <button class="btn-action" onclick="refreshVideo(<?php echo $video['id']; ?>)" title="重新获取视频数据">
                                    <i class="fas fa-sync-alt"></i> 重新获取
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 视频播放器 -->
                <?php 
                // 播放优先级：R2 > 本地 > 解析地址
                $videoSrc = '';
                if (!empty($video['r2_path'])) {
                    // 优先使用R2链接
                    $r2PublicUrl = $db->getSetting('r2_public_url');
                    $videoSrc = $r2PublicUrl . $video['r2_path'];
                } elseif (!empty($video['local_path'])) {
                    // 其次使用本地链接
                    $videoSrc = $video['local_path'];
                } elseif (!empty($video['url'])) {
                    // 最后使用解析地址
                    $videoSrc = $video['url'];
                }
                ?>
                <?php if ($videoSrc): ?>
                <div class="video-player">
                    <video controls autoplay>
                        <source src="<?php echo htmlspecialchars($videoSrc); ?>" type="video/mp4">
                        您的浏览器不支持视频播放
                    </video>
                </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-film"></i>
                    <p><?php echo $searchId ? '视频不存在' : '暂无视频，请先解析视频'; ?></p>
                </div>
            <?php endif; ?>
    </div>
</div>

<script>
// 支持回车键搜索
document.getElementById('videoId').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        searchVideo();
    }
});

// 下载视频
function downloadVideo(url) {
    window.location.href = '/download.php?url=' + encodeURIComponent(url);
}

// 搜索视频
async function searchVideo() {
    const id = document.getElementById('videoId').value.trim();
    
    if (!id) {
        randomVideo();
        return;
    }
    
    if (id < 1) {
        showToast('请输入有效的视频ID');
        return;
    }
    
    const videoInfo = document.getElementById('videoInfo');
    showLoading(videoInfo);
    
    try {
        const formData = new FormData();
        formData.append('action', 'get');
        formData.append('id', id);
        formData.append('csrf_token', '<?php echo $csrfToken; ?>');
        
        const response = await fetch('/random.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.code === 0 && data.data) {
            displayVideo(data.data);
        } else {
            showEmpty(videoInfo, data.message || '视频不存在');
        }
    } catch (error) {
        console.error('请求失败:', error);
        showEmpty(videoInfo, '网络请求失败');
    }
}

// 随机视频
async function randomVideo() {
    const videoInfo = document.getElementById('videoInfo');
    showLoading(videoInfo);
    
    try {
        const formData = new FormData();
        formData.append('action', 'random');
        formData.append('csrf_token', '<?php echo $csrfToken; ?>');
        
        const response = await fetch('/random.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.code === 0 && data.data) {
            displayVideo(data.data);
        } else {
            showEmpty(videoInfo, data.message || '暂无视频');
        }
    } catch (error) {
        console.error('请求失败:', error);
        showEmpty(videoInfo, '网络请求失败');
    }
}

// 显示视频
function displayVideo(video) {
    let html = '<div class="result-table">';
    
    // ID
    html += `
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                ID
            </div>
            <div class="result-value">
                <span>${escapeHtml(video.id)}</span>
            </div>
        </div>
    `;
    
    // 标题
    if (video.title) {
        html += `
            <div class="result-row">
                <div class="result-label">
                    <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                    标题
                </div>
                <div class="result-value">
                    <span>${escapeHtml(video.title)}</span>
                </div>
            </div>
        `;
    }
    
    // 封面
    if (video.cover) {
        html += `
            <div class="result-row">
                <div class="result-label">
                    <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                    封面
                </div>
                <div class="result-value">
                    <span>${escapeHtml(video.cover)}</span>
                    <div class="action-buttons">
                        <button class="btn-action" onclick="openPreview('${escapeAttr(video.cover)}')">
                            <i class="fas fa-eye"></i> 预览
                        </button>
                        <button class="btn-action" onclick="copyToClipboard('${escapeAttr(video.cover)}')">
                            <i class="fas fa-copy"></i> 复制
                        </button>
                    </div>
                </div>
            </div>
        `;
    }
    
    // 视频
    if (video.url) {
        html += `
            <div class="result-row">
                <div class="result-label">
                    <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                    视频
                </div>
                <div class="result-value">
                    <span>${escapeHtml(video.url)}</span>
                    <div class="action-buttons">
                        <button class="btn-action" onclick="openPreview('${escapeAttr(video.url)}')">
                            <i class="fas fa-eye"></i> 预览
                        </button>
                        <button class="btn-action" onclick="copyToClipboard('${escapeAttr(video.url)}')">
                            <i class="fas fa-copy"></i> 复制
                        </button>
                        <button class="btn-action btn-download" onclick="downloadVideo('${escapeAttr(video.url)}')">
                            <i class="fas fa-download"></i> 下载
                        </button>
                    </div>
                </div>
            </div>
        `;
    }
    
    // 操作按钮
    html += `
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                操作
            </div>
            <div class="result-value">
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <?php if (isset($_SESSION['user_id'])): ?>
                    <button class="btn-action ${video.is_favorited ? 'btn-favorited' : ''}" id="favoriteBtn" onclick="toggleFavorite(${video.id}, ${video.is_favorited ? 'true' : 'false'})">
                        <i class="fas fa-heart"></i> <span id="favoriteText">${video.is_favorited ? '已收藏' : '收藏'}</span>
                    </button>
                    <?php endif; ?>
                    <button class="btn-action" onclick="window.location.href='/article.php?id=${video.id}'" title="查看详细页面">
                        <i class="fas fa-info-circle"></i> 详细页面
                    </button>
                    <button class="btn-action" onclick="refreshVideo(${video.id})" title="重新获取视频数据">
                        <i class="fas fa-sync-alt"></i> 重新获取
                    </button>
                </div>
            </div>
        </div>
    `;
    
    html += '</div>';
    
    // 视频播放器 - 播放优先级：R2 > 本地 > 解析地址
    let videoSrc = '';
    if (video.r2_path) {
        // 优先使用R2链接
        videoSrc = '<?php echo $db->getSetting("r2_public_url"); ?>' + video.r2_path;
    } else if (video.local_path) {
        // 其次使用本地链接
        videoSrc = video.local_path;
    } else if (video.url) {
        // 最后使用解析地址
        videoSrc = video.url;
    }
    
    if (videoSrc) {
        html += `
            <div class="video-player">
                <video controls autoplay>
                    <source src="${escapeAttr(videoSrc)}" type="video/mp4">
                    您的浏览器不支持视频播放
                </video>
            </div>
        `;
    }
    
    document.getElementById('videoInfo').innerHTML = html;
}

// 重新获取视频数据
async function refreshVideo(id) {
    if (!confirm('确定要重新获取该视频的数据吗？')) {
        return;
    }
    
    const videoInfo = document.getElementById('videoInfo');
    showLoading(videoInfo);
    
    try {
        const formData = new FormData();
        formData.append('action', 'refresh');
        formData.append('id', id);
        formData.append('csrf_token', '<?php echo $csrfToken; ?>');
        
        const response = await fetch('/random.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.code === 0 && data.data) {
            displayVideo(data.data);
            showToast(data.message || '刷新成功');
        } else {
            showEmpty(videoInfo, data.message || '刷新失败');
        }
    } catch (error) {
        console.error('请求失败:', error);
        showEmpty(videoInfo, '网络请求失败');
    }
}

// 收藏/取消收藏
async function toggleFavorite(videoId, isFavorited) {
    try {
        const formData = new FormData();
        formData.append('action', isFavorited ? 'unfavorite' : 'favorite');
        formData.append('video_id', videoId);
        formData.append('csrf_token', '<?php echo $csrfToken; ?>');
        
        const response = await fetch('/user/api.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.code === 0) {
            const btn = document.getElementById('favoriteBtn');
            const text = document.getElementById('favoriteText');
            
            if (isFavorited) {
                btn.classList.remove('btn-favorited');
                text.textContent = '收藏';
            } else {
                btn.classList.add('btn-favorited');
                text.textContent = '已收藏';
            }
            
            // 更新onclick事件
            btn.setAttribute('onclick', `toggleFavorite(${videoId}, ${!isFavorited})`);
            
            showToast(data.message || (isFavorited ? '取消收藏成功' : '收藏成功'));
        } else {
            showToast(data.message || '操作失败');
        }
    } catch (error) {
        console.error('收藏操作失败:', error);
        showToast('网络请求失败');
    }
}

// 打开预览
function openPreview(url) {
    window.open(url, '_blank');
}

// 复制到剪贴板
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showToast('✓ 复制成功！');
    } catch (error) {
        // 备用方案
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('✓ 复制成功！');
    }
}

// 转义HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// 转义属性
function escapeAttr(text) {
    return String(text).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// 显示加载状态
function showLoading(container) {
    container.innerHTML = '<div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>加载中...</p></div>';
}

// 显示空状态
function showEmpty(container, message) {
    container.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i><p>${escapeHtml(message)}</p></div>`;
}

// 显示提示
function showToast(message) {
    // 创建提示元素
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #333; color: #fff; padding: 12px 20px; border-radius: 4px; z-index: 10000; animation: slideIn 0.3s ease;';
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 2000);
}
</script>

<style>
@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOut {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}
</style>

<?php htmlFooter(); ?>

