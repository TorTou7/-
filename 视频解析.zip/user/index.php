<?php
/**
 * 用户中心 - 标签页式布局
 */

require_once '../config.php';
require_once '../database.php';
require_once '../functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 检查登录状态
if (!isset($_SESSION['user_id'])) {
    header('Location: /user/login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? '用户';
$email = $_SESSION['email'] ?? '';

// 获取数据库连接
$db = Database::getInstance()->getConnection();

// 获取用户信息
$stmt = $db->prepare("SELECT is_admin, password_updated_at FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// 检查用户是否存在
if (!$user) {
    // 用户不存在, 清除session并跳转到登录页
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    header('Location: /user/login.php?error=' . urlencode('您的账号已被删除'));
    exit;
}

$isAdmin = $user['is_admin'] ?? 0;
$passwordUpdatedAt = $user['password_updated_at'] ?? null;

// 获取当前页面参数
$currentPage = $_GET['page'] ?? 'home';
$allowedPages = ['home', 'my-videos', 'favorites', 'custom'];
if ($isAdmin) {
    $allowedPages[] = 'admin';
}
if (!in_array($currentPage, $allowedPages)) {
    $currentPage = 'home';
}

// 获取统计数据
$stats = [
    'my_videos' => 0,
    'favorites' => 0,
    'total_views' => 0
];

// 我的视频数量
$stmt = $db->prepare("SELECT COUNT(*) as count FROM user_videos WHERE user_id = ?");
$stmt->execute([$userId]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$stats['my_videos'] = $result['count'] ?? 0;

// 收藏视频数量
$stmt = $db->prepare("SELECT COUNT(*) as count FROM user_favorites WHERE user_id = ?");
$stmt->execute([$userId]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$stats['favorites'] = $result['count'] ?? 0;

// 总浏览量
$stmt = $db->prepare("
    SELECT SUM(v.views) as total_views 
    FROM user_videos uv 
    JOIN videos v ON uv.video_id = v.id 
    WHERE uv.user_id = ?
");
$stmt->execute([$userId]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$stats['total_views'] = $result['total_views'] ?? 0;

// 输出HTML头部
htmlHeader('用户中心');
?>

<div class="header">
    <h1><i class="fas fa-user-circle"></i> 用户中心</h1>
    <p>管理查看数据统计</p>
</div>

<?php htmlNav('user'); ?>

<link rel="stylesheet" href="/assets/dashboard.css">

<div class="content">
    <!-- 用户信息卡片 -->
    <div class="user-card">
        <div class="user-card-left">
            <div class="user-avatar">
                <i class="fas fa-user-circle"></i>
            </div>
            <div class="user-details">
                <h2 class="user-name"><?php echo htmlspecialchars($username); ?></h2>
                <p class="user-email">
                    <?php if ($email): ?>
                        <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($email); ?>
                    <?php else: ?>
                        <i class="fas fa-envelope"></i> 未设置邮箱
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <div class="user-card-right">
            <div class="stat-item">
                <div class="stat-value"><?php echo $stats['my_videos']; ?></div>
                <div class="stat-label">我的视频</div>
            </div>
            <div class="stat-item">
                <div class="stat-value"><?php echo $stats['favorites']; ?></div>
                <div class="stat-label">收藏视频</div>
            </div>
            <div class="stat-item">
                <div class="stat-value"><?php echo $stats['total_views']; ?></div>
                <div class="stat-label">总浏览量</div>
            </div>
        </div>
    </div>

    <!-- 标签页导航 -->
    <div class="tabs-nav">
        <button class="tab-btn <?php echo $currentPage === 'home' ? 'active' : ''; ?>" data-tab="home" onclick="location.href='?page=home'">
            <i class="fas fa-home"></i>
            <span>用户首页</span>
        </button>
        <button class="tab-btn <?php echo $currentPage === 'my-videos' ? 'active' : ''; ?>" data-tab="my-videos" onclick="location.href='?page=my-videos'">
            <i class="fas fa-video"></i>
            <span>我的链接</span>
        </button>
        <button class="tab-btn <?php echo $currentPage === 'favorites' ? 'active' : ''; ?>" data-tab="favorites" onclick="location.href='?page=favorites'">
            <i class="fas fa-heart"></i>
            <span>喜欢收藏</span>
        </button>
        <button class="tab-btn <?php echo $currentPage === 'custom' ? 'active' : ''; ?>" data-tab="custom" onclick="location.href='?page=custom'">
            <i class="fas fa-magic"></i>
            <span>专属定制</span>
        </button>
        <?php if ($isAdmin): ?>
        <button class="tab-btn <?php echo $currentPage === 'admin' ? 'active' : ''; ?>" data-tab="admin" onclick="location.href='?page=admin'">
            <i class="fas fa-shield-alt"></i>
            <span>管理后台</span>
        </button>
        <?php endif; ?>
        <button class="tab-btn logout-btn" onclick="if(confirm('确定要退出登录吗？')) location.href='/user/auth.php?action=logout'">
            <i class="fas fa-sign-out-alt"></i>
            <span>退出登录</span>
        </button>
    </div>

    <!-- 标签页内容 -->
    <div class="tabs-content">
        <!-- 用户首页 -->
        <div class="tab-pane <?php echo $currentPage === 'home' ? 'active' : ''; ?>" id="tab-home">
            <?php include 'pages/home.php'; ?>
        </div>

        <!-- 我的链接 -->
        <div class="tab-pane <?php echo $currentPage === 'my-videos' ? 'active' : ''; ?>" id="tab-my-videos">
            <?php include 'pages/my-videos.php'; ?>
        </div>

        <!-- 喜欢收藏 -->
        <div class="tab-pane <?php echo $currentPage === 'favorites' ? 'active' : ''; ?>" id="tab-favorites">
            <?php include 'pages/favorites.php'; ?>
        </div>

        <!-- 专属定制 -->
        <div class="tab-pane <?php echo $currentPage === 'custom' ? 'active' : ''; ?>" id="tab-custom">
            <?php include 'pages/custom.php'; ?>
        </div>

        <?php if ($isAdmin): ?>
        <!-- 管理后台 -->
        <div class="tab-pane <?php echo $currentPage === 'admin' ? 'active' : ''; ?>" id="tab-admin">
            <?php include 'pages/admin.php'; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<script src="/assets/dashboard.js"></script>

<?php htmlFooter(); ?>

