-- 视频存储功能数据库更新

-- 为 videos 表添加存储相关字段
ALTER TABLE `videos` 
-- 本地存储字段
ADD COLUMN `local_url` VARCHAR(500) DEFAULT NULL COMMENT '本地存储的视频URL' AFTER `url`,
ADD COLUMN `local_uploaded_at` DATETIME DEFAULT NULL COMMENT '本地上传时间' AFTER `local_url`,
ADD COLUMN `local_file_size` BIGINT DEFAULT NULL COMMENT '本地文件大小(字节)' AFTER `local_uploaded_at`,
-- R2 存储字段
ADD COLUMN `r2_url` VARCHAR(500) DEFAULT NULL COMMENT 'R2存储的视频URL' AFTER `local_file_size`,
ADD COLUMN `r2_uploaded_at` DATETIME DEFAULT NULL COMMENT 'R2上传时间' AFTER `r2_url`,
ADD COLUMN `r2_file_size` BIGINT DEFAULT NULL COMMENT 'R2文件大小(字节)' AFTER `r2_uploaded_at`,
ADD COLUMN `backup_status` ENUM('pending', 'uploading', 'completed', 'failed') DEFAULT 'pending' COMMENT '备份状态' AFTER `r2_file_size`;

-- 配置项说明
-- 本系统使用 Database::setSetting() 方法动态创建配置项，无需预先创建
-- 存储策略: storage_strategy (local/r2/both)
-- 本地存储: local_storage_path, local_storage_url
-- R2 存储: r2_account_id, r2_access_key_id, r2_secret_access_key, r2_bucket_name, r2_public_domain

