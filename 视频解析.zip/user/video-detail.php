<?php
/**
 * 视频详情页面
 */

require_once '../config.php';
require_once '../database.php';
require_once '../functions.php';

$videoId = intval($_GET['id'] ?? 0);

if ($videoId <= 0) {
    header('Location: /');
    exit;
}

$db = Database::getInstance();
$video = $db->getVideoById($videoId);

if (!$video) {
    header('Location: /');
    exit;
}

// 增加浏览量
$db->incrementViews($videoId);

htmlHeader($video['title'] ?? '视频详情', true, ['video-detail']);
?>

<div class="header">
    <h1><i class="fas fa-play-circle"></i> 视频详情</h1>
    <p>ID: #<?php echo $video['id']; ?></p>
</div>

<div class="nav">
    <div class="nav-buttons">
        <a href="/" class="btn btn-secondary">
            <i class="fas fa-home"></i> 视频解析
        </a>
        <a href="/random.php" class="btn btn-secondary">
            <i class="fas fa-random"></i> 探索视频
        </a>
        <?php if (isset($_SESSION['user_id'])): ?>
        <a href="/user/index.php" class="btn btn-secondary">
            <i class="fas fa-user-circle"></i> 会员中心
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="content">
    <div class="video-detail-container">
        <!-- 视频信息卡片 -->
        <div class="video-detail-card">
            <div class="video-detail-header">
                <h2><?php echo htmlspecialchars($video['title'] ?? '无标题'); ?></h2>
                <div class="video-meta">
                    <span><i class="fas fa-eye"></i> <?php echo number_format($video['views']); ?> 次浏览</span>
                    <span><i class="fas fa-clock"></i> <?php echo date('Y-m-d H:i', strtotime($video['created_at'])); ?></span>
                </div>
            </div>
            
            <!-- 封面图 -->
            <?php if (!empty($video['cover'])): ?>
            <div class="video-cover">
                <img src="<?php echo htmlspecialchars($video['cover']); ?>" alt="封面">
            </div>
            <?php endif; ?>
            
            <!-- 视频播放器 -->
            <div class="video-player">
                <video controls poster="<?php echo htmlspecialchars($video['cover']); ?>" style="width:100%;max-height:600px;">
                    <source src="<?php echo htmlspecialchars($video['url']); ?>" type="video/mp4">
                    您的浏览器不支持视频播放
                </video>
            </div>
            
            <!-- 操作按钮 -->
            <div class="video-actions">
                <button class="btn btn-primary" onclick="document.querySelector('video').play()">
                    <i class="fas fa-play"></i> 播放视频
                </button>
                <button class="btn btn-secondary" onclick="copyToClipboard('<?php echo htmlspecialchars($video['url'], ENT_QUOTES); ?>')">
                    <i class="fas fa-copy"></i> 复制视频链接
                </button>
                <a href="<?php echo htmlspecialchars($video['url']); ?>" download class="btn btn-secondary">
                    <i class="fas fa-download"></i> 下载视频
                </a>
                <?php if (isset($_SESSION['user_id'])): ?>
                <button class="btn btn-secondary" id="favoriteBtn" onclick="toggleFavorite(<?php echo $video['id']; ?>)">
                    <i class="fas fa-heart"></i> <span id="favoriteText">收藏</span>
                </button>
                <?php endif; ?>
            </div>
            
            <!-- 视频信息 -->
            <div class="video-info-table">
                <table>
                    <tr>
                        <td><strong>视频ID</strong></td>
                        <td>#<?php echo $video['id']; ?></td>
                    </tr>
                    <tr>
                        <td><strong>标题</strong></td>
                        <td><?php echo htmlspecialchars($video['title'] ?? '无标题'); ?></td>
                    </tr>
                    <tr>
                        <td><strong>原地址</strong></td>
                        <td style="word-break:break-all;"><?php echo htmlspecialchars($video['input_url']); ?></td>
                    </tr>
                    <tr>
                        <td><strong>浏览次数</strong></td>
                        <td><?php echo number_format($video['views']); ?></td>
                    </tr>
                    <tr>
                        <td><strong>解析时间</strong></td>
                        <td><?php echo date('Y-m-d H:i:s', strtotime($video['created_at'])); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// 复制到剪贴板
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showMessage('复制成功', 'success');
    }).catch(() => {
        showMessage('复制失败', 'error');
    });
}

// 切换收藏状态
async function toggleFavorite(videoId) {
    try {
        const response = await fetch('/user/api.php?action=toggle_favorite', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({video_id: videoId})
        });
        
        const result = await response.json();
        
        if (result.success) {
            const btn = document.getElementById('favoriteBtn');
            const text = document.getElementById('favoriteText');
            if (result.favorited) {
                btn.classList.add('btn-danger');
                btn.classList.remove('btn-secondary');
                text.textContent = '已收藏';
            } else {
                btn.classList.remove('btn-danger');
                btn.classList.add('btn-secondary');
                text.textContent = '收藏';
            }
            showMessage(result.message, 'success');
        } else {
            showMessage(result.message || '操作失败', 'error');
        }
    } catch (error) {
        showMessage('操作失败', 'error');
    }
}

// 检查收藏状态
<?php if (isset($_SESSION['user_id'])): ?>
async function checkFavoriteStatus() {
    try {
        const response = await fetch('/user/api.php?action=check_favorite&video_id=<?php echo $video['id']; ?>');
        const result = await response.json();
        
        if (result.favorited) {
            const btn = document.getElementById('favoriteBtn');
            const text = document.getElementById('favoriteText');
            btn.classList.add('btn-danger');
            btn.classList.remove('btn-secondary');
            text.textContent = '已收藏';
        }
    } catch (error) {
        console.error('检查收藏状态失败', error);
    }
}

checkFavoriteStatus();
<?php endif; ?>

// 显示消息
function showMessage(text, type) {
    const msg = document.createElement('div');
    msg.textContent = text;
    msg.style.cssText = 'position:fixed;top:20px;right:20px;padding:15px 25px;background:#fff;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);z-index:9999;';
    if (type === 'success') msg.style.borderLeft = '4px solid #28a745';
    if (type === 'error') msg.style.borderLeft = '4px solid #dc3545';
    document.body.appendChild(msg);
    setTimeout(() => msg.remove(), 3000);
}
</script>

<?php htmlFooter(); ?>

