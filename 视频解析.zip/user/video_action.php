<?php
/**
 * 视频操作处理
 * 处理删除、收藏等操作
 */

require_once '../config.php';
require_once '../database.php';

// Session已在config.php中启动,无需重复调用
header('Content-Type: application/json; charset=utf-8');

// 检查登录状态
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => '请先登录'
    ]);
    exit;
}

$userId = $_SESSION['user_id'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    $db = Database::getInstance()->getConnection();
    
    switch ($action) {
        case 'delete':
            handleDelete($db, $userId);
            break;
            
        case 'favorite':
            handleFavorite($db, $userId);
            break;
            
        case 'unfavorite':
            handleUnfavorite($db, $userId);
            break;
            
        default:
            throw new Exception('无效的操作');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * 删除视频关联
 */
function handleDelete($db, $userId) {
    $videoId = intval($_POST['video_id'] ?? 0);
    
    if (!$videoId) {
        throw new Exception('视频ID无效');
    }
    
    // 检查是否是视频的作者
    $stmt = $db->prepare("SELECT id FROM user_videos WHERE user_id = ? AND video_id = ?");
    $stmt->execute([$userId, $videoId]);
    
    if (!$stmt->fetch()) {
        throw new Exception('您不是此视频的作者');
    }
    
    // 删除关联关系
    $stmt = $db->prepare("DELETE FROM user_videos WHERE user_id = ? AND video_id = ?");
    
    if ($stmt->execute([$userId, $videoId])) {
        echo json_encode([
            'success' => true,
            'message' => '删除成功！此链接已变为无主状态'
        ]);
    } else {
        throw new Exception('删除失败，请重试');
    }
}

/**
 * 收藏视频
 */
function handleFavorite($db, $userId) {
    $videoId = intval($_POST['video_id'] ?? 0);
    
    if (!$videoId) {
        throw new Exception('视频ID无效');
    }
    
    // 检查视频是否存在
    $stmt = $db->prepare("SELECT id FROM videos WHERE id = ?");
    $stmt->execute([$videoId]);
    
    if (!$stmt->fetch()) {
        throw new Exception('视频不存在');
    }
    
    // 检查是否已收藏
    $stmt = $db->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND video_id = ?");
    $stmt->execute([$userId, $videoId]);
    
    if ($stmt->fetch()) {
        throw new Exception('您已收藏过此视频');
    }
    
    // 添加收藏
    $stmt = $db->prepare("INSERT INTO user_favorites (user_id, video_id, created_at) VALUES (?, ?, NOW())");
    
    if ($stmt->execute([$userId, $videoId])) {
        echo json_encode([
            'success' => true,
            'message' => '收藏成功！'
        ]);
    } else {
        throw new Exception('收藏失败，请重试');
    }
}

/**
 * 取消收藏
 */
function handleUnfavorite($db, $userId) {
    $videoId = intval($_POST['video_id'] ?? 0);
    
    if (!$videoId) {
        throw new Exception('视频ID无效');
    }
    
    // 删除收藏
    $stmt = $db->prepare("DELETE FROM user_favorites WHERE user_id = ? AND video_id = ?");
    
    if ($stmt->execute([$userId, $videoId])) {
        echo json_encode([
            'success' => true,
            'message' => '已取消收藏'
        ]);
    } else {
        throw new Exception('操作失败，请重试');
    }
}
?>

