<?php
/**
 * 用户登录页面
 */

require_once '../config.php';
require_once '../database.php';
require_once '../functions.php';

// Session已在config.php中启动,无需重复调用

// 如果已登录，跳转到用户中心
if (isset($_SESSION['user_id'])) {
    header('Location: /user/');
    exit;
}

htmlHeader('用户登录', true, ['login']);
?>

<div class="header">
    <h1><i class="fas fa-sign-in-alt"></i> 用户登录</h1>
    <p>登录您的账户</p>
</div>

<?php htmlNav('login'); ?>

<div class="content">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <i class="fas fa-user-circle"></i>
                <h2>欢迎回来</h2>
                <p>请登录您的账户</p>
            </div>
            
            <div id="loginMessage" class="auth-message"></div>
            
            <form id="loginForm" class="auth-form">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> 用户名/邮箱
                    </label>
                    <input type="text" id="username" name="username" required 
                           placeholder="请输入用户名或邮箱">
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> 密码
                    </label>
                    <input type="password" id="password" name="password" required 
                           placeholder="请输入密码">
                </div>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember" id="remember">
                        <span>记住我</span>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-sign-in-alt"></i> 登录
                </button>
            </form>
            
            <div class="auth-footer">
                <p>还没有账户？ <a href="/user/register.php">立即注册</a></p>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const messageDiv = document.getElementById('loginMessage');
    const submitBtn = this.querySelector('button[type="submit"]');
    
    // 禁用提交按钮
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 登录中...';
    
    const formData = new FormData(this);
    
    try {
        const response = await fetch('/user/auth.php?action=login', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.className = 'auth-message success';
            messageDiv.innerHTML = '<i class="fas fa-check-circle"></i> ' + result.message;
            
            // 延迟跳转
            setTimeout(() => {
                window.location.href = '/user/';
            }, 1000);
        } else {
            messageDiv.className = 'auth-message error';
            messageDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + result.message;
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> 登录';
        }
    } catch (error) {
        messageDiv.className = 'auth-message error';
        messageDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> 登录失败，请重试';
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> 登录';
    }
});
</script>

<?php htmlFooter(); ?>

