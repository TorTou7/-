<?php
/**
 * 用户注册页面
 */

require_once '../config.php';
require_once '../database.php';
require_once '../functions.php';

// Session已在config.php中启动,无需重复调用

// 如果已登录，跳转到用户中心
if (isset($_SESSION['user_id'])) {
    header('Location: /user/');
    exit;
}

htmlHeader('用户注册', true, ['login']);
?>

<div class="header">
    <h1><i class="fas fa-user-plus"></i> 用户注册</h1>
    <p>创建您的账户</p>
</div>

<?php htmlNav('register'); ?>

<div class="content">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <i class="fas fa-user-plus"></i>
                <h2>创建账户</h2>
                <p>加入我们，开始使用</p>
            </div>
            
            <div id="registerMessage" class="auth-message"></div>
            
            <form id="registerForm" class="auth-form">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> 用户名
                    </label>
                    <input type="text" id="username" name="username" required 
                           placeholder="请输入用户名（1-20个字符）"
                           maxlength="20"
                           title="用户名支持中文、英文、数字，长度1-20个字符">
                </div>
                
                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i> 邮箱
                    </label>
                    <input type="email" id="email" name="email" 
                           placeholder="请输入邮箱地址（可选）">
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> 密码
                    </label>
                    <input type="password" id="password" name="password" required 
                           placeholder="请输入密码">
                </div>
                
                <div class="form-group">
                    <label for="password_confirm">
                        <i class="fas fa-lock"></i> 确认密码
                    </label>
                    <input type="password" id="password_confirm" name="password_confirm" required 
                           placeholder="请再次输入密码">
                </div>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="agree" id="agree" required>
                        <span>我已阅读并同意 <a href="#" class="link">服务条款</a></span>
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-user-plus"></i> 注册
                </button>
            </form>
            
            <div class="auth-footer">
                <p>已有账户？ <a href="/user/login.php">立即登录</a></p>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('registerForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const messageDiv = document.getElementById('registerMessage');
    const submitBtn = this.querySelector('button[type="submit"]');
    const password = document.getElementById('password').value;
    const passwordConfirm = document.getElementById('password_confirm').value;
    
    // 验证密码一致性
    if (password !== passwordConfirm) {
        messageDiv.className = 'auth-message error';
        messageDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> 两次输入的密码不一致';
        return;
    }
    
    // 禁用提交按钮
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 注册中...';
    
    const formData = new FormData(this);
    
    try {
        const response = await fetch('/user/auth.php?action=register', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.className = 'auth-message success';
            messageDiv.innerHTML = '<i class="fas fa-check-circle"></i> ' + result.message;
            
            // 延迟跳转到登录页
            setTimeout(() => {
                window.location.href = '/user/login.php';
            }, 2000);
        } else {
            messageDiv.className = 'auth-message error';
            messageDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + result.message;
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-user-plus"></i> 注册';
        }
    } catch (error) {
        messageDiv.className = 'auth-message error';
        messageDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> 注册失败，请重试';
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-user-plus"></i> 注册';
    }
});
</script>

<?php htmlFooter(); ?>

