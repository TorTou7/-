<?php
/**
 * 用户认证处理
 * 处理登录、注册、找回密码等操作
 */

require_once '../config.php';
require_once '../database.php';

// Session已在config.php中启动,无需重复调用
header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';

try {
    $db = Database::getInstance()->getConnection();
    
    switch ($action) {
        case 'register':
            handleRegister($db);
            break;
            
        case 'login':
            handleLogin($db);
            break;
            
        case 'logout':
            handleLogout();
            break;
            
        case 'update_email':
            handleUpdateEmail($db);
            break;
            
        case 'update_password':
            handleUpdatePassword($db);
            break;
        
        default:
            throw new Exception('无效的操作');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * 处理用户注册
 */
function handleRegister($db) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // 验证输入
    if (empty($username) || empty($password)) {
        throw new Exception('请填写用户名和密码');
    }
    
    // 用户名验证：1-20个字符，支持中文、英文、数字，除特殊字符外
    if (mb_strlen($username) < 1 || mb_strlen($username) > 20) {
        throw new Exception('用户名长度必须在1-20个字符之间');
    }
    
    // 检查是否包含特殊字符
    if (preg_match('/[<>"\'\/\\;(){}\[\]&|`~!@#$%^*+=]/', $username)) {
        throw new Exception('用户名不能包含特殊字符');
    }
    
    // 邮箱验证（可选）
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('邮箱格式不正确');
    }
    
    // 检查用户名是否已存在
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        throw new Exception('用户名已被使用');
    }
    
    // 检查邮箱是否已存在（如果提供了邮箱）
    if (!empty($email)) {
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            throw new Exception('邮箱已被注册');
        }
    }
    
    // 创建用户
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $db->prepare("
        INSERT INTO users (username, email, password, created_at) 
        VALUES (?, ?, ?, NOW())
    ");
    
    // 邮箱为空时使用NULL
    $emailValue = !empty($email) ? $email : null;
    
    if ($stmt->execute([$username, $emailValue, $passwordHash])) {
        echo json_encode([
            'success' => true,
            'message' => '注册成功！即将跳转到登录页...'
        ]);
    } else {
        throw new Exception('注册失败，请重试');
    }
}

/**
 * 处理用户登录
 */
function handleLogin($db) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);
    
    if (empty($username) || empty($password)) {
        throw new Exception('请输入用户名和密码');
    }
    
    // 查询用户（支持用户名或邮箱登录）
    $stmt = $db->prepare("
        SELECT id, username, email, password 
        FROM users 
        WHERE username = ? OR email = ?
    ");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        throw new Exception('用户名或密码错误');
    }
    
    // 验证密码
    if (!password_verify($password, $user['password'])) {
        throw new Exception('用户名或密码错误');
    }
    
    // 设置session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    
    // 记住我功能
    if ($remember) {
        // 设置session过期时间为30天
        ini_set('session.gc_maxlifetime', 86400 * 30);
        session_set_cookie_params(86400 * 30);
    }
    
    // 更新最后登录时间
    $stmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $stmt->execute([$user['id']]);
    
    echo json_encode([
        'success' => true,
        'message' => '登录成功！'
    ]);
}

/**
 * 处理用户登出
 */
function handleLogout() {
    session_destroy();
    setcookie('remember_token', '', time() - 3600, '/');
    
    // 直接跳转到首页,不返回JSON
    header('Location: /');
    exit;
}

/**
 * 处理修改邮箱
 */
function handleUpdateEmail($db) {
    // 检查登录状态
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('请先登录');
    }
    
    $userId = $_SESSION['user_id'];
    $newEmail = trim($_POST['email'] ?? '');
    
    // 验证新邮箱格式（如果不为空）
    if (!empty($newEmail) && !filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('邮箱格式不正确');
    }
    
    // 检查邮箱是否已被使用
    if (!empty($newEmail)) {
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$newEmail, $userId]);
        if ($stmt->fetch()) {
            throw new Exception('该邮箱已被其他用户使用');
        }
    }
    
    // 更新邮箱
    $emailValue = !empty($newEmail) ? $newEmail : null;
    $stmt = $db->prepare("UPDATE users SET email = ? WHERE id = ?");
    
    if ($stmt->execute([$emailValue, $userId])) {
        $_SESSION['email'] = $emailValue;
        echo json_encode([
            'success' => true,
            'message' => '邮箱修改成功！'
        ]);
    } else {
        throw new Exception('修改失败，请重试');
    }
}

/**
 * 处理修改密码
 */
function handleUpdatePassword($db) {
    // 检查登录状态
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('请先登录');
    }
    
    $userId = $_SESSION['user_id'];
    $oldPassword = $_POST['old_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    
    if (empty($oldPassword) || empty($newPassword)) {
        throw new Exception('请填写完整信息');
    }
    
    if (strlen($newPassword) < 6) {
        throw new Exception('新密码长度不能少于6位');
    }
    
    // 验证旧密码
    $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || !password_verify($oldPassword, $user['password'])) {
        throw new Exception('当前密码错误');
    }
    
    // 更新密码和修改时间
    $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $db->prepare("UPDATE users SET password = ?, password_updated_at = NOW() WHERE id = ?");
    
    if ($stmt->execute([$passwordHash, $userId])) {
        echo json_encode([
            'success' => true,
            'message' => '密码修改成功！'
        ]);
    } else {
        throw new Exception('修改失败，请重试');
    }
}

