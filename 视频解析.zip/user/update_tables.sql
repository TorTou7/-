-- 更新数据库表结构
-- 为users表添加is_admin字段

ALTER TABLE `users` ADD COLUMN `is_admin` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否管理员' AFTER `email`;

-- 如果表已存在is_admin字段，以上语句会报错，可以忽略

