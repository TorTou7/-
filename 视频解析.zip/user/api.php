<?php
/**
 * 会员功能API处理
 */

require_once '../config.php';
require_once '../database.php';

// Session已在config.php中启动,无需重复调用
header('Content-Type: application/json; charset=utf-8');

// 检查登录
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$userId = $_SESSION['user_id'];
$action = $_GET['action'] ?? '';
$db = Database::getInstance()->getConnection();

// 检查是否是管理员
$stmt = $db->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$isAdmin = ($user && $user['is_admin'] == 1);

try {
    switch ($action) {
        case 'add_to_my_videos':
            addToMyVideos($db, $userId);
            break;
            
        case 'delete_my_video':
            deleteMyVideo($db, $userId);
            break;
            
        case 'toggle_favorite':
            toggleFavorite($db, $userId);
            break;
            
        case 'check_favorite':
            checkFavorite($db, $userId);
            break;
            
        case 'remove_favorite':
            removeFavorite($db, $userId);
            break;
            
        case 'unfavorite_video':
            unfavoriteVideo($db, $userId);
            break;
            
        case 'create_custom_link':
            createCustomLink($db, $userId);
            break;
            
        case 'update_custom_link':
            updateCustomLink($db, $userId);
            break;
            
        case 'delete_custom_link':
            deleteCustomLink($db, $userId);
            break;
            
        case 'save_config':
            saveConfig($db, $userId, $isAdmin);
            break;
            
        case 'delete_video':
            deleteVideo($db, $userId, $isAdmin);
            break;
            
        case 'delete_user':
            deleteUser($db, $userId, $isAdmin);
            break;
            
        case 'find_user_by_video':
            findUserByVideo($db, $userId, $isAdmin);
            break;
            
        case 'delete_all_videos':
            deleteAllVideos($db, $userId, $isAdmin);
            break;
            
        case 'save_storage_config':
            saveStorageConfig($db, $userId, $isAdmin);
            break;
            
        case 'test_storage_config':
            testStorageConfig($db, $userId, $isAdmin);
            break;
            
        // 兼容旧接口
        case 'save_r2_config':
            saveStorageConfig($db, $userId, $isAdmin);
            break;
            
        case 'test_r2_connection':
            testStorageConfig($db, $userId, $isAdmin);
            break;
            
        case 'backup_video':
            backupVideoManually($db, $userId, $isAdmin);
            break;
            
        default:
            throw new Exception('无效的操作');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * 添加到我的视频
 */
function addToMyVideos($db, $userId) {
    $input = json_decode(file_get_contents('php://input'), true);
    $videoId = intval($input['video_id'] ?? 0);
    
    if ($videoId <= 0) {
        throw new Exception('无效的视频ID');
    }
    
    $stmt = $db->prepare("
        INSERT IGNORE INTO user_videos (user_id, video_id, created_at) 
        VALUES (?, ?, NOW())
    ");
    $stmt->execute([$userId, $videoId]);
    
    echo json_encode([
        'success' => true,
        'message' => '已添加到我的视频'
    ]);
}

/**
 * 从我的视频中删除
 */
function deleteMyVideo($db, $userId) {
    $input = json_decode(file_get_contents('php://input'), true);
    $videoId = intval($input['video_id'] ?? 0);
    
    if ($videoId <= 0) {
        throw new Exception('无效的视频ID');
    }
    
    $stmt = $db->prepare("
        DELETE FROM user_videos 
        WHERE user_id = ? AND video_id = ?
    ");
    $stmt->execute([$userId, $videoId]);
    
    echo json_encode([
        'success' => true,
        'message' => '删除成功'
    ]);
}

/**
 * 切换收藏状态
 */
function toggleFavorite($db, $userId) {
    $input = json_decode(file_get_contents('php://input'), true);
    $videoId = intval($input['video_id'] ?? 0);
    
    if ($videoId <= 0) {
        throw new Exception('无效的视频ID');
    }
    
    // 检查是否已收藏
    $stmt = $db->prepare("
        SELECT id FROM user_favorites 
        WHERE user_id = ? AND video_id = ?
    ");
    $stmt->execute([$userId, $videoId]);
    $exists = $stmt->fetch();
    
    if ($exists) {
        // 取消收藏
        $stmt = $db->prepare("
            DELETE FROM user_favorites 
            WHERE user_id = ? AND video_id = ?
        ");
        $stmt->execute([$userId, $videoId]);
        
        echo json_encode([
            'success' => true,
            'favorited' => false,
            'message' => '已取消收藏'
        ]);
    } else {
        // 添加收藏
        $stmt = $db->prepare("
            INSERT INTO user_favorites (user_id, video_id, created_at) 
            VALUES (?, ?, NOW())
        ");
        $stmt->execute([$userId, $videoId]);
        
        echo json_encode([
            'success' => true,
            'favorited' => true,
            'message' => '收藏成功'
        ]);
    }
}

/**
 * 检查收藏状态
 */
function checkFavorite($db, $userId) {
    $videoId = intval($_GET['video_id'] ?? 0);
    
    if ($videoId <= 0) {
        throw new Exception('无效的视频ID');
    }
    
    $stmt = $db->prepare("
        SELECT id FROM user_favorites 
        WHERE user_id = ? AND video_id = ?
    ");
    $stmt->execute([$userId, $videoId]);
    $exists = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'favorited' => (bool)$exists
    ]);
}

/**
 * 取消收藏
 */
function removeFavorite($db, $userId) {
    $input = json_decode(file_get_contents('php://input'), true);
    $videoId = intval($input['video_id'] ?? 0);
    
    if ($videoId <= 0) {
        throw new Exception('无效的视频ID');
    }
    
    $stmt = $db->prepare("
        DELETE FROM user_favorites 
        WHERE user_id = ? AND video_id = ?
    ");
    $stmt->execute([$userId, $videoId]);
    
    echo json_encode([
        'success' => true,
        'message' => '取消收藏成功'
    ]);
}

/**
 * 创建专属链接
 */
function createCustomLink($db, $userId) {
    // 支持从 POST 表单和 JSON 两种方式接收数据
    $input = $_POST;
    if (empty($input)) {
        $input = json_decode(file_get_contents('php://input'), true);
    }
    
    $customCode = trim($input['custom_code'] ?? '');
    $remark = trim($input['remark'] ?? '');
    
    // 验证自定义代码（只能包含英文或数字，3-15个字符）
    if (!preg_match('/^[a-zA-Z0-9]{3,15}$/', $customCode)) {
        throw new Exception('自定义代码只能包含英文字母或数字，3-15个字符');
    }
    
    // 检查是否已存在
    $stmt = $db->prepare("SELECT id FROM custom_links WHERE custom_code = ?");
    $stmt->execute([$customCode]);
    if ($stmt->fetch()) {
        throw new Exception('该代码已被使用，请换一个');
    }
    
    // 创建链接
    $stmt = $db->prepare("
        INSERT INTO custom_links (user_id, custom_code, remark, created_at, updated_at) 
        VALUES (?, ?, ?, NOW(), NOW())
    ");
    $stmt->execute([$userId, $customCode, $remark]);
    
    echo json_encode([
        'success' => true,
        'message' => '创建成功',
        'link_id' => $db->lastInsertId()
    ]);
}

/**
 * 取消收藏（用于收藏页面）
 */
function unfavoriteVideo($db, $userId) {
    $input = json_decode(file_get_contents('php://input'), true);
    $videoId = intval($input['video_id'] ?? 0);
    
    if ($videoId <= 0) {
        throw new Exception('无效的视频ID');
    }
    
    $stmt = $db->prepare("
        DELETE FROM user_favorites 
        WHERE user_id = ? AND video_id = ?
    ");
    $stmt->execute([$userId, $videoId]);
    
    echo json_encode([
        'success' => true,
        'message' => '取消收藏成功'
    ]);
}

/**
 * 更新专属链接
 */
function updateCustomLink($db, $userId) {
    // 支持从 POST 表单和 JSON 两种方式接收数据
    $input = $_POST;
    if (empty($input)) {
        $input = json_decode(file_get_contents('php://input'), true);
    }
    
    $linkId = intval($input['link_id'] ?? 0);
    $customCode = trim($input['custom_code'] ?? '');
    $videoIds = trim($input['video_ids'] ?? '');
    $remark = trim($input['remark'] ?? '');
    
    if ($linkId <= 0) {
        throw new Exception('无效的链接ID');
    }
    
    // 验证视频ID格式
    if (!empty($videoIds) && !preg_match('/^[0-9,\s]+$/', $videoIds)) {
        throw new Exception('视频ID格式不正确');
    }
    
    // 清理视频ID（去除空格）
    $videoIds = preg_replace('/\s+/', '', $videoIds);
    
    // 验证自定义代码（只能包含英文或数字，3-15个字符）
    if (!preg_match('/^[a-zA-Z0-9]{3,15}$/', $customCode)) {
        throw new Exception('自定义代码只能包含英文字母或数字，3-15个字符');
    }
    
    // 验证所属权
    $stmt = $db->prepare("SELECT custom_code FROM custom_links WHERE id = ? AND user_id = ?");
    $stmt->execute([$linkId, $userId]);
    $oldLink = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$oldLink) {
        throw new Exception('无权限操作');
    }
    
    // 如果修改了custom_code，检查是否已存在
    if ($customCode !== $oldLink['custom_code']) {
        $stmt = $db->prepare("SELECT id FROM custom_links WHERE custom_code = ?");
        $stmt->execute([$customCode]);
        if ($stmt->fetch()) {
            throw new Exception('该代码已被使用，请换一个');
        }
    }
    
    // 更新
    $stmt = $db->prepare("
        UPDATE custom_links 
        SET custom_code = ?, video_ids = ?, remark = ?, updated_at = NOW() 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$customCode, $videoIds, $remark, $linkId, $userId]);
    
    echo json_encode([
        'success' => true,
        'message' => '更新成功'
    ]);
}

/**
 * 删除专属链接
 */
function deleteCustomLink($db, $userId) {
    $input = json_decode(file_get_contents('php://input'), true);
    $linkId = intval($input['link_id'] ?? 0);
    
    if ($linkId <= 0) {
        throw new Exception('无效的链接ID');
    }
    
    $stmt = $db->prepare("
        DELETE FROM custom_links 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$linkId, $userId]);
    
    echo json_encode([
        'success' => true,
        'message' => '删除成功'
    ]);
}



/**
 * 保存系统配置
 */
function saveConfig($db, $userId, $isAdmin) {
    if (!$isAdmin) {
        throw new Exception('无权限操作');
    }
    
    $dbInstance = Database::getInstance();
    
    // 获取配置项
    $configs = [
        'site_title' => $_POST['site_title'] ?? null,
        'site_description' => $_POST['site_description'] ?? null,
        'site_url' => $_POST['site_url'] ?? null,
        'api_url' => $_POST['api_url'] ?? null,
        'guest_parse' => $_POST['guest_parse'] ?? null
    ];
    
    // 保存配置
    foreach ($configs as $key => $value) {
        if ($value !== null) {
            $dbInstance->setSetting($key, $value);
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => '配置保存成功'
    ]);
}

/**
 * 删除视频
 */
function deleteVideo($db, $userId, $isAdmin) {
    if (!$isAdmin) {
        throw new Exception('无权限操作');
    }
    
    $videoId = intval($_POST['video_id'] ?? 0);
    
    if ($videoId <= 0) {
        throw new Exception('无效的视频ID');
    }
    
    // 检查视频是否存在
    $stmt = $db->prepare("SELECT id FROM videos WHERE id = ?");
    $stmt->execute([$videoId]);
    if (!$stmt->fetch()) {
        throw new Exception('视频不存在');
    }
    
    // 开始事务，确保数据一致性
    $db->beginTransaction();
    
    try {
        // 1. 删除user_videos中的记录
        $stmt = $db->prepare("DELETE FROM user_videos WHERE video_id = ?");
        $stmt->execute([$videoId]);
        
        // 2. 删除user_favorites中的收藏记录
        $stmt = $db->prepare("DELETE FROM user_favorites WHERE video_id = ?");
        $stmt->execute([$videoId]);
        
        // 3. 从custom_links的video_ids中移除该视频ID
        $stmt = $db->prepare("SELECT id, video_ids FROM custom_links WHERE video_ids LIKE ?");
        $stmt->execute(['%' . $videoId . '%']);
        $links = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($links as $link) {
            if (empty($link['video_ids'])) continue;
            
            $videoIds = explode(',', $link['video_ids']);
            $videoIds = array_filter($videoIds, function($id) use ($videoId) {
                return intval(trim($id)) != $videoId;
            });
            $newVideoIds = implode(',', $videoIds);
            
            $updateStmt = $db->prepare("UPDATE custom_links SET video_ids = ? WHERE id = ?");
            $updateStmt->execute([$newVideoIds, $link['id']]);
        }
        
        // 4. 删除视频本身
        $stmt = $db->prepare("DELETE FROM videos WHERE id = ?");
        $stmt->execute([$videoId]);
        
        // 提交事务
        $db->commit();
        
        echo json_encode([
            'success' => true,
            'message' => '视频及相关数据删除成功'
        ]);
    } catch (Exception $e) {
        // 回滚事务
        $db->rollBack();
        throw $e;
    }
}

/**
 * 删除用户
 */
function deleteUser($db, $userId, $isAdmin) {
    if (!$isAdmin) {
        throw new Exception('无权限操作');
    }
    
    $username = $_POST['username'] ?? '';
    $deleteVideos = $_POST['delete_videos'] ?? '0';
    
    if (empty($username)) {
        throw new Exception('请输入用户名');
    }
    
    // 检查用户是否存在
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if (!$user) {
        throw new Exception('用户不存在');
    }
    
    $targetUserId = $user['id'];
    
    // 不能删除自己
    if ($targetUserId == $userId) {
        throw new Exception('不能删除自己的账号');
    }
    
    // 开始事务，确保数据一致性
    $db->beginTransaction();
    
    try {
        if ($deleteVideos == '1') {
            // 获取用户的所有视频ID
            $stmt = $db->prepare("SELECT video_id FROM user_videos WHERE user_id = ?");
            $stmt->execute([$targetUserId]);
            $videoIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // 逐个删除视频及其关联数据
            foreach ($videoIds as $videoId) {
                // 删除user_videos记录
                $stmt = $db->prepare("DELETE FROM user_videos WHERE video_id = ?");
                $stmt->execute([$videoId]);
                
                // 删除user_favorites记录
                $stmt = $db->prepare("DELETE FROM user_favorites WHERE video_id = ?");
                $stmt->execute([$videoId]);
                
                // 从custom_links中移除视频ID
                $stmt = $db->prepare("SELECT id, video_ids FROM custom_links WHERE video_ids LIKE ?");
                $stmt->execute(['%' . $videoId . '%']);
                $links = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                foreach ($links as $link) {
                    if (empty($link['video_ids'])) continue;
                    
                    $vids = explode(',', $link['video_ids']);
                    $vids = array_filter($vids, function($id) use ($videoId) {
                        return intval(trim($id)) != $videoId;
                    });
                    $newVideoIds = implode(',', $vids);
                    
                    $updateStmt = $db->prepare("UPDATE custom_links SET video_ids = ? WHERE id = ?");
                    $updateStmt->execute([$newVideoIds, $link['id']]);
                }
                
                // 删除视频本身
                $stmt = $db->prepare("DELETE FROM videos WHERE id = ?");
                $stmt->execute([$videoId]);
            }
        } else {
            // 仅删除user_videos关联，视频变为无主状态
            $stmt = $db->prepare("DELETE FROM user_videos WHERE user_id = ?");
            $stmt->execute([$targetUserId]);
        }
        
        // 删除用户的收藏记录
        $stmt = $db->prepare("DELETE FROM user_favorites WHERE user_id = ?");
        $stmt->execute([$targetUserId]);
        
        // 删除用户的定制链接
        $stmt = $db->prepare("DELETE FROM custom_links WHERE user_id = ?");
        $stmt->execute([$targetUserId]);
        
        // 删除用户
        $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$targetUserId]);
        
        // 提交事务
        $db->commit();
        
        echo json_encode([
            'success' => true,
            'message' => '用户及相关数据删除成功'
        ]);
    } catch (Exception $e) {
        // 回滚事务
        $db->rollBack();
        throw $e;
    }
}

/**
 * 通过视频ID查找用户
 */
function findUserByVideo($db, $userId, $isAdmin) {
    if (!$isAdmin) {
        throw new Exception('无权限操作');
    }
    
    $videoId = intval($_GET['video_id'] ?? 0);
    
    if ($videoId <= 0) {
        throw new Exception('无效的视频ID');
    }
    
    // 检查视频是否存在
    $stmt = $db->prepare("SELECT id FROM videos WHERE id = ?");
    $stmt->execute([$videoId]);
    if (!$stmt->fetch()) {
        throw new Exception('视频不存在');
    }
    
    // 查找视频的作者
    $stmt = $db->prepare("
        SELECT u.username 
        FROM users u
        INNER JOIN user_videos uv ON u.id = uv.user_id
        WHERE uv.video_id = ?
        LIMIT 1
    ");
    $stmt->execute([$videoId]);
    $user = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'data' => [
            'username' => $user['username'] ?? null
        ]
    ]);
}

/**
 * 删除所有视频
 */
function deleteAllVideos($db, $userId, $isAdmin) {
    if (!$isAdmin) {
        throw new Exception('无权限操作');
    }
    
    // 开始事务，确保数据一致性
    $db->beginTransaction();
    
    try {
        // 1. 删除所有user_videos记录
        $db->exec("DELETE FROM user_videos");
        
        // 2. 删除所有user_favorites记录
        $db->exec("DELETE FROM user_favorites");
        
        // 3. 清空所有custom_links的video_ids
        $db->exec("UPDATE custom_links SET video_ids = ''");
        
        // 4. 删除所有视频
        $db->exec("DELETE FROM videos");
        
        // 5. 重置自增ID
        $db->exec("ALTER TABLE videos AUTO_INCREMENT = 1");
        
        // 提交事务
        $db->commit();
        
        echo json_encode([
            'success' => true,
            'message' => '所有视频及相关数据已删除，ID已重置'
        ]);
    } catch (Exception $e) {
        // 回滚事务
        $db->rollBack();
        throw $e;
    }
}



/**
 * 保存存储配置
 */
function saveStorageConfig($db, $userId, $isAdmin) {
    if (!$isAdmin) {
        throw new Exception('无权限操作');
    }
    
    require_once '../r2storage.php';
    $dbInstance = Database::getInstance();
    
    // 保存存储策略
    $strategy = $_POST['storage_strategy'] ?? 'local';
    $dbInstance->setSetting('storage_strategy', $strategy);
    
    // 保存本地存储配置
    if ($strategy === 'local' || $strategy === 'both') {
        $dbInstance->setSetting('local_storage_path', $_POST['local_storage_path'] ?? '/uploads/videos');
        $dbInstance->setSetting('local_storage_url', $_POST['local_storage_url'] ?? '');
    }
    
    // 保存 R2 配置
    if ($strategy === 'r2' || $strategy === 'both') {
        $configs = [
            'r2_endpoint' => $_POST['r2_endpoint'] ?? '',
            'r2_access_key_id' => $_POST['r2_access_key_id'] ?? '',
            'r2_bucket_name' => $_POST['r2_bucket_name'] ?? '',
            'r2_public_url' => $_POST['r2_public_url'] ?? '',
            'r2_storage_path' => $_POST['r2_storage_path'] ?? '/'
        ];
        
        // 直接保存密钥（不加密）
        $secretAccessKey = $_POST['r2_secret_access_key'] ?? '';
        if (!empty($secretAccessKey)) {
            $configs['r2_secret_access_key'] = $secretAccessKey;
        }
        
        // 保存配置
        foreach ($configs as $key => $value) {
            $dbInstance->setSetting($key, $value);
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => '存储配置保存成功'
    ]);
}

/**
 * 测试存储配置
 */
function testStorageConfig($db, $userId, $isAdmin) {
    if (!$isAdmin) {
        throw new Exception('无权限操作');
    }
    
    $strategy = $_POST['storage_strategy'] ?? 'local';
    
    // 本地存储无需测试
    if ($strategy === 'local') {
        echo json_encode([
            'success' => true,
            'message' => '本地存储无需测试'
        ]);
        return;
    }
    
    // 测试 R2 连接
    if ($strategy === 'r2' || $strategy === 'both') {
        require_once '../r2storage.php';
        $dbInstance = Database::getInstance();
        
        // 优先从POST获取配置,如果为空则从数据库读取
        $endpoint = $_POST['r2_endpoint'] ?? $dbInstance->getSetting('r2_endpoint');
        $accessKeyId = $_POST['r2_access_key_id'] ?? $dbInstance->getSetting('r2_access_key_id');
        $bucketName = $_POST['r2_bucket_name'] ?? $dbInstance->getSetting('r2_bucket_name');
        $publicUrl = $_POST['r2_public_url'] ?? $dbInstance->getSetting('r2_public_url');
        
        // 密钥处理:如果POST中有新密钥则使用,否则从数据库读取
        $secretAccessKey = $_POST['r2_secret_access_key'] ?? '';
        if (empty($secretAccessKey)) {
            $secretAccessKey = $dbInstance->getSetting('r2_secret_access_key'); // 直接使用，不解密
        }
        
        if (empty($endpoint) || empty($accessKeyId) || empty($secretAccessKey) || empty($bucketName)) {
            throw new Exception('请填写完整的 R2 配置信息');
        }
        
        // 创建 R2Storage 实例并测试连接
        $r2 = new R2Storage($endpoint, $accessKeyId, $secretAccessKey, $bucketName, $publicUrl);
        $result = $r2->testConnection();
        
        echo json_encode($result);
    }
}



/**
 * 手动备份视频到 R2
 */
function backupVideoManually($db, $userId, $isAdmin) {
    if (!$isAdmin) {
        throw new Exception('无权限操作');
    }
    
    require_once '../video_backup.php';
    
    $videoId = intval($_POST['video_id'] ?? 0);
    
    if ($videoId <= 0) {
        throw new Exception('无效的视频ID');
    }
    
    // 检查视频是否存在
    $stmt = $db->prepare("SELECT id, url FROM videos WHERE id = ?");
    $stmt->execute([$videoId]);
    $video = $stmt->fetch();
    
    if (!$video) {
        throw new Exception('视频不存在');
    }
    
    // 执行备份
    $backup = new VideoBackup();
    
    if (!$backup->isR2Configured()) {
        throw new Exception('R2 存储未配置');
    }
    
    $result = $backup->backupVideo($videoId, $video['url']);
    
    echo json_encode($result);
}

