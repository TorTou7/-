<?php
/**
 * 管理后台页面
 * 仅管理员可访问
 */

// 获取系统统计
$stats = [
    'total_users' => 0,
    'total_videos' => 0,
    'total_views' => 0,
    'total_favorites' => 0
];

$stmt = $db->query("SELECT COUNT(*) as count FROM users");
$stats['total_users'] = $stmt->fetch()['count'];

$stmt = $db->query("SELECT COUNT(*) as count FROM videos");
$stats['total_videos'] = $stmt->fetch()['count'];

$stmt = $db->query("SELECT SUM(views) as total FROM videos");
$result = $stmt->fetch();
$stats['total_views'] = $result['total'] ?? 0;

$stmt = $db->query("SELECT COUNT(*) as count FROM user_favorites");
$stats['total_favorites'] = $stmt->fetch()['count'];

// 获取任务统计
$taskStats = [
    'pending' => 0,
    'processing' => 0,
    'completed' => 0,
    'failed' => 0
];

try {
    $stmt = $db->query("SELECT status, COUNT(*) as count FROM download_tasks GROUP BY status");
    while ($row = $stmt->fetch()) {
        $taskStats[$row['status']] = (int)$row['count'];
    }
} catch (PDOException $e) {
    // 表可能不存在，忽略错误
}

// 获取文件统计
$fileStats = [
    'local_count' => 0,
    'r2_count' => 0,
    'total_count' => 0
];

$strategy = $dbInstance->getSetting('storage_strategy') ?? 'none';

if ($strategy === 'local' || $strategy === 'both') {
    $stmt = $db->query("SELECT COUNT(*) FROM videos WHERE local_path IS NOT NULL AND local_path != ''");
    $fileStats['local_count'] = (int)$stmt->fetchColumn();
}

if ($strategy === 'r2' || $strategy === 'both') {
    $stmt = $db->query("SELECT COUNT(*) FROM videos WHERE r2_path IS NOT NULL AND r2_path != ''");
    $fileStats['r2_count'] = (int)$stmt->fetchColumn();
}

if ($strategy === 'both') {
    $fileStats['total_count'] = max($fileStats['local_count'], $fileStats['r2_count']);
} else {
    $fileStats['total_count'] = $fileStats['local_count'] + $fileStats['r2_count'];
}

// 获取系统配置
$dbInstance = Database::getInstance();
$siteTitle = $dbInstance->getSetting('site_title') ?? '视频去水印解析系统';
$siteDesc = $dbInstance->getSetting('site_description') ?? '专业的视频去水印解析服务';
$siteUrl = $dbInstance->getSetting('site_url') ?? 'http://' . $_SERVER['HTTP_HOST'];
$apiUrl = $dbInstance->getSetting('api_url') ?? '';
$guestParse = $dbInstance->getSetting('guest_parse') ?? '1'; // 1=允许游客，0=需要登录
?>

<style>
/* 警告提示样式 */
.admin-warning {
    background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
    color: #fff;
    padding: 20px;
    border: 3px solid #333;
    box-shadow: 6px 6px 0 #333;
    margin-bottom: 30px;
}

.admin-warning h3 {
    margin: 0 0 10px 0;
    font-size: 18px;
    font-weight: 700;
}

.admin-warning p {
    margin: 0;
    font-size: 14px;
    opacity: 0.95;
}

/* 系统统计样式 */
.section-title {
    font-size: 20px;
    font-weight: 700;
    color: #333;
    margin: 0 0 20px 0;
    padding-bottom: 10px;
    border-bottom: 3px solid #333;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}

.stat-card {
    background: #fff;
    padding: 24px;
    text-align: center;
    transition: all 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-4px);
}

.stat-card .icon {
    width: 60px;
    height: 60px;
    margin: 0 auto 16px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 24px;
}

.stat-card .number {
    font-size: 32px;
    font-weight: 700;
    color: #333;
    margin: 0 0 8px 0;
}

.stat-card .label {
    font-size: 14px;
    color: #666;
    margin: 0;
}

/* 配置功能样式 */
.config-section {
    margin-bottom: 40px;
}

.config-form {
    background: #fff;
    padding: 30px;
}

.form-group {
    margin-bottom: 24px;
}

.form-group label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #333;
    margin-bottom: 8px;
}

.form-group input[type="text"],
.form-group textarea {
    width: 100%;
    padding: 12px;
    font-size: 14px;
    border: 2px solid #333;
    background: #fff;
    box-sizing: border-box;
}

.form-group input[type="text"]:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #667eea;
}

.form-group small {
    display: block;
    margin-top: 6px;
    font-size: 12px;
    color: #666;
}

.form-actions {
    display: flex;
    gap: 12px;
    margin-top: 24px;
}

.btn-save {
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 600;
    border: 2px solid #333;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-save:hover {
    transform: translateY(-2px);
    box-shadow: 4px 4px 0 #333;
}

/* 内容管理样式 */
.content-section {
    margin-bottom: 40px;
}

.management-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.management-card {
    background: #fff;
    padding: 24px;
}

.management-card h4 {
    font-size: 16px;
    font-weight: 700;
    color: #333;
    margin: 0 0 16px 0;
}

.management-card .form-row {
    display: flex;
    gap: 12px;
    margin-bottom: 12px;
}

.management-card .form-row input {
    flex: 1;
    padding: 10px;
    font-size: 14px;
    border: 2px solid #333;
}

.management-card .form-row button {
    padding: 10px 20px;
    font-size: 14px;
    font-weight: 600;
    border: 2px solid #333;
    background: #fff;
    cursor: pointer;
    transition: all 0.3s ease;
}

.management-card .form-row button:hover {
    background: #333;
    color: #fff;
}

.management-card .checkbox-group {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 12px;
}

.management-card .checkbox-group input[type="checkbox"] {
    width: 18px;
    height: 18px;
}

.management-card .checkbox-group label {
    font-size: 14px;
    color: #333;
    margin: 0;
}

.management-card .result-box {
    margin-top: 16px;
    padding: 12px;
    background: #f5f5f5;
    border: 2px solid #333;
    font-size: 14px;
    color: #333;
    display: none;
}

.management-card .result-box.show {
    display: block;
}

.management-card .result-box.success {
    background: #d4edda;
    border-color: #28a745;
    color: #155724;
}

.management-card .result-box.error {
    background: #f8d7da;
    border-color: #dc3545;
    color: #721c24;
}

.danger-card {
    border-color: #dc3545;
    box-shadow: 6px 6px 0 #dc3545;
}

.danger-card h4 {
    color: #dc3545;
}

.btn-danger {
    background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
    color: #fff;
    border-color: #dc3545;
}

.btn-danger:hover {
    box-shadow: 4px 4px 0 #dc3545;
}

/* 游客解析开关样式 */
.switch-group {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
}

.switch {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 26px;
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    border: 2px solid #333;
    transition: .4s;
}

.slider:before {
    position: absolute;
    content: "";
    height: 18px;
    width: 18px;
    left: 2px;
    bottom: 2px;
    background-color: white;
    transition: .4s;
}

input:checked + .slider {
    background-color: #667eea;
}

input:checked + .slider:before {
    transform: translateX(24px);
}

.switch-label {
    font-size: 14px;
    font-weight: 600;
    color: #333;
}

/* 响应式设计 */
@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .management-grid {
        grid-template-columns: 1fr;
    }
    
    .form-actions {
        flex-direction: column;
    }
    
    .btn-save {
        width: 100%;
    }
}

/* 深色主题适配 */
[data-theme="dark"] .section-title {
    color: #e0e0e0;
    border-bottom-color: #444444;
}

[data-theme="dark"] .stat-card {
    background: #2a2a2a;
}

[data-theme="dark"] .stat-card:hover {
    /* no shadow */
}

[data-theme="dark"] .stat-card .number {
    color: #e0e0e0;
}

[data-theme="dark"] .stat-card .label {
    color: #999999;
}

[data-theme="dark"] .config-form {
    background: #2a2a2a;
}

[data-theme="dark"] .form-group label {
    color: #e0e0e0;
}

[data-theme="dark"] .form-group input[type="text"],
[data-theme="dark"] .form-group textarea {
    background: #1a1a1a;
    border-color: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .form-group input[type="text"]:focus,
[data-theme="dark"] .form-group textarea:focus {
    border-color: #667eea;
}

[data-theme="dark"] .form-group small {
    color: #666666;
}

[data-theme="dark"] .management-card {
    background: #2a2a2a;
}

[data-theme="dark"] .management-card h4 {
    color: #e0e0e0;
}

[data-theme="dark"] .management-card .form-row input {
    background: #1a1a1a;
    border-color: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .management-card .form-row button {
    background: #2a2a2a;
    border-color: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .management-card .form-row button:hover {
    background: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .management-card .checkbox-group label {
    color: #e0e0e0;
}

[data-theme="dark"] .management-card .result-box {
    background: #1a1a1a;
    border-color: #444444;
    color: #e0e0e0;
}
</style>

<!-- 警告提示 -->
<div class="admin-warning">
    <h3><i class="fas fa-exclamation-triangle"></i> 管理后台</h3>
    <p><strong>警告：</strong>您正在访问管理后台，请谨慎操作，避免误删重要数据。</p>
</div>

<!-- 系统统计 -->
<div class="stats-section">
    <h3 class="section-title">系统统计</h3>
    <div class="stats-grid">
        <div class="stat-card">
            <div class="icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="number"><?php echo $stats['total_users']; ?></div>
            <div class="label">注册用户</div>
        </div>
        <div class="stat-card">
            <div class="icon">
                <i class="fas fa-video"></i>
            </div>
            <div class="number"><?php echo $stats['total_videos']; ?></div>
            <div class="label">视频总数</div>
        </div>
        <div class="stat-card">
            <div class="icon">
                <i class="fas fa-eye"></i>
            </div>
            <div class="number"><?php echo $stats['total_views']; ?></div>
            <div class="label">总浏览量</div>
        </div>
        <div class="stat-card">
            <div class="icon">
                <i class="fas fa-heart"></i>
            </div>
            <div class="number"><?php echo $stats['total_favorites']; ?></div>
            <div class="label">收藏数</div>
        </div>
        <div class="stat-card">
            <div class="icon">
                <i class="fas fa-tasks"></i>
            </div>
            <div class="number"><?php echo $taskStats['pending'] + $taskStats['processing']; ?></div>
            <div class="label">待处理任务</div>
            <small style="font-size: 12px; color: #666; margin-top: 4px; display: block;">
                处理中: <?php echo $taskStats['processing']; ?> | 待处理: <?php echo $taskStats['pending']; ?>
            </small>
        </div>
        <?php if ($strategy !== 'none'): ?>
        <div class="stat-card">
            <div class="icon">
                <i class="fas fa-database"></i>
            </div>
            <div class="number"><?php echo $fileStats['total_count']; ?></div>
            <div class="label">
                <?php 
                if ($strategy === 'local') {
                    echo '本地文件';
                } elseif ($strategy === 'r2') {
                    echo 'R2文件';
                } else {
                    echo '总文件数';
                }
                ?>
            </div>
            <?php if ($strategy === 'both'): ?>
            <small style="font-size: 12px; color: #666; margin-top: 4px; display: block;">
                本地: <?php echo $fileStats['local_count']; ?> | R2: <?php echo $fileStats['r2_count']; ?>
            </small>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- 配置功能 -->
<div class="config-section">
    <h3 class="section-title">配置功能</h3>
    <div class="config-form">
        <form id="configForm">
            <div class="form-group">
                <label for="siteTitle">网站标题</label>
                <input type="text" id="siteTitle" name="site_title" value="<?php echo htmlspecialchars($siteTitle); ?>" placeholder="例如: 视频去水印解析系统">
                <small>网站的主标题，显示在浏览器标签和页面顶部</small>
            </div>
            
            <div class="form-group">
                <label for="siteDesc">网站描述</label>
                <textarea id="siteDesc" name="site_description" rows="3" placeholder="例如: 专业的视频去水印解析服务"><?php echo htmlspecialchars($siteDesc); ?></textarea>
                <small>网站的简短描述，用于SEO和页面介绍</small>
            </div>
            
            <div class="form-group">
                <label for="siteUrl">网站链接</label>
                <input type="text" id="siteUrl" name="site_url" value="<?php echo htmlspecialchars($siteUrl); ?>" placeholder="例如: http://cc.ziyuanqu.com">
                <small>网站的完整URL地址，用于生成专属定制链接</small>
            </div>
            
            <div class="form-group">
                <label for="apiUrl">API地址</label>
                <input type="text" id="apiUrl" name="api_url" value="<?php echo htmlspecialchars($apiUrl); ?>" placeholder="例如: https://api.example.com/parse">
                <small>视频解析API的完整地址</small>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-save">
                    <i class="fas fa-save"></i> 保存配置
                </button>
            </div>
        </form>
    </div>
</div>

<!-- R2 对象存储配置 -->
<div class="config-section">
    <h3 class="section-title"><i class="fas fa-save"></i> 视频存储配置</h3>
    <div class="config-form">
        <form id="storageConfigForm">
            <!-- 存储策略选择 -->
            <div class="form-group">
                <label>存储策略</label>
                <select id="storageStrategy" name="storage_strategy" onchange="toggleStorageConfig()" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="none" <?php echo ($dbInstance->getSetting('storage_strategy') ?? 'none') == 'none' ? 'selected' : ''; ?>>不保存（默认）</option>
                    <option value="local" <?php echo ($dbInstance->getSetting('storage_strategy') ?? 'none') == 'local' ? 'selected' : ''; ?>>仅本地存储</option>
                    <option value="r2" <?php echo ($dbInstance->getSetting('storage_strategy') ?? 'none') == 'r2' ? 'selected' : ''; ?>>仅 R2 存储</option>
                    <option value="both" <?php echo ($dbInstance->getSetting('storage_strategy') ?? 'none') == 'both' ? 'selected' : ''; ?>>本地 + R2 双重存储</option>
                </select>
                <small style="color: #666;">
                    <strong>不保存</strong>: 不下载视频，直接使用API返回的地址<br>
                    <strong>仅本地</strong>: 视频保存在服务器本地<br>
                    <strong>仅 R2</strong>: 视频上传到 Cloudflare R2，不占用本地空间<br>
                    <strong>双重存储</strong>: 同时保存到本地和 R2，播放优先使用R2
                </small>
            </div>
            
            <!-- 本地存储配置 -->
            <div id="localStorageConfig" style="display: none;">
                <h4 style="margin: 20px 0 10px 0; color: #333;"><i class="fas fa-hdd"></i> 本地存储配置</h4>
                <div class="form-group">
                    <label for="localStoragePath">存储路径</label>
                    <input type="text" id="localStoragePath" name="local_storage_path" value="<?php echo htmlspecialchars($dbInstance->getSetting('local_storage_path') ?? '/uploads'); ?>" placeholder="例如: /uploads/{Y}/{m}/{d}">
                    <small>相对于网站根目录的路径，支持年月日变量: {Y}年 {m}月 {d}日，不输入或/为根目录</small>
                </div>
            </div>
            
            <!-- R2 存储配置 -->
            <div id="r2StorageConfig" style="display: none;">
                <h4 style="margin: 20px 0 10px 0; color: #333;"><i class="fas fa-cloud"></i> Cloudflare R2 配置</h4>
                
            <div class="form-group">
                <label for="r2BucketName">存储桶名称</label>
                <input type="text" id="r2BucketName" name="r2_bucket_name" value="<?php echo htmlspecialchars($dbInstance->getSetting('r2_bucket_name') ?? ''); ?>" placeholder="例如: maopx">
                <small>R2 存储桶的名称</small>
            </div>
            
            <div class="form-group">
                <label for="r2Endpoint">端点URL</label>
                <input type="text" id="r2Endpoint" name="r2_endpoint" value="<?php echo htmlspecialchars($dbInstance->getSetting('r2_endpoint') ?? ''); ?>" placeholder="例如: https://xxx.r2.cloudflarestorage.com">
                <small>Cloudflare R2 的端点地址，在 R2 控制台查看</small>
            </div>
            
            <div class="form-group">
                <label for="r2AccessKeyId">访问密钥ID</label>
                <input type="text" id="r2AccessKeyId" name="r2_access_key_id" value="<?php echo htmlspecialchars($dbInstance->getSetting('r2_access_key_id') ?? ''); ?>" placeholder="例如: 48f02f5a90fc5a53971958a21bac31aa">
                <small>R2 API Token 的 Access Key ID</small>
            </div>
            
            <div class="form-group">
                <label for="r2SecretAccessKey">访问密钥</label>
                <input type="password" id="r2SecretAccessKey" name="r2_secret_access_key" value="<?php echo htmlspecialchars($dbInstance->getSetting('r2_secret_access_key') ?? ''); ?>" placeholder="输入密钥" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
                <small>R2 API Token 的 Secret Access Key（加密存储）</small>
            </div>
            
            <div class="form-group">
                <label for="r2PublicUrl">存储桶公开URL</label>
                <input type="text" id="r2PublicUrl" name="r2_public_url" value="<?php echo htmlspecialchars($dbInstance->getSetting('r2_public_url') ?? ''); ?>" placeholder="例如: https://sp.miaopix.com">
                <small>R2 存储桶的公开访问域名（需要在 Cloudflare 配置自定义域名）</small>
            </div>
            
            <div class="form-group">
                <label for="r2StoragePath">R2存储路径</label>
                <input type="text" id="r2StoragePath" name="r2_storage_path" value="<?php echo htmlspecialchars($dbInstance->getSetting('r2_storage_path') ?? '/'); ?>" placeholder="例如: /{Y}/{m}/{d}">
                <small>支持年月日变量: {Y}年 {m}月 {d}日，不输入或/为根目录</small>
            </div>
            
            </div>
            
            
            <div class="form-actions">
                <button type="button" id="testStorageBtn" onclick="testStorageConnection()" class="btn-test" style="background: #17a2b8; color: #fff; margin-right: 10px;">
                    <i class="fas fa-plug"></i> 测试配置
                </button>
                <button type="submit" class="btn-save">
                    <i class="fas fa-save"></i> 保存配置
                </button>
            </div>
            <div id="storageTestResult" class="result-box"></div>
        </form>
    </div>
</div>

<!-- 内容管理 -->
<div class="content-section">
    <h3 class="section-title">内容管理</h3>
    <div class="management-grid">
        <!-- 游客登录解析 -->
        <div class="management-card">
            <h4><i class="fas fa-user-shield"></i> 游客登录解析</h4>
            <div class="switch-group">
                <label class="switch">
                    <input type="checkbox" id="guestParseSwitch" <?php echo $guestParse == '1' ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
                <span class="switch-label">允许游客解析视频</span>
            </div>
            <small style="color: #666;">开启后，游客无需登录即可解析视频；关闭后，需要登录才能解析。</small>
        </div>
        
        <!-- 删除视频 -->
        <div class="management-card">
            <h4><i class="fas fa-trash"></i> 删除视频</h4>
            <div class="form-row">
                <input type="number" id="deleteVideoId" placeholder="输入视频ID">
                <button onclick="deleteVideo()">删除</button>
            </div>
            <small style="color: #666;">从数据库中删除指定ID的视频</small>
            <div id="deleteVideoResult" class="result-box"></div>
        </div>
        
        <!-- 删除用户 -->
        <div class="management-card">
            <h4><i class="fas fa-user-times"></i> 删除用户</h4>
            <div class="form-row">
                <input type="text" id="deleteUsername" placeholder="输入用户名">
                <button onclick="deleteUser()">删除</button>
            </div>
            <div class="checkbox-group">
                <input type="checkbox" id="deleteUserVideos">
                <label for="deleteUserVideos">同时删除该用户下所有视频</label>
            </div>
            <small style="color: #666;">不选择则仅删除用户，该用户下的视频为无主状态</small>
            <div id="deleteUserResult" class="result-box"></div>
        </div>
        
        <!-- 查找用户 -->
        <div class="management-card">
            <h4><i class="fas fa-search"></i> 查找用户</h4>
            <div class="form-row">
                <input type="number" id="findVideoId" placeholder="输入视频ID">
                <button onclick="findUserByVideo()">查找</button>
            </div>
            <small style="color: #666;">通过视频ID查找对应的用户名</small>
            <div id="findUserResult" class="result-box"></div>
        </div>
        
        <!-- 视频备份管理 -->
        <div class="management-card">
            <h4><i class="fas fa-cloud-upload-alt"></i> 视频备份管理</h4>
            <div class="form-row">
                <input type="number" id="backupVideoId" placeholder="输入视频ID">
                <button onclick="backupVideo()">备份到 R2</button>
            </div>
            <small style="color: #666;">手动将指定视频备份到 R2 存储</small>
            <div id="backupVideoResult" class="result-box"></div>
        </div>
        
        <!-- 删除所有视频 -->
        <div class="management-card danger-card">
            <h4><i class="fas fa-exclamation-triangle"></i> 删除所有视频</h4>
            <p style="color: #dc3545; font-size: 14px; margin-bottom: 12px;">
                <strong>危险操作！</strong>删除所有视频数据并重置ID，此操作不可恢复！
            </p>
            <div class="checkbox-group">
                <input type="checkbox" id="confirmDeleteAll">
                <label for="confirmDeleteAll">我确认要删除所有视频</label>
            </div>
            <button onclick="deleteAllVideos()" class="btn-danger" style="width: 100%; margin-top: 12px;">
                <i class="fas fa-trash-alt"></i> 删除所有视频
            </button>
            <div id="deleteAllResult" class="result-box"></div>
        </div>
    </div>
</div>

<script>
// 保存配置
document.getElementById('configForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    try {
        const response = await fetch('/user/api.php?action=save_config', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('配置保存成功！');
        } else {
            alert('保存失败：' + (result.message || '未知错误'));
        }
    } catch (error) {
        alert('保存失败：' + error.message);
    }
});

// 游客解析开关
document.getElementById('guestParseSwitch').addEventListener('change', async function() {
    const value = this.checked ? '1' : '0';
    
    try {
        const response = await fetch('/user/api.php?action=save_config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'guest_parse=' + value
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert(this.checked ? '已允许游客解析视频' : '已禁止游客解析视频');
        } else {
            alert('设置失败：' + (result.message || '未知错误'));
            this.checked = !this.checked; // 恢复原状态
        }
    } catch (error) {
        alert('设置失败：' + error.message);
        this.checked = !this.checked; // 恢复原状态
    }
});

// 删除视频
async function deleteVideo() {
    const videoId = document.getElementById('deleteVideoId').value;
    const resultBox = document.getElementById('deleteVideoResult');
    
    if (!videoId) {
        showResult(resultBox, '请输入视频ID', 'error');
        return;
    }
    
    if (!confirm('确定要删除视频ID: ' + videoId + ' 吗？')) {
        return;
    }
    
    try {
        const response = await fetch('/user/api.php?action=delete_video', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'video_id=' + videoId
        });
        
        const result = await response.json();
        
        if (result.success) {
            showResult(resultBox, '视频删除成功！', 'success');
            document.getElementById('deleteVideoId').value = '';
        } else {
            showResult(resultBox, '删除失败：' + (result.message || '未知错误'), 'error');
        }
    } catch (error) {
        showResult(resultBox, '删除失败：' + error.message, 'error');
    }
}

// 删除用户
async function deleteUser() {
    const username = document.getElementById('deleteUsername').value;
    const deleteVideos = document.getElementById('deleteUserVideos').checked;
    const resultBox = document.getElementById('deleteUserResult');
    
    if (!username) {
        showResult(resultBox, '请输入用户名', 'error');
        return;
    }
    
    const confirmMsg = deleteVideos 
        ? '确定要删除用户 "' + username + '" 及其所有视频吗？'
        : '确定要删除用户 "' + username + '" 吗？（该用户的视频将变为无主状态）';
    
    if (!confirm(confirmMsg)) {
        return;
    }
    
    try {
        const response = await fetch('/user/api.php?action=delete_user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'username=' + encodeURIComponent(username) + '&delete_videos=' + (deleteVideos ? '1' : '0')
        });
        
        const result = await response.json();
        
        if (result.success) {
            showResult(resultBox, '用户删除成功！', 'success');
            document.getElementById('deleteUsername').value = '';
            document.getElementById('deleteUserVideos').checked = false;
        } else {
            showResult(resultBox, '删除失败：' + (result.message || '未知错误'), 'error');
        }
    } catch (error) {
        showResult(resultBox, '删除失败：' + error.message, 'error');
    }
}

// 查找用户
async function findUserByVideo() {
    const videoId = document.getElementById('findVideoId').value;
    const resultBox = document.getElementById('findUserResult');
    
    if (!videoId) {
        showResult(resultBox, '请输入视频ID', 'error');
        return;
    }
    
    try {
        const response = await fetch('/user/api.php?action=find_user_by_video&video_id=' + videoId);
        const result = await response.json();
        
        if (result.success) {
            if (result.data.username) {
                showResult(resultBox, '视频ID ' + videoId + ' 的作者是：' + result.data.username, 'success');
            } else {
                showResult(resultBox, '该视频还未被认领！', 'error');
            }
        } else {
            showResult(resultBox, '查找失败：' + (result.message || '未知错误'), 'error');
        }
    } catch (error) {
        showResult(resultBox, '查找失败：' + error.message, 'error');
    }
}

// 删除所有视频
async function deleteAllVideos() {
    const confirmed = document.getElementById('confirmDeleteAll').checked;
    const resultBox = document.getElementById('deleteAllResult');
    
    if (!confirmed) {
        showResult(resultBox, '请先勾选确认框', 'error');
        return;
    }
    
    if (!confirm('最后确认：确定要删除所有视频吗？此操作不可恢复！')) {
        return;
    }
    
    try {
        const response = await fetch('/user/api.php?action=delete_all_videos', {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (result.success) {
            showResult(resultBox, '所有视频已删除，ID已重置！', 'success');
            document.getElementById('confirmDeleteAll').checked = false;
            // 刷新页面以更新统计数据
            setTimeout(() => location.reload(), 2000);
        } else {
            showResult(resultBox, '删除失败：' + (result.message || '未知错误'), 'error');
        }
    } catch (error) {
        showResult(resultBox, '删除失败：' + error.message, 'error');
    }
}

// 存储策略切换
function toggleStorageConfig() {
    const strategy = document.getElementById('storageStrategy').value;
    const localConfig = document.getElementById('localStorageConfig');
    const r2Config = document.getElementById('r2StorageConfig');
    const testBtn = document.getElementById('testStorageBtn');
    
    if (strategy === 'none') {
        localConfig.style.display = 'none';
        r2Config.style.display = 'none';
        testBtn.style.display = 'none';
    } else if (strategy === 'local') {
        localConfig.style.display = 'block';
        r2Config.style.display = 'none';
        testBtn.style.display = 'none';
    } else if (strategy === 'r2') {
        localConfig.style.display = 'none';
        r2Config.style.display = 'block';
        testBtn.style.display = 'inline-block';
    } else if (strategy === 'both') {
        localConfig.style.display = 'block';
        r2Config.style.display = 'block';
        testBtn.style.display = 'inline-block';
    }
}

// 页面加载时初始化显示
window.addEventListener('DOMContentLoaded', function() {
    toggleStorageConfig();
});

// 保存存储配置
document.getElementById('storageConfigForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    try {
        const response = await fetch('/user/api.php?action=save_storage_config', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('存储配置保存成功！');
        } else {
            alert('保存失败：' + (result.message || '未知错误'));
        }
    } catch (error) {
        alert('保存失败：' + error.message);
    }
});

// 手动备份视频
async function backupVideo() {
    const videoId = document.getElementById('backupVideoId').value;
    const resultBox = document.getElementById('backupVideoResult');
    
    if (!videoId) {
        showResult(resultBox, '请输入视频ID', 'error');
        return;
    }
    
    showResult(resultBox, '正在备份视频...', 'info');
    
    try {
        const response = await fetch('/user/api.php?action=backup_video', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'video_id=' + videoId
        });
        
        const result = await response.json();
        
        if (result.success) {
            showResult(resultBox, '视频备份成功！', 'success');
            document.getElementById('backupVideoId').value = '';
        } else {
            showResult(resultBox, '备份失败：' + (result.message || '未知错误'), 'error');
        }
    } catch (error) {
        showResult(resultBox, '备份失败：' + error.message, 'error');
    }
}

// 测试存储配置
async function testStorageConnection() {
    const resultBox = document.getElementById('storageTestResult');
    const strategy = document.getElementById('storageStrategy').value;
    const formData = new FormData(document.getElementById('storageConfigForm'));
    
    // 根据策略检查必填项
    if (strategy === 'local') {
        const localPath = document.getElementById('localStoragePath').value;
        if (!localPath) {
            showResult(resultBox, '请填写本地存储路径', 'error');
            return;
        }
        showResult(resultBox, '本地存储无需测试，请直接保存配置', 'info');
        return;
    }
    
    if (strategy === 'r2' || strategy === 'both') {
        const endpoint = document.getElementById('r2Endpoint').value;
        const accessKeyId = document.getElementById('r2AccessKeyId').value;
        const secretAccessKey = document.getElementById('r2SecretAccessKey').value;
        const bucketName = document.getElementById('r2BucketName').value;
        
        if (!endpoint || !accessKeyId || !secretAccessKey || !bucketName) {
            showResult(resultBox, '请填写完整的 R2 配置信息', 'error');
            return;
        }
    }
    
    showResult(resultBox, '正在测试连接...', 'info');
    
    try {
        const response = await fetch('/user/api.php?action=test_storage_config', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            showResult(resultBox, '配置测试成功！', 'success');
        } else {
            showResult(resultBox, '测试失败：' + (result.message || '未知错误'), 'error');
        }
    } catch (error) {
        showResult(resultBox, '测试失败：' + error.message, 'error');
    }
}

// 显示结果
function showResult(element, message, type) {
    element.textContent = message;
    element.className = 'result-box show ' + type;
    setTimeout(() => {
        element.className = 'result-box';
    }, 5000);
}
</script>

