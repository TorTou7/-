<?php
/**
 * 专属定制页面
 * 用户可以创建自定义视频库链接
 */

// 获取网站链接配置
$dbInstance = Database::getInstance();
$websiteUrl = $dbInstance->getSetting('site_url', 'http://' . $_SERVER['HTTP_HOST']);
$websiteUrl = rtrim($websiteUrl, '/');

// 获取用户的定制链接列表
$stmt = $db->prepare("
    SELECT id, custom_code, remark, video_ids, created_at, updated_at
    FROM custom_links
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$stmt->execute([$userId]);
$customLinks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
/* 页面标题样式 */
.page-title-custom {
    margin-bottom: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.page-title-custom h2 {
    font-size: 24px;
    font-weight: 700;
    color: #333;
    margin: 0;
}

.page-title-custom .btn-create {
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 600;
    border: 2px solid #333;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    cursor: pointer;
    transition: all 0.3s ease;
}

.page-title-custom .btn-create:hover {
    transform: translateY(-2px);
    box-shadow: 4px 4px 0 #333;
}

/* 链接列表样式 */
.custom-links-list {
    background: #fff;
    border: 3px solid #333;
    box-shadow: 6px 6px 0 #333;
}

.custom-link-item {
    padding: 20px;
    border-bottom: 2px solid #e0e0e0;
    transition: background 0.3s ease;
}

.custom-link-item:last-child {
    border-bottom: none;
}

.custom-link-item:hover {
    background: #f8f9fa;
}

.custom-link-item .link-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.custom-link-item .link-title {
    font-size: 18px;
    font-weight: 700;
    color: #333;
    margin: 0;
}

.custom-link-item .link-actions {
    display: flex;
    gap: 10px;
}

.custom-link-item .action-btn {
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    border: 2px solid #333;
    background: #fff;
    color: #333;
    cursor: pointer;
    transition: all 0.3s ease;
}

.custom-link-item .action-btn:hover {
    background: #333;
    color: #fff;
}

.custom-link-item .action-btn.delete-btn {
    border-color: #dc3545;
    color: #dc3545;
}

.custom-link-item .action-btn.delete-btn:hover {
    background: #dc3545;
    color: #fff;
}

.custom-link-item .link-url {
    font-size: 14px;
    color: #667eea;
    margin-bottom: 10px;
    word-break: break-all;
}

.custom-link-item .link-info {
    font-size: 13px;
    color: #999;
}

/* 空状态样式 */
.empty-state-custom {
    text-align: center;
    padding: 60px 20px;
}

.empty-state-custom i {
    font-size: 64px;
    color: #ccc;
    margin-bottom: 20px;
}

.empty-state-custom h3 {
    font-size: 20px;
    font-weight: 600;
    color: #666;
    margin: 0 0 10px 0;
}

.empty-state-custom p {
    font-size: 14px;
    color: #999;
    margin: 0;
}

/* 模态框样式 */
.modal-custom {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 9999;
    justify-content: center;
    align-items: center;
}

.modal-custom .modal-content {
    background: #fff;
    border: 3px solid #333;
    box-shadow: 8px 8px 0 #333;
    width: 90%;
    max-width: 600px;
    max-height: 80vh;
    overflow-y: auto;
}

.modal-custom .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    border-bottom: 2px solid #e0e0e0;
}

.modal-custom .modal-header h3 {
    font-size: 20px;
    font-weight: 700;
    color: #333;
    margin: 0;
}

.modal-custom .modal-close {
    font-size: 28px;
    font-weight: 700;
    color: #999;
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
    width: 32px;
    height: 32px;
    line-height: 32px;
    text-align: center;
}

.modal-custom .modal-close:hover {
    color: #333;
}

.modal-custom .modal-body {
    padding: 20px;
}

.modal-custom .form-group {
    margin-bottom: 20px;
}

.modal-custom .form-group label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #333;
    margin-bottom: 8px;
}

.modal-custom .form-group input,
.modal-custom .form-group textarea {
    width: 100%;
    padding: 12px 15px;
    font-size: 14px;
    border: 2px solid #ddd;
    background: #fff;
    transition: all 0.3s ease;
    box-sizing: border-box;
}

.modal-custom .form-group input:focus,
.modal-custom .form-group textarea:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.modal-custom .form-group small {
    display: block;
    font-size: 12px;
    color: #999;
    margin-top: 6px;
}

.modal-custom .form-group textarea {
    min-height: 100px;
    resize: vertical;
}

.modal-custom .form-actions {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

.modal-custom .btn {
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 600;
    border: 2px solid #333;
    background: #fff;
    color: #333;
    cursor: pointer;
    transition: all 0.3s ease;
}

.modal-custom .btn:hover {
    background: #333;
    color: #fff;
}

.modal-custom .btn.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-color: #667eea;
    color: #fff;
}

.modal-custom .btn.btn-primary:hover {
    background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    transform: translateY(-2px);
    box-shadow: 4px 4px 0 #333;
}

/* 消息提示样式 */
.message-box {
    padding: 12px 15px;
    border-radius: 4px;
    margin-bottom: 15px;
    font-size: 14px;
}

.message-box.success {
    background: #d4edda;
    color: #155724;
    border: 2px solid #c3e6cb;
}

.message-box.error {
    background: #f8d7da;
    color: #721c24;
    border: 2px solid #f5c6cb;
}

.message-box i {
    margin-right: 8px;
}

/* 响应式设计 */
@media (max-width: 768px) {
    .page-title-custom {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }
    
    .custom-link-item .link-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
    
    .custom-link-item .link-actions {
        width: 100%;
    }
}

/* 深色主题适配 */
[data-theme="dark"] .page-title-custom h2 {
    color: #e0e0e0;
}

[data-theme="dark"] .custom-links-list {
    background: #2a2a2a;
    border-color: #444444;
    box-shadow: 6px 6px 0 #444444;
}

[data-theme="dark"] .custom-link-item {
    border-bottom-color: #444444;
}

[data-theme="dark"] .custom-link-item:hover {
    background: #333333;
}

[data-theme="dark"] .custom-link-item .link-title {
    color: #e0e0e0;
}

[data-theme="dark"] .custom-link-item .action-btn {
    background: #2a2a2a;
    border-color: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .custom-link-item .action-btn:hover {
    background: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .custom-link-item .link-info {
    color: #666666;
}

[data-theme="dark"] .empty-state-custom i {
    color: #444444;
}

[data-theme="dark"] .empty-state-custom h3 {
    color: #999999;
}

[data-theme="dark"] .empty-state-custom p {
    color: #666666;
}

[data-theme="dark"] .modal-custom .modal-content {
    background: #2a2a2a;
    border-color: #444444;
    box-shadow: 8px 8px 0 #444444;
}

[data-theme="dark"] .modal-custom .modal-header {
    border-bottom-color: #444444;
}

[data-theme="dark"] .modal-custom .modal-header h3 {
    color: #e0e0e0;
}

[data-theme="dark"] .modal-custom .modal-close {
    color: #666666;
}

[data-theme="dark"] .modal-custom .modal-close:hover {
    color: #e0e0e0;
}

[data-theme="dark"] .modal-custom .form-group label {
    color: #e0e0e0;
}

[data-theme="dark"] .modal-custom .form-group input,
[data-theme="dark"] .modal-custom .form-group textarea {
    background: #1a1a1a;
    border-color: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .modal-custom .form-group input:focus,
[data-theme="dark"] .modal-custom .form-group textarea:focus {
    border-color: #667eea;
    background: #1a1a1a;
}

[data-theme="dark"] .modal-custom .form-group small {
    color: #666666;
}

[data-theme="dark"] .modal-custom .btn {
    background: #2a2a2a;
    border-color: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .modal-custom .btn:hover {
    background: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .message-box.success {
    background: #1a3a1a;
    color: #90ee90;
    border-color: #2a5a2a;
}

[data-theme="dark"] .message-box.error {
    background: #3a1a1a;
    color: #ff9999;
    border-color: #5a2a2a;
}
</style>

<div class="page-title-custom">
    <h2><i class="fas fa-magic"></i> 定制专属视频库</h2>
    <button class="btn-create" onclick="showCreateModal()">
        <i class="fas fa-plus"></i> 创建新链接
    </button>
</div>

<?php if (empty($customLinks)): ?>
<div class="custom-links-list">
    <div class="empty-state-custom">
        <i class="fas fa-magic"></i>
        <h3>还没有创建定制链接</h3>
        <p>点击上方按钮创建您的第一个专属视频库链接</p>
    </div>
</div>
<?php else: ?>
<div class="custom-links-list">
    <?php foreach ($customLinks as $link): ?>
    <div class="custom-link-item">
        <div class="link-header">
            <h3 class="link-title"><?php echo htmlspecialchars($link['remark'] ?: '未命名链接'); ?></h3>
            <div class="link-actions">
                <button class="action-btn" onclick="editLink(<?php echo $link['id']; ?>, '<?php echo htmlspecialchars($link['custom_code'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($link['remark'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($link['video_ids'], ENT_QUOTES); ?>')">
                    <i class="fas fa-edit"></i> 编辑
                </button>
                <button class="action-btn delete-btn" onclick="deleteLink(<?php echo $link['id']; ?>)">
                    <i class="fas fa-trash"></i> 删除
                </button>
            </div>
        </div>
        <div class="link-url">
            <i class="fas fa-link"></i> <a href="<?php echo htmlspecialchars($websiteUrl); ?>/api.php?code=<?php echo htmlspecialchars($link['custom_code']); ?>" target="_blank" style="color: #667eea; text-decoration: none;"><?php echo htmlspecialchars(str_replace(array('http://', 'https://'), '', $websiteUrl)); ?>/api.php?code=<?php echo htmlspecialchars($link['custom_code']); ?></a>
        </div>
        <div class="link-info">
            <i class="fas fa-video"></i> 视频数量: <?php echo $link['video_ids'] ? count(array_filter(explode(',', $link['video_ids']))) : 0; ?> 
            | <i class="fas fa-clock"></i> 创建于 <?php echo date('Y-m-d H:i', strtotime($link['created_at'])); ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- 创建链接模态框 -->
<div id="createModal" class="modal-custom">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-plus"></i> 创建专属链接</h3>
            <button class="modal-close" onclick="closeCreateModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div id="createMessage"></div>
            <form id="createForm" onsubmit="handleCreateLink(event)">
                <div class="form-group">
                    <label for="customCode">自定义链接 *</label>
                    <input type="text" id="customCode" name="custom_code" placeholder="例如: myvideo" required pattern="[a-zA-Z0-9]+" minlength="3" maxlength="15">
                    <small>只能包含英文字母或数字，3-15个字符</small>
                </div>
                <div class="form-group">
                    <label for="remark">标题备注</label>
                    <input type="text" id="remark" name="remark" placeholder="例如: 我的精选视频合集">
                </div>
                <div class="form-actions">
                    <button type="button" class="btn" onclick="closeCreateModal()">取消</button>
                    <button type="submit" class="btn btn-primary">创建链接</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- 编辑链接模态框 -->
<div id="editModal" class="modal-custom">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-edit"></i> 编辑专属链接</h3>
            <button class="modal-close" onclick="closeEditModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div id="editMessage"></div>
            <form id="editForm" onsubmit="handleEditLink(event)">
                <input type="hidden" id="editLinkId" name="link_id">
                <div class="form-group">
                    <label for="editCustomCode">自定义链接 *</label>
                    <input type="text" id="editCustomCode" name="custom_code" placeholder="例如: myvideo" required pattern="[a-zA-Z0-9]+" minlength="3" maxlength="15">
                    <small>只能包含英文字母或数字，3-15个字符</small>
                </div>
                <div class="form-group">
                    <label for="editRemark">标题备注</label>
                    <input type="text" id="editRemark" name="remark" placeholder="例如: 我的精选视频合集">
                </div>
                <div class="form-group">
                    <label for="editVideoIds">视频ID列表</label>
                    <textarea id="editVideoIds" name="video_ids" placeholder="例如: 1,2,3,4,5&#10;多个ID用英文逗号分隔，随机视频只调取这里面输入的视频ID对应的视频链接"></textarea>
                    <small>多个视频ID用英文逗号分隔，例如: 1,2,3,4,5</small>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn" onclick="closeEditModal()">取消</button>
                    <button type="submit" class="btn btn-primary">保存修改</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// 显示创建模态框
function showCreateModal() {
    document.getElementById('createModal').style.display = 'flex';
    document.getElementById('createMessage').innerHTML = '';
    document.getElementById('createForm').reset();
}

// 关闭创建模态框
function closeCreateModal() {
    document.getElementById('createModal').style.display = 'none';
}

// 显示编辑模态框
function editLink(id, code, remark, videoIds) {
    document.getElementById('editModal').style.display = 'flex';
    document.getElementById('editMessage').innerHTML = '';
    document.getElementById('editLinkId').value = id;
    document.getElementById('editCustomCode').value = code;
    document.getElementById('editRemark').value = remark;
    document.getElementById('editVideoIds').value = videoIds || '';
}

// 关闭编辑模态框
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

// 处理创建链接
async function handleCreateLink(e) {
    e.preventDefault();
    
    const messageDiv = document.getElementById('createMessage');
    const formData = new FormData(e.target);
    
    try {
        const response = await fetch('/user/api.php?action=create_custom_link', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.innerHTML = '<div class="message-box success"><i class="fas fa-check-circle"></i> ' + result.message + '</div>';
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            messageDiv.innerHTML = '<div class="message-box error"><i class="fas fa-exclamation-circle"></i> ' + result.message + '</div>';
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message-box error"><i class="fas fa-exclamation-circle"></i> 操作失败，请重试</div>';
    }
}

// 处理编辑链接
async function handleEditLink(e) {
    e.preventDefault();
    
    const messageDiv = document.getElementById('editMessage');
    const formData = new FormData(e.target);
    
    try {
        const response = await fetch('/user/api.php?action=update_custom_link', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.innerHTML = '<div class="message-box success"><i class="fas fa-check-circle"></i> ' + result.message + '</div>';
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            messageDiv.innerHTML = '<div class="message-box error"><i class="fas fa-exclamation-circle"></i> ' + result.message + '</div>';
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message-box error"><i class="fas fa-exclamation-circle"></i> 操作失败，请重试</div>';
    }
}

// 删除链接
async function deleteLink(linkId) {
    if (!confirm('确定要删除此定制链接吗？删除后无法恢复！')) {
        return;
    }
    
    try {
        const response = await fetch('/user/api.php?action=delete_custom_link', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ link_id: linkId })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('删除成功！');
            location.reload();
        } else {
            alert('删除失败：' + result.message);
        }
    } catch (error) {
        alert('操作失败，请重试');
    }
}

// 点击模态框外部关闭
window.onclick = function(event) {
    const createModal = document.getElementById('createModal');
    const editModal = document.getElementById('editModal');
    
    if (event.target === createModal) {
        closeCreateModal();
    }
    
    if (event.target === editModal) {
        closeEditModal();
    }
}
</script>

