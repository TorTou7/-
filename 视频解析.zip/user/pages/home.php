<?php
/**
 * 用户首页内容
 * 显示统计信息和账号设置
 */
?>

<style>
/* 页面标题样式 */
.page-title {
    margin-bottom: 30px;
}

.page-title h2 {
    font-size: 24px;
    font-weight: 700;
    color: #333;
    margin: 0 0 8px 0;
}

.page-title p {
    font-size: 14px;
    color: #666;
    margin: 0;
}

/* 统计卡片网格 - 一行3个，响应式 */
.stats-grid-home {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 40px;
}

/* 统计卡片样式 - 正方形 */
.stat-card-home {
    aspect-ratio: 1;
    background: #fff;
    padding: 30px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    transition: all 0.3s ease;
}

.stat-card-home:hover {
    transform: scale(1.05);
}

.stat-card-home .icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
}

.stat-card-home .icon i {
    font-size: 28px;
    color: #fff;
}

.stat-card-home .value {
    font-size: 36px;
    font-weight: 700;
    color: #333;
    margin-bottom: 8px;
}

.stat-card-home .label {
    font-size: 16px;
    font-weight: 600;
    color: #666;
    margin-bottom: 8px;
}

.stat-card-home .desc {
    font-size: 12px;
    color: #999;
    line-height: 1.4;
}

/* 设置区域样式 */
.settings-section-home {
    background: #fff;
    padding: 30px;
    margin-bottom: 30px;
}

.settings-section-home h3 {
    font-size: 18px;
    font-weight: 700;
    color: #333;
    margin: 0 0 20px 0;
    padding-bottom: 15px;
    border-bottom: 2px solid #e0e0e0;
}

.settings-section-home h3 i {
    margin-right: 8px;
    color: #667eea;
}

/* 表单样式 */
.form-group-home {
    margin-bottom: 20px;
}

.form-group-home label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #333;
    margin-bottom: 8px;
}

.form-group-home input {
    width: 100%;
    padding: 12px 15px;
    font-size: 14px;
    border: 2px solid #ddd;
    background: #fff;
    transition: all 0.3s ease;
    box-sizing: border-box;
}

.form-group-home input:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.form-group-home .hint {
    display: block;
    font-size: 12px;
    color: #999;
    margin-top: 6px;
}

/* 按钮样式 */
.btn-home {
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 600;
    border: 2px solid #333;
    background: #fff;
    color: #333;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-right: 10px;
}

.btn-home:hover {
    background: #333;
    color: #fff;
}

.btn-home.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-color: #667eea;
    color: #fff;
}

.btn-home.btn-primary:hover {
    background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    transform: translateY(-2px);
    box-shadow: 4px 4px 0 #333;
}

/* 消息提示样式 */
.message-box {
    padding: 12px 15px;
    border-radius: 4px;
    margin-bottom: 15px;
    font-size: 14px;
}

.message-box.success {
    background: #d4edda;
    color: #155724;
    border: 2px solid #c3e6cb;
}

.message-box.error {
    background: #f8d7da;
    color: #721c24;
    border: 2px solid #f5c6cb;
}

.message-box i {
    margin-right: 8px;
}

/* 当前信息显示 */
.current-info {
    background: #f8f9fa;
    padding: 15px;
    border-left: 4px solid #667eea;
    margin-bottom: 20px;
    font-size: 14px;
    color: #666;
}

.current-info strong {
    color: #333;
}

/* 响应式设计 - 平板端 */
@media (max-width: 1024px) {
    .stats-grid-home {
        gap: 15px;
    }
    
    .stat-card-home {
        padding: 20px;
    }
    
    .stat-card-home .icon {
        width: 50px;
        height: 50px;
        margin-bottom: 15px;
    }
    
    .stat-card-home .icon i {
        font-size: 24px;
    }
    
    .stat-card-home .value {
        font-size: 30px;
    }
    
    .stat-card-home .label {
        font-size: 14px;
    }
    
    .stat-card-home .desc {
        font-size: 11px;
    }
}

/* 响应式设计 - 手机端 */
@media (max-width: 768px) {
    .stats-grid-home {
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
    }
    
    .stat-card-home {
        padding: 10px;
    }
    
    .stat-card-home:hover {
        transform: scale(1.02);
    }
    
    .stat-card-home .icon {
        width: 30px;
        height: 30px;
        margin-bottom: 8px;
    }
    
    .stat-card-home .icon i {
        font-size: 16px;
    }
    
    .stat-card-home .value {
        font-size: 18px;
        margin-bottom: 4px;
        line-height: 1.2;
    }
    
    .stat-card-home .label {
        font-size: 11px;
        margin-bottom: 4px;
        line-height: 1.2;
    }
    
    .stat-card-home .desc {
        font-size: 9px;
        line-height: 1.3;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    
    .settings-section-home {
        padding: 15px;
    }
    
    .page-title h2 {
        font-size: 20px;
    }
    
    .page-title p {
        font-size: 13px;
    }
}

/* 响应式设计 - 小屏手机 */
@media (max-width: 480px) {
    .stats-grid-home {
        gap: 6px;
    }
    
    .stat-card-home {
        padding: 8px;
    }
    
    .stat-card-home .icon {
        width: 24px;
        height: 24px;
        margin-bottom: 6px;
    }
    
    .stat-card-home .icon i {
        font-size: 12px;
    }
    
    .stat-card-home .value {
        font-size: 16px;
        margin-bottom: 3px;
    }
    
    .stat-card-home .label {
        font-size: 10px;
        margin-bottom: 3px;
    }
    
    .stat-card-home .desc {
        font-size: 8px;
    }
}

/* 深色主题适配 */
[data-theme="dark"] .page-title h2 {
    color: #e0e0e0;
}

[data-theme="dark"] .page-title p {
    color: #999999;
}

[data-theme="dark"] .stat-card-home {
    background: #2a2a2a;
}

[data-theme="dark"] .stat-card-home .value {
    color: #e0e0e0;
}

[data-theme="dark"] .stat-card-home .label {
    color: #999999;
}

[data-theme="dark"] .stat-card-home .desc {
    color: #666666;
}

[data-theme="dark"] .settings-section-home {
    background: #2a2a2a;
}

[data-theme="dark"] .settings-section-home h3 {
    color: #e0e0e0;
}

[data-theme="dark"] .settings-section-home p {
    color: #999999 !important;
}

[data-theme="dark"] .form-group-home label {
    color: #e0e0e0;
}

[data-theme="dark"] .form-group-home input {
    background: #1a1a1a;
    border-color: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .form-group-home input:focus {
    border-color: #667eea;
    background: #1a1a1a;
}

[data-theme="dark"] .form-group-home .hint {
    color: #666666;
}

[data-theme="dark"] .current-info {
    background: #1a1a1a;
    border-left-color: #667eea;
    color: #999999;
}

[data-theme="dark"] .current-info strong {
    color: #e0e0e0;
}

[data-theme="dark"] .btn-home {
    background: #2a2a2a;
    border-color: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .btn-home:hover {
    background: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .btn-home.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-color: #667eea;
    color: #fff;
}

[data-theme="dark"] .message-box.success {
    background: #1a3a1a;
    color: #90ee90;
    border-color: #2a5a2a;
}

[data-theme="dark"] .message-box.error {
    background: #3a1a1a;
    color: #ff9999;
    border-color: #5a2a2a;
}
</style>

<!-- 统计信息 -->
<div class="page-title">
    <h2><i class="fas fa-chart-line"></i> 统计信息</h2>
    <p>查看账号数据统计</p>
</div>

<div class="stats-grid-home">
    <div class="stat-card-home">
        <div class="icon">
            <i class="fas fa-video"></i>
        </div>
        <div class="value"><?php echo number_format($stats['my_videos']); ?></div>
        <div class="label">我的视频</div>
        <div class="desc">此账号下所有解析的视频</div>
    </div>
    
    <div class="stat-card-home">
        <div class="icon">
            <i class="fas fa-heart"></i>
        </div>
        <div class="value"><?php echo number_format($stats['favorites']); ?></div>
        <div class="label">喜欢收藏</div>
        <div class="desc">此账号下所有收藏的视频</div>
    </div>
    
    <div class="stat-card-home">
        <div class="icon">
            <i class="fas fa-eye"></i>
        </div>
        <div class="value"><?php echo number_format($stats['total_views']); ?></div>
        <div class="label">浏览统计</div>
        <div class="desc">我的视频的总浏览次数</div>
    </div>
</div>

<!-- 邮箱设置 -->
<div class="settings-section-home">
    <h3><i class="fas fa-envelope"></i> 邮箱设置</h3>
    <p style="color: #666; font-size: 14px; margin-bottom: 20px;">修改您的邮箱地址</p>
    
    <div class="current-info">
        <i class="fas fa-info-circle"></i> 当前邮箱: <strong><?php echo $email ? htmlspecialchars($email) : '未设置'; ?></strong>
    </div>
    
    <div id="emailMessage"></div>
    
    <form id="emailForm" onsubmit="handleEmailUpdate(event)">
        <div class="form-group-home">
            <label for="newEmail">新邮箱地址</label>
            <input type="email" id="newEmail" name="email" placeholder="请输入新邮箱地址，留空表示清除邮箱">
            <span class="hint">邮箱可用于登录和找回密码</span>
        </div>
        
        <button type="submit" class="btn-home btn-primary">
            <i class="fas fa-save"></i> 保存修改
        </button>
    </form>
</div>

<!-- 密码修改 -->
<div class="settings-section-home">
    <h3><i class="fas fa-key"></i> 密码修改</h3>
    
    <div class="current-info">
        <i class="fas fa-clock"></i> 上次修改: <strong>
            <?php 
            if ($passwordUpdatedAt) {
                echo date('Y年m月d日 H:i:s', strtotime($passwordUpdatedAt));
            } else {
                echo '暂无记录';
            }
            ?>
        </strong>
    </div>
    
    <div id="passwordMessage"></div>
    
    <form id="passwordForm" onsubmit="handlePasswordUpdate(event)">
        <div class="form-group-home">
            <label for="oldPassword">当前密码 *</label>
            <input type="password" id="oldPassword" name="old_password" placeholder="请输入当前密码" required>
        </div>
        
        <div class="form-group-home">
            <label for="newPassword">新密码 *</label>
            <input type="password" id="newPassword" name="new_password" placeholder="请输入新密码（至少6位）" required minlength="6">
        </div>
        
        <div class="form-group-home">
            <label for="confirmPassword">确认密码 *</label>
            <input type="password" id="confirmPassword" placeholder="请再次输入新密码" required>
        </div>
        
        <button type="submit" class="btn-home btn-primary">
            <i class="fas fa-save"></i> 修改密码
        </button>
    </form>
</div>

<script>
// 处理邮箱修改
async function handleEmailUpdate(e) {
    e.preventDefault();
    
    const messageDiv = document.getElementById('emailMessage');
    const formData = new FormData(e.target);
    
    try {
        const response = await fetch('/user/auth.php?action=update_email', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.innerHTML = '<div class="message-box success"><i class="fas fa-check-circle"></i> ' + result.message + '</div>';
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            messageDiv.innerHTML = '<div class="message-box error"><i class="fas fa-exclamation-circle"></i> ' + result.message + '</div>';
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message-box error"><i class="fas fa-exclamation-circle"></i> 操作失败，请重试</div>';
    }
}

// 处理密码修改
async function handlePasswordUpdate(e) {
    e.preventDefault();
    
    const messageDiv = document.getElementById('passwordMessage');
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // 验证两次密码是否一致
    if (newPassword !== confirmPassword) {
        messageDiv.innerHTML = '<div class="message-box error"><i class="fas fa-exclamation-circle"></i> 两次输入的密码不一致</div>';
        return;
    }
    
    const formData = new FormData(e.target);
    
    try {
        const response = await fetch('/user/auth.php?action=update_password', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            messageDiv.innerHTML = '<div class="message-box success"><i class="fas fa-check-circle"></i> ' + result.message + '</div>';
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            messageDiv.innerHTML = '<div class="message-box error"><i class="fas fa-exclamation-circle"></i> ' + result.message + '</div>';
        }
    } catch (error) {
        messageDiv.innerHTML = '<div class="message-box error"><i class="fas fa-exclamation-circle"></i> 操作失败，请重试</div>';
    }
}
</script>

