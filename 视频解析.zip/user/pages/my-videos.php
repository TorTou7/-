<?php
/**
 * 我的链接页面
 * 显示用户解析的所有视频
 */

// 分页设置
$pageNum = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$perPage = 20; // 每页20个
$offset = ($pageNum - 1) * $perPage;

// 获取总数
$stmt = $db->prepare("SELECT COUNT(*) as total FROM user_videos WHERE user_id = ?");
$stmt->execute([$userId]);
$totalCount = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
$totalPages = ceil($totalCount / $perPage);

// 获取视频列表
$stmt = $db->prepare("
    SELECT v.id, v.title, v.input_url, v.created_at
    FROM user_videos uv
    INNER JOIN videos v ON uv.video_id = v.id
    WHERE uv.user_id = ?
    ORDER BY uv.created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->bindValue(1, $userId, PDO::PARAM_INT);
$stmt->bindValue(2, $perPage, PDO::PARAM_INT);
$stmt->bindValue(3, $offset, PDO::PARAM_INT);
$stmt->execute();
$videos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
/* 页面标题样式 */
.page-title-myvideos {
    margin-bottom: 30px;
}

.page-title-myvideos h2 {
    font-size: 24px;
    font-weight: 700;
    color: #333;
    margin: 0 0 8px 0;
}

.page-title-myvideos p {
    font-size: 14px;
    color: #666;
    margin: 0;
}

/* 空状态样式 */
.empty-state-myvideos {
    text-align: center;
    padding: 60px 20px;
    background: #fff;
}

.empty-state-myvideos i {
    font-size: 64px;
    color: #ccc;
    margin-bottom: 20px;
}

.empty-state-myvideos h3 {
    font-size: 20px;
    font-weight: 600;
    color: #666;
    margin: 0 0 10px 0;
}

.empty-state-myvideos p {
    font-size: 14px;
    color: #999;
    margin: 0;
}

.empty-state-myvideos a {
    color: #667eea;
    text-decoration: none;
    font-weight: 600;
}

.empty-state-myvideos a:hover {
    text-decoration: underline;
}

/* 分页样式 */
.pagination-myvideos {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 20px;
    margin-top: 30px;
    padding: 20px;
}

.pagination-myvideos .page-btn {
    padding: 10px 20px;
    font-size: 14px;
    font-weight: 600;
    border: 2px solid #333;
    background: #fff;
    color: #333;
    text-decoration: none;
    transition: all 0.3s ease;
}

.pagination-myvideos .page-btn:hover {
    background: #333;
    color: #fff;
}

.pagination-myvideos .page-info {
    font-size: 14px;
    color: #666;
    font-weight: 600;
}

/* 响应式设计 */
@media (max-width: 768px) {
    .pagination-myvideos {
        flex-direction: column;
        gap: 10px;
    }
}

/* 深色主题适配 */
[data-theme="dark"] .page-title-myvideos h2 {
    color: #e0e0e0;
}

[data-theme="dark"] .page-title-myvideos p {
    color: #999999;
}

[data-theme="dark"] .empty-state-myvideos {
    background: #2a2a2a;
}

[data-theme="dark"] .empty-state-myvideos i {
    color: #444444;
}

[data-theme="dark"] .empty-state-myvideos h3 {
    color: #999999;
}

[data-theme="dark"] .empty-state-myvideos p {
    color: #666666;
}

[data-theme="dark"] .pagination-myvideos .page-btn {
    background: #2a2a2a;
    border-color: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .pagination-myvideos .page-btn:hover {
    background: #444444;
    color: #e0e0e0;
}

[data-theme="dark"] .pagination-myvideos .page-info {
    color: #999999;
}
</style>

<div class="page-title-myvideos">
    <h2><i class="fas fa-video"></i> 我的链接</h2>
    <p>此账号下所有解析的视频，每个链接仅有一位作者</p>
</div>

<?php if (empty($videos)): ?>
<div class="empty-state-myvideos">
    <i class="fas fa-video-slash"></i>
    <h3>还没有解析过视频</h3>
    <p>去<a href="/">首页</a>解析您的第一个视频吧！</p>
</div>
<?php else: ?>
<?php foreach ($videos as $video): ?>
<div class="result-table">
    <div class="result-row">
        <div class="result-label">ID:<?php echo $video['id']; ?></div>
        <div class="result-value">
            <span><?php echo htmlspecialchars($video['input_url']); ?></span>
            <div class="action-buttons">
                <button class="btn-action" onclick="window.open('<?php echo htmlspecialchars($video['input_url'], ENT_QUOTES); ?>', '_blank')">
                    <i class="fas fa-external-link-alt"></i> 跳转
                </button>
                <button class="btn-action" onclick="location.href='/article.php?id=<?php echo $video['id']; ?>'">
                    <i class="fas fa-info-circle"></i> 详细
                </button>
                <button class="btn-action btn-danger" onclick="deleteMyVideo(<?php echo $video['id']; ?>)">
                    <i class="fas fa-trash"></i> 删除
                </button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php if ($totalPages > 1): ?>
<div class="pagination-myvideos">
    <?php if ($pageNum > 1): ?>
    <a href="?page=my-videos&p=<?php echo $pageNum - 1; ?>" class="page-btn">
        <i class="fas fa-chevron-left"></i> 上一页
    </a>
    <?php endif; ?>
    
    <span class="page-info">第 <?php echo $pageNum; ?> / <?php echo $totalPages; ?> 页 (共 <?php echo $totalCount; ?> 个视频)</span>
    
    <?php if ($pageNum < $totalPages): ?>
    <a href="?page=my-videos&p=<?php echo $pageNum + 1; ?>" class="page-btn">
        下一页 <i class="fas fa-chevron-right"></i>
    </a>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php endif; ?>

<script>
// 删除我的视频
async function deleteMyVideo(videoId) {
    if (!confirm('确定要删除与此视频的绑定吗？')) {
        return;
    }
    
    try {
        const response = await fetch('/user/api.php?action=delete_my_video', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ video_id: videoId })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('删除成功！');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('删除失败：' + result.message);
        }
    } catch (error) {
        showToast('操作失败，请重试');
    }
}

// 显示提示消息
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.textContent = message;
    toast.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #333; color: #fff; padding: 12px 24px; border-radius: 4px; z-index: 10000; animation: slideIn 0.3s ease;';
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 2000);
}
</script>


