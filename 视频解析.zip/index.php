<?php
/**
 * 主页 - 视频解析
 * 
 * 功能：解析视频链接，获取标题、封面、视频地址
 */

// 错误处理配置（已移至config.php统一管理）

require_once 'config.php';
require_once 'database.php';
require_once 'functions.php';
require_once 'csrf.php';

// 处理AJAX请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // 验证CSRF Token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        jsonResponse(-1, 'CSRF验证失败');
    }
    
    $action = $_POST['action'];
    
    if ($action === 'parse') {
        // 检查游客解析权限
        $isLoggedIn = isset($_SESSION['user_id']);
        $guestParse = Database::getInstance()->getSetting('guest_parse') ?? '1'; // 1=允许游客, 0=需要登录
        
        if (!$isLoggedIn && $guestParse === '0') {
            jsonResponse(-1, '请先登录后再解析视频');
        }
        
        $url = $_POST['url'] ?? '';
        
        if (empty($url)) {
            jsonResponse(-1, '请输入视频链接');
        }
        
        // 清理URL,提取纯净链接
        $url = cleanVideoUrl($url);
        
        // 验证URL格式
        if (!isValidVideoUrl($url)) {
            jsonResponse(-1, 'URL格式无效,请输入正确的视频链接');
        }
        
        // URL长度限制
        if (strlen($url) > 2000) {
            jsonResponse(-1, 'URL长度超过限制(2000字符)');
        }
        
        $result = parseVideo($url);
        
        if ($result['success']) {
            // 解析成功后，检查是否需要创建下载任务
            $videoId = $result['data']['id'] ?? null;
            $videoUrl = $result['data']['url'] ?? null;
            
            if ($videoId && $videoUrl) {
                // 获取存储策略
                $strategy = Database::getInstance()->getSetting('storage_strategy') ?? 'none';
                
                // 如果不是“不保存”策略，则创建下载任务
                if ($strategy !== 'none') {
                    require_once 'task_queue.php';
                    $taskQueue = TaskQueue::getInstance();
                    $taskId = $taskQueue->createTask($videoId, $videoUrl);
                    $result['data']['task_id'] = $taskId;
                    $result['data']['task_created'] = true;
                    
                    // 在后台异步触发任务处理
                    $phpPath = PHP_BINARY;
                    $scriptPath = __DIR__ . '/process_task_async.php';
                    $command = sprintf('%s %s %d > /dev/null 2>&1 &', 
                        escapeshellarg($phpPath),
                        escapeshellarg($scriptPath),
                        $taskId
                    );
                    exec($command);
                    
                    $result['data']['task_triggered'] = true;
                }
            }
            
            jsonResponse(0, '解析成功', $result['data']);
        } else {
            jsonResponse(-1, $result['error'] ?? '解析失败');
        }
    }
}

// 生成CSRF Token
$csrfToken = generateCsrfToken();

// 输出HTML
htmlHeader('视频解析');
?>

<div class="header">
    <h1><i class="fas fa-video"></i> <?php echo APP_NAME; ?></h1>
    <p><?php echo SITE_DESCRIPTION; ?></p>
</div>

<?php htmlNav('index'); ?>

<div class="content">
    <!-- 状态消息 -->
    <div id="statusMessage" class="status-message"></div>
    
    <!-- 输入表单 -->
    <div class="input-group">
        <label class="input-label">
            <i class="fas fa-link"></i> 视频链接
        </label>
        <div class="input-wrapper">
            <input type="url" id="videoUrl" placeholder="请输入视频链接，如 https://x.com/...">
            <button class="btn btn-primary" id="parseBtn" onclick="parseVideo()">
                <i class="fas fa-search"></i> 解析视频
            </button>
            <button class="btn btn-secondary" id="clearBtn" onclick="clearInput()" style="display: none;">
                <i class="fas fa-times"></i> 清空内容
            </button>
        </div>
    </div>
        
    <!-- 结果区域 -->
    <div id="resultArea">
        <div class="empty-state">
            <i class="fas fa-cloud-download-alt"></i>
            <p>请输入视频链接开始解析</p>
        </div>
    </div>
</div>

<script>
// 监听输入框变化
document.getElementById('videoUrl').addEventListener('input', function() {
    const clearBtn = document.getElementById('clearBtn');
    clearBtn.style.display = this.value.trim() ? 'inline-flex' : 'none';
});

// 支持回车键解析
document.getElementById('videoUrl').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        parseVideo();
    }
});

// 清空输入
function clearInput() {
    document.getElementById('videoUrl').value = '';
    document.getElementById('clearBtn').style.display = 'none';
    document.getElementById('resultArea').innerHTML = `
        <div class="empty-state">
            <i class="fas fa-cloud-download-alt"></i>
            <p>请输入视频链接开始解析</p>
        </div>
    `;
    hideStatus();
}

// 清理URL,提取纯净链接
function cleanVideoUrl(input) {
    // 定义视频平台URL模式
    const patterns = [
        // 抖音短链接
        /https?:\/\/v\.douyin\.com\/[a-zA-Z0-9\-_]+\/?/,
        // 抖音长链接
        /https?:\/\/www\.douyin\.com\/video\/\d+/,
        // 快手短链接
        /https?:\/\/v\.kuaishou\.com\/[a-zA-Z0-9]+/,
        // 快手长链接
        /https?:\/\/www\.kuaishou\.com\/short-video\/\d+/,
        // B站短链接
        /https?:\/\/b23\.tv\/[a-zA-Z0-9]+/,
        // B站视频链接
        /https?:\/\/www\.bilibili\.com\/video\/[a-zA-Z0-9]+/,
        // 小红书
        /https?:\/\/xhslink\.com\/[a-zA-Z0-9]+/,
        /https?:\/\/www\.xiaohongshu\.com\/[a-zA-Z0-9\/]+/,
        // 通用HTTP(S)链接
        /https?:\/\/[^\s]+/
    ];
    
    // 尝试匹配每个模式
    for (let pattern of patterns) {
        const match = input.match(pattern);
        if (match) {
            let cleanUrl = match[0];
            // 移除末尾可能的标点符号
            cleanUrl = cleanUrl.replace(/[.,;:!?。，；：！？]+$/, '');
            
            // 特别处理：抖音短链接必须以斜杠结尾
            if (/^https?:\/\/v\.douyin\.com\/[a-zA-Z0-9\-_]+$/.test(cleanUrl)) {
                cleanUrl += '/';
            }
            
            return cleanUrl;
        }
    }
    
    return input;
}

// 解析视频
async function parseVideo() {
    let url = document.getElementById('videoUrl').value.trim();
    const resultArea = document.getElementById('resultArea');
    const parseBtn = document.getElementById('parseBtn');
    
    if (!url) {
        showStatus('请输入视频链接', 'error');
        return;
    }
    
    // 清理URL,提取纯净链接
    url = cleanVideoUrl(url);
    
    // 验证URL格式
    try {
        new URL(url);
    } catch (e) {
        showStatus('请输入有效的视频链接', 'error');
        return;
    }
    
    // 显示加载状态
    parseBtn.disabled = true;
    showStatus('正在解析视频，请稍候...', 'loading');
    showLoading(resultArea);
    
    try {
        // 发送POST请求
        const formData = new FormData();
        formData.append('action', 'parse');
        formData.append('url', url);
        formData.append('csrf_token', '<?php echo $csrfToken; ?>');
        
        const response = await fetch('/', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        console.log('响应数据:', data);
        
        if (data.code === 0 && data.data) {
            displayResult(data.data);
            showStatus('✓ 解析成功！', 'success');
            setTimeout(() => hideStatus(), 3000);
        } else {
            // 根据错误类型显示不同的提示
            let errorMsg = data.message || '解析失败';
            let helpText = '';
            
            if (errorMsg.includes('SSL') || errorMsg.includes('网络请求失败')) {
                helpText = '⚠️ 服务器网络问题：无法访问API服务。<br>请联系管理员在后台“API测试”中查看详细诊断信息。';
            } else if (errorMsg.includes('超时')) {
                helpText = '⏱️ 请求超时，请检查网络连接或稍后重试。';
            } else if (errorMsg.includes('CSRF')) {
                helpText = '🔄 页面已过期，请刷新页面后重试。';
            } else if (errorMsg.includes('URL')) {
                helpText = '🔗 请检查视频链接是否正确。';
            }
            
            let displayMsg = errorMsg;
            if (helpText) {
                displayMsg += '<br><small style="color: #7f8c8d;">' + helpText + '</small>';
            }
            
            showEmpty(resultArea, displayMsg);
            showStatus('✗ ' + errorMsg, 'error');
        }
    } catch (error) {
        console.error('请求失败:', error);
        showEmpty(resultArea, '网络请求失败，请检查网络连接');
        showStatus('✗ 网络请求失败', 'error');
    } finally {
        parseBtn.disabled = false;
    }
}

// 显示结果
function displayResult(video) {
    let html = '';
    
    // 作者提示信息
    if (video.author_message) {
        const messageClass = video.has_author ? 'author-warning' : 'author-success';
        html += `<div class="${messageClass}" style="margin-bottom: 20px; padding: 15px; border-radius: 8px; text-align: center; font-size: 14px;">`;
        html += `<i class="fas ${video.has_author ? 'fa-info-circle' : 'fa-check-circle'}"></i> `;
        html += escapeHtml(video.author_message);
        html += '</div>';
    }
    
    html += '<div class="result-table">';
    
    // ID
    if (video.id) {
        html += createResultRow('ID', video.id, 'text');
    }
    
    // 标题（不显示复制按钮）
    if (video.title) {
        html += createResultRow('标题', video.title, 'title');
    }
    
    // 封面
    if (video.cover) {
        html += createResultRow('封面', video.cover, 'cover');
    }
    
    // 视频
    if (video.url) {
        html += createResultRow('视频', video.url, 'video');
    }
    
    // 操作按钮
    if (video.id) {
        let operationContent = '<div class="info-value" style="display: flex; gap: 8px; flex-wrap: wrap;">';
        
        // 收藏按钮（仅已登录用户显示）
        <?php if (isset($_SESSION['user_id'])): ?>
        const favClass = video.is_favorited ? 'btn-favorited' : '';
        const favText = video.is_favorited ? '已收藏' : '收藏';
        operationContent += `<button class="btn-action ${favClass}" id="favoriteBtn_${video.id}" onclick="toggleFavoriteInResult(${video.id}, ${video.is_favorited ? 'true' : 'false'})" title="收藏视频">`;
        operationContent += `<i class="fas fa-heart"></i> ${favText}`;
        operationContent += '</button>';
        <?php endif; ?>
        
        // 原文地址按钮
        if (video.input_url) {
            operationContent += `<button class="btn-action btn-source" onclick="copyText('${escapeAttr(video.input_url)}')" title="复制解析前的原文地址">`;
            operationContent += '<i class="fas fa-external-link-alt"></i> 原文地址';
            operationContent += '</button>';
        }
        
        // 详细页面按钮
        operationContent += `<button class="btn-action btn-detail" onclick="window.location.href='/article.php?id=${video.id}'" title="查看详细页面">`;
        operationContent += '<i class="fas fa-info-circle"></i> 详细页面';
        operationContent += '</button>';
        
        // 重新获取按钮
        operationContent += `<button class="btn-action btn-refresh" onclick="refreshVideoInResult(${video.id})" title="重新获取视频数据">`;
        operationContent += '<i class="fas fa-sync-alt"></i> 重新获取';
        operationContent += '</button>';
        
        operationContent += '</div>';
        
        html += createResultRow('操作', operationContent, 'html');
    }
    
    html += '</div>';
    
    // 收藏按钮已移动到ID后
    
    document.getElementById('resultArea').innerHTML = html;
}

// 下载视频
function downloadVideo(url) {
    window.location.href = '/download.php?url=' + encodeURIComponent(url);
}

// 创建结果行
function createResultRow(label, value, type = 'text') {
    // 如果是html类型，直接使用value，不进行escapeHtml
    const displayValue = type === 'html' ? value : escapeHtml(String(value));
    let buttons = '';
    
    // 标题类型不显示任何按钮
    if (type === 'cover' || type === 'video') {
        buttons = `
            <div class="action-buttons">
                <button class="btn-action" onclick="openPreview('${escapeAttr(value)}')">
                    <i class="fas fa-eye"></i> 预览
                </button>
                <button class="btn-action" onclick="copyToClipboard('${escapeAttr(value)}')">
                    <i class="fas fa-copy"></i> 复制
                </button>
                ${type === 'video' ? `
                <button class="btn-action btn-download" onclick="downloadVideo('${escapeAttr(value)}')">
                    <i class="fas fa-download"></i> 下载
                </button>
                ` : ''}
            </div>
        `;
    }
    
    return `
        <div class="result-row">
            <div class="result-label">
                <i class="fas fa-check" style="color: #27ae60; margin-right: 5px;"></i>
                ${label}
            </div>
            <div class="result-value">
                <span>${displayValue}</span>
                ${buttons}
            </div>
        </div>
    `;
}

// 复制文本
function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
            showStatus('✓ 复制成功！', 'success');
            setTimeout(() => hideStatus(), 2000);
        }).catch(() => {
            fallbackCopyText(text);
        });
    } else {
        fallbackCopyText(text);
    }
}

function fallbackCopyText(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
        document.execCommand('copy');
        showStatus('✓ 复制成功！', 'success');
        setTimeout(() => hideStatus(), 2000);
    } catch (err) {
        showStatus('✗ 复制失败', 'error');
    }
    document.body.removeChild(textarea);
}

// 在解析结果中重新拉取视频
async function refreshVideoInResult(videoId) {
    if (!confirm('确定要重新获取该视频的数据吗？')) {
        return;
    }
    
    showStatus('正在重新拉取数据...', 'loading');
    
    try {
        const formData = new FormData();
        formData.append('action', 'refresh');
        formData.append('id', videoId);
        formData.append('csrf_token', '<?php echo $csrfToken; ?>');
        
        const response = await fetch('/random.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.code === 0 && data.data) {
            displayResult(data.data);
            showStatus('✓ ' + (data.message || '刷新成功！'), 'success');
            setTimeout(() => hideStatus(), 3000);
        } else {
            showStatus('✗ ' + (data.message || '刷新失败'), 'error');
        }
    } catch (error) {
        console.error('请求失败:', error);
        showStatus('✗ 网络请求失败', 'error');
    }
}

// 在解析结果中切换收藏状态
async function toggleFavoriteInResult(videoId, isFavorited) {
    const btn = document.getElementById('favoriteBtn_' + videoId);
    
    if (!btn) {
        console.error('找不到收藏按钮');
        return;
    }
    
    // 禁用按钮防止重复点击
    btn.disabled = true;
    
    try {
        const response = await fetch('/user/api.php?action=toggle_favorite', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({video_id: videoId})
        });
        
        const result = await response.json();
        
        if (result.success) {
            // 更新按钮状态
            const newText = result.favorited ? '已收藏' : '收藏';
            
            // 更新按钮样式和文本
            if (result.favorited) {
                btn.classList.add('btn-favorited');
            } else {
                btn.classList.remove('btn-favorited');
            }
            btn.innerHTML = `<i class="fas fa-heart"></i> ${newText}`;
            
            // 更新onclick事件
            btn.onclick = function() {
                toggleFavoriteInResult(videoId, result.favorited);
            };
            
            showStatus('✓ ' + result.message, 'success');
            setTimeout(() => hideStatus(), 2000);
        } else {
            showStatus('✗ ' + (result.message || '操作失败'), 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showStatus('✗ 操作失败，请重试', 'error');
    } finally {
        // 重新启用按钮
        btn.disabled = false;
    }
}
</script>

<style>
.author-success {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    font-weight: 500;
}
.author-warning {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: white;
    font-weight: 500;
}
.author-success i, .author-warning i {
    margin-right: 8px;
    font-size: 16px;
}
</style>

<?php htmlFooter(); ?>

