<?php
/**
 * 本地存储处理类 (重构版)
 * 
 * 功能:
 * 1. 下载视频到本地服务器
 * 2. 支持年月日目录结构
 * 3. 仅存储相对路径到数据库
 * 4. 动态生成完整URL
 */

require_once __DIR__ . '/database.php';

class LocalStorage {
    private $basePath;
    private $siteUrl;
    
    public function __construct() {
        $db = Database::getInstance();
        // 获取配置的存储路径，默认为 /uploads
        $this->basePath = $db->getSetting('local_storage_path') ?? '/uploads';
        // 获取网站链接作为URL前缀
        $this->siteUrl = rtrim($db->getSetting('site_url') ?? '', '/');
    }
    
    /**
     * 生成带年月日的存储路径
     * 支持占位符: {Y} {m} {d}
     * 
     * @param string $pathTemplate 路径模板，如 "uploads/{Y}/{m}/{d}" 或 "/uploads/{Y}/{m}/{d}"
     * @return string 实际路径，如 "/uploads/2025/10/25"（始终以/开头，相对于网站根目录）
     */
    private function generateDatePath($pathTemplate) {
        // 替换日期占位符
        $path = str_replace(
            ['{Y}', '{m}', '{d}'],
            [date('Y'), date('m'), date('d')],
            $pathTemplate
        );
        
        // 如果路径为空或只有/，使用默认uploads目录
        if (empty($path) || $path === '/') {
            $path = '/uploads';
        }
        
        // 确保路径以/开头（相对于网站根目录）
        if ($path[0] !== '/') {
            $path = '/' . $path;
        }
        
        // 移除末尾的/
        $path = rtrim($path, '/');
        
        return $path;
    }
    
    /**
     * 保存视频到本地
     * 
     * @param string $videoUrl 视频URL
     * @param int $videoId 视频ID
     * @param callable $progressCallback 进度回调函数
     * @return array ['success' => bool, 'local_path' => string, 'file_size' => int, 'message' => string]
     */
    public function saveVideo($videoUrl, $videoId, $progressCallback = null) {
        try {
            // 生成实际存储路径（支持年月日）
            $relativePath = $this->generateDatePath($this->basePath);
            $fullPath = $_SERVER['DOCUMENT_ROOT'] . $relativePath;
            
            // 确保存储目录存在
            if (!file_exists($fullPath)) {
                if (!mkdir($fullPath, 0755, true)) {
                    throw new Exception('无法创建存储目录: ' . $relativePath);
                }
            }
            
            // 检查目录是否可写
            if (!is_writable($fullPath)) {
                throw new Exception('存储目录不可写: ' . $relativePath);
            }
            
            // 下载视频（大文件支持）
            if ($progressCallback) {
                // 使用大文件下载器
                require_once __DIR__ . '/large_file_downloader.php';
                $downloader = new LargeFileDownloader();
                $downloader->setChunkSize(2 * 1024 * 1024); // 2MB
                
                $extension = $this->getVideoExtension($videoUrl);
                $filename = $videoId . '_' . time() . '.' . $extension;
                $destFile = $fullPath . '/' . $filename;
                
                $result = $downloader->download($videoUrl, $destFile, $progressCallback);
                
                if (!$result['success']) {
                    throw new Exception($result['error'] ?? '视频下载失败');
                }
                
                $tempFile = null; // 不需要移动文件
            } else {
                // 使用传统下载方式
                $tempFile = $this->downloadVideo($videoUrl);
                if (!$tempFile) {
                    throw new Exception('视频下载失败');
                }
                
                // 生成文件名
                $extension = $this->getVideoExtension($videoUrl);
                $filename = $videoId . '_' . time() . '.' . $extension;
                $destFile = $fullPath . '/' . $filename;
                
                // 移动文件
                if (!rename($tempFile, $destFile)) {
                    @unlink($tempFile);
                    throw new Exception('文件保存失败');
                }
            }
            

            
            // 生成相对路径（仅存储后缀）
            $localPath = $relativePath . '/' . $filename;
            
            // 获取文件大小
            $fileSize = filesize($destFile);
            
            return [
                'success' => true,
                'local_path' => $localPath,  // 仅存储相对路径
                'file_size' => $fileSize,
                'message' => '视频保存成功'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 根据相对路径生成完整URL
     * 
     * @param string $localPath 相对路径，如 "/uploads/2025/10/25/123_1234567890.mp4"
     * @return string 完整URL
     */
    public function getFullUrl($localPath) {
        if (empty($localPath)) {
            return '';
        }
        
        // 确保路径以 / 开头
        if ($localPath[0] !== '/') {
            $localPath = '/' . $localPath;
        }
        
        return $this->siteUrl . $localPath;
    }
    
    /**
     * 下载视频到临时目录
     */
    private function downloadVideo($url) {
        $tempFile = sys_get_temp_dir() . '/video_' . uniqid() . '.tmp';
        
        // 使用 cURL 下载
        $ch = curl_init($url);
        $fp = fopen($tempFile, 'wb');
        
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 300); // 5分钟超时
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        
        // SSL/TLS 配置
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
        
        // User-Agent
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
        
        $success = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        curl_close($ch);
        fclose($fp);
        
        if (!$success || $httpCode != 200) {
            @unlink($tempFile);
            return false;
        }
        
        // 检查文件大小
        if (filesize($tempFile) < 1024) { // 小于1KB可能是错误
            @unlink($tempFile);
            return false;
        }
        
        return $tempFile;
    }
    
    /**
     * 获取视频文件扩展名
     */
    private function getVideoExtension($url) {
        $path = parse_url($url, PHP_URL_PATH);
        $extension = pathinfo($path, PATHINFO_EXTENSION);
        
        // 如果没有扩展名或扩展名不是视频格式,默认使用 mp4
        $videoExtensions = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv'];
        if (empty($extension) || !in_array(strtolower($extension), $videoExtensions)) {
            $extension = 'mp4';
        }
        
        return strtolower($extension);
    }
    
    /**
     * 删除本地视频文件
     * 
     * @param string $localPath 相对路径
     * @return bool
     */
    public function deleteVideo($localPath) {
        if (empty($localPath)) {
            return true;
        }
        
        $fullPath = $_SERVER['DOCUMENT_ROOT'] . $localPath;
        
        if (file_exists($fullPath)) {
            return @unlink($fullPath);
        }
        
        return true;
    }
    
    /**
     * 获取存储目录信息
     * 
     * @return array ['total_size' => int, 'file_count' => int, 'free_space' => int]
     */
    public function getStorageInfo() {
        $fullPath = $_SERVER['DOCUMENT_ROOT'] . $this->basePath;
        
        if (!file_exists($fullPath)) {
            return [
                'total_size' => 0,
                'file_count' => 0,
                'free_space' => disk_free_space($_SERVER['DOCUMENT_ROOT'])
            ];
        }
        
        $totalSize = 0;
        $fileCount = 0;
        
        // 递归统计所有文件
        $this->scanDirectory($fullPath, $totalSize, $fileCount);
        
        return [
            'total_size' => $totalSize,
            'file_count' => $fileCount,
            'free_space' => disk_free_space($fullPath)
        ];
    }
    
    /**
     * 递归扫描目录
     */
    private function scanDirectory($dir, &$totalSize, &$fileCount) {
        $files = @scandir($dir);
        if ($files === false) {
            return;
        }
        
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }
            
            $path = $dir . '/' . $file;
            
            if (is_file($path)) {
                $totalSize += filesize($path);
                $fileCount++;
            } elseif (is_dir($path)) {
                $this->scanDirectory($path, $totalSize, $fileCount);
            }
        }
    }
    
    /**
     * 从临时文件保存到本地存储
     * 
     * @param string $tempFile 临时文件路径
     * @param string $filename 文件名
     * @return array ['success' => bool, 'path' => string, 'url' => string, 'error' => string]
     */
    public function save($tempFile, $filename) {
        try {
            // 检查临时文件是否存在
            if (!file_exists($tempFile)) {
                return [
                    'success' => false,
                    'error' => '临时文件不存在: ' . $tempFile
                ];
            }
            
            // 生成实际存储路径（支持年月日）
            $relativePath = $this->generateDatePath($this->basePath);
            $fullPath = $_SERVER['DOCUMENT_ROOT'] . $relativePath;
            
            // 确保存储目录存在
            if (!file_exists($fullPath)) {
                if (!mkdir($fullPath, 0755, true)) {
                    return [
                        'success' => false,
                        'error' => '无法创建存储目录: ' . $relativePath
                    ];
                }
            }
            
            // 检查目录是否可写
            if (!is_writable($fullPath)) {
                return [
                    'success' => false,
                    'error' => '存储目录不可写: ' . $relativePath
                ];
            }
            
            // 目标文件路径
            $destFile = $fullPath . '/' . $filename;
            $destRelativePath = $relativePath . '/' . $filename;
            
            // 移动文件
            if (!rename($tempFile, $destFile)) {
                // 如果rename失败（可能跨分区），尝试copy + unlink
                if (!copy($tempFile, $destFile)) {
                    return [
                        'success' => false,
                        'error' => '无法移动文件到目标位置'
                    ];
                }
                @unlink($tempFile);
            }
            
            // 设置文件权限
            chmod($destFile, 0644);
            
            // 生成完整URL
            $fullUrl = $this->getFullUrl($destRelativePath);
            
            return [
                'success' => true,
                'path' => $destRelativePath,
                'url' => $fullUrl,
                'file_size' => filesize($destFile)
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * 检查本地存储是否配置
     */
    public static function isConfigured() {
        $db = Database::getInstance();
        $strategy = $db->getSetting('storage_strategy') ?? 'none';
        
        return $strategy === 'local' || $strategy === 'both';
    }
}

