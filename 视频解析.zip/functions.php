<?php
/**
 * ==============================================
 * 公共函数库 - functions.php
 * ==============================================
 * 
 * 功能说明：
 * 包含所有页面共用的函数，包括：
 * 1. API调用函数 - callApi()
 * 2. 视频解析函数 - parseVideo()
 * 3. JSON响应函数 - jsonResponse()
 * 4. URL清理函数 - cleanVideoUrl()
 * 5. 日志记录函数 - logInfo(), logError(), cleanOldLogs()
 * 
 * 作者：Manus AI
 * 版本：V5.0
 * 更新日期：2025-10-22
 * ==============================================

/**
 * 调用外部API解析视频 (增强版 - 带重试和日志)
 * 
 * 功能说明：
 * - 调用第三方API服务解析视频链接
 * - 支持多平台：抖音、快手、B站、小红书等
 * - 自动重试3次，提高成功率
 * - 记录详细日志，便于排查问题
 * 
 * 参数：
 * @param string $url - 视频链接 (已清理后的纯净URL)
 * 
 * 返回值：
 * @return array - 解析结果
 *   - success: bool - 是否成功
 *   - data: array - 视频数据 (title, cover, url)
 *   - error: string - 错误信息
 *   - detail: string - 详细说明
 *   - errno: int - CURL错误码
 * 
 * 使用示例：
 * $result = callApi('https://v.douyin.com/xxx/');
 * if ($result['success']) {
 *     echo $result['data']['title'];
 * } else {
 *     echo $result['error'];
 * }
 * 
 * 性能优化：
 * - 强制TLS 1.2，提高SSL兼容性
 * - 模拟真实浏览器，避免被拒绝
 * - 连接复用，提高速度
 * - 重试延迟2秒，避免频繁请求
 */
function callApi($url) {
    $fullApiUrl = API_URL . urlencode($url);
    $maxRetries = 1;  // 优化: 只尝试1次,避免超时 // 最大重试次数（减少到2次，避免总时间过长）
    $retryDelay = 1; // 重试延迟(秒)
    
    if (!function_exists('curl_init')) {
        logError('CURL扩展未安装', ['url' => $url]);
        return ['success' => false, 'error' => 'CURL扩展未安装'];
    }
    
    // 记录开始时间
    $startTime = microtime(true);
    
    $lastError = '';
    $lastErrno = 0;
    
    // 重试循环
    for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            // 基本配置
            CURLOPT_URL => $fullApiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_TIMEOUT => 10,  // 优化: 减少到10秒
            CURLOPT_CONNECTTIMEOUT => 15,  // 增加连接超时时间
            
            // SSL配置 (增强兼容性)
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            // 移除TLS版本限制,让CURL自动协商最佳版本
            
            // HTTP头 (模拟真实浏览器)
            CURLOPT_HTTPHEADER => [
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept: application/json, text/plain, */*',
                'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
                'Accept-Encoding: gzip, deflate, br',
                'Connection: keep-alive',
                'Cache-Control: no-cache',
                'Pragma: no-cache',
            ],
            
            // 编码和连接复用
            CURLOPT_ENCODING => '',
            CURLOPT_FRESH_CONNECT => false,  // 允许复用连接
            CURLOPT_FORBID_REUSE => false,   // 允许连接复用
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        $errno = curl_errno($ch);
        $totalTime = curl_getinfo($ch, CURLINFO_TOTAL_TIME);
        curl_close($ch);
        
        // 尝试第 $attempt 次
        
        // 成功
        if ($errno === 0 && $httpCode === 200) {
            $elapsed = round((microtime(true) - $startTime) * 1000, 2);
            // API调用成功
            
            $data = json_decode($response, true);
            
            if (!$data) {
                logError('JSON解析失败', ['response' => substr($response, 0, 200)]);
                return ['success' => false, 'error' => 'JSON解析失败'];
            }
            
            // 检查API是否返回错误
            if (isset($data['msg']) && $data['msg'] !== '成功!') {
                // API返回了错误信息
                logError('API返回错误', [
                    'url' => $url,
                    'code' => $data['code'] ?? 'N/A',
                    'msg' => $data['msg'],
                    'content' => $data['content']
                ]);
                
                // 根据错误类型返回友好的提示
                $errorMsg = $data['msg'];
                if ($errorMsg === '短视频解析失败') {
                    $errorMsg = '视频解析失败，可能是视频已被删除、设为私密或链接格式不正确。请尝试其他视频链接。';
                }
                
                return [
                    'success' => false,
                    'error' => $errorMsg,
                    'code' => $data['code'] ?? 'unknown'
                ];
            }
            
            // 检查API响应格式
            // 注意：success字段可能是布尔值true、数字1、字符串"1"等，需要兼容处理
            if (isset($data['msg']) && $data['msg'] === '成功!' && 
                isset($data['content']) && !empty($data['content']['success'])) {
                
                // 验证必需字段
                if (empty($data['content']['url'])) {
                    logError('API返回数据不完整', ['data' => $data]);
                    return ['success' => false, 'error' => '视频地址为空'];
                }
                
                // 验证URL格式
                if (!filter_var($data['content']['url'], FILTER_VALIDATE_URL)) {
                    logError('视频地址格式无效', ['url' => $data['content']['url']]);
                    return ['success' => false, 'error' => '视频地址格式无效'];
                }
                
                return [
                    'success' => true,
                    'data' => [
                        'title' => $data['content']['title'] ?? '未知标题',
                        'cover' => $data['content']['cover'] ?? '',
                        'url' => $data['content']['url']
                    ]
                ];
            }
            
            // 记录详细的响应信息，便于调试
            logError('API响应格式错误', [
                'msg_isset' => isset($data['msg']),
                'msg_value' => $data['msg'] ?? 'N/A',
                'msg_match' => ($data['msg'] ?? '') === '成功!',
                'content_isset' => isset($data['content']),
                'success_isset' => isset($data['content']['success']),
                'success_value' => $data['content']['success'] ?? 'N/A',
                'success_type' => gettype($data['content']['success'] ?? null),
                'url_isset' => isset($data['content']['url']),
                'url_value' => isset($data['content']['url']) ? substr($data['content']['url'], 0, 50) . '...' : 'N/A'
            ]);
            
            // 返回更详细的错误信息
            $errorDetail = [];
            if (!isset($data['msg'])) {
                $errorDetail[] = '缺少msg字段';
            } elseif ($data['msg'] !== '成功!') {
                $errorDetail[] = "msg字段值为: {$data['msg']}";
            }
            if (!isset($data['content'])) {
                $errorDetail[] = '缺少content字段';
            } elseif (!isset($data['content']['success'])) {
                $errorDetail[] = '缺少content.success字段';
            } elseif (empty($data['content']['success'])) {
                $errorDetail[] = 'content.success为false或空';
                if (isset($data['content']['msg'])) {
                    $errorDetail[] = "API错误: {$data['content']['msg']}";
                }
            }
            
            $errorMsg = 'API响应格式错误';
            if (!empty($errorDetail)) {
                $errorMsg .= ': ' . implode(', ', $errorDetail);
            }
            
            return ['success' => false, 'error' => $errorMsg];
        }
        
        // 记录错误
        $lastError = $error;
        $lastErrno = $errno;
        
        // 如果不是最后一次尝试,等待后重试
        if ($attempt < $maxRetries) {
            // 等待后重试
            sleep($retryDelay);
        }
    }
    
    // 所有重试都失败
    $elapsed = round((microtime(true) - $startTime) * 1000, 2);
    logError('API调用失败(已重试3次)', [
        'url' => $url,
        'errno' => $lastErrno,
        'error' => $lastError,
        'time' => $elapsed . 'ms'
    ]);
    
    // 返回详细的错误信息
    if ($lastErrno === 35 || strpos($lastError, 'SSL') !== false) {
        return [
            'success' => false, 
            'error' => '网络请求失败：SSL连接错误',
            'detail' => '服务器无法访问API服务，请联系管理员检查服务器网络配置。您可以在后台“API测试”中查看详细诊断信息。',
            'errno' => $lastErrno
        ];
    } elseif ($lastErrno === 28) {
        return [
            'success' => false, 
            'error' => '网络请求超时',
            'detail' => 'API响应超时，请稍后重试。',
            'errno' => $lastErrno
        ];
    } elseif ($lastErrno === 6 || $lastErrno === 7) {
        return [
            'success' => false, 
            'error' => '网络连接失败',
            'detail' => '无法连接到API服务器，请检查网络连接。',
            'errno' => $lastErrno
        ];
    } else {
        return ['success' => false, 'error' => 'API调用失败: ' . $lastError];
    }
}

// 前面的callApi函数保持不变，这里只替换parseVideo部分

/**
 * 检查并关联用户与视频
 * 
 * @param PDO $pdo 数据库连接
 * @param int $userId 用户ID
 * @param int $videoId 视频ID
 * @return array 包含is_author, has_author, author_message, is_favorited
 */
function checkUserVideoRelation($pdo, $userId, $videoId) {
    $relation = [
        'is_author' => false,
        'has_author' => false,
        'author_message' => '',
        'is_favorited' => false
    ];
    
    try {
        // 检查是否已经有作者
        $stmt = $pdo->prepare("SELECT user_id FROM user_videos WHERE video_id = ?");
        $stmt->execute([$videoId]);
        $existingAuthor = $stmt->fetch();
        
        if (!$existingAuthor) {
            // 没有作者（被删除后的无主状态），绑定当前用户
            $stmt = $pdo->prepare("INSERT INTO user_videos (user_id, video_id, created_at) VALUES (?, ?, NOW())");
            $stmt->execute([$userId, $videoId]);
            $relation['is_author'] = true;
            $relation['author_message'] = '恭喜！您成为了此视频的作者';
        } elseif ($existingAuthor['user_id'] == $userId) {
            // 当前用户就是作者
            $relation['is_author'] = true;
            $relation['author_message'] = '这是您的视频';
        } else {
            // 已有其他作者
            $relation['is_author'] = false;
            $relation['has_author'] = true;
            $relation['author_message'] = '此链接已被人绑定！喜欢请收藏呦~';
        }
        
        // 检查是否已收藏
        $stmt = $pdo->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND video_id = ?");
        $stmt->execute([$userId, $videoId]);
        $relation['is_favorited'] = (bool)$stmt->fetch();
        
    } catch (Exception $e) {
        error_log('User video relation check failed: ' . $e->getMessage());
    }
    
    return $relation;
}

/**
 * 解析视频(核心逻辑) - 优化版
 * 
 * 优化点：
 * 1. 消除session_start()重复调用
 * 2. 统一数据库连接获取
 * 3. 提取用户关联检查为独立函数
 * 4. 添加input_url字段
 * 5. 统一收藏状态检查
 * 
 * @param string $url 视频URL
 * @return array 解析结果
 */
function parseVideo($url) {
    // ========== 全局开关:控制URL过滤功能 ==========
    // true = 启用过滤(匹配的链接不缓存数据库)
    // false = 禁用过滤(所有链接都正常缓存)
    $ENABLE_URL_FILTER = false;
    // ==============================================
    
    // 确保session已启动（只启动一次）
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // 获取用户ID
    $userId = $_SESSION['user_id'] ?? null;
    
    // 判断是否匹配过滤规则
    $isFilteredUrl = false;
    
    if ($ENABLE_URL_FILTER) {
        $isFilteredUrl = 
            // 1. 抖音
            preg_match('/https?:\/\/v\.douyin\.com\/[a-zA-Z0-9\-_]+\/?/', $url) ||
            preg_match('/https?:\/\/www\.douyin\.com\/video\/\d+/', $url) ||
            
            // 2. 快手
            preg_match('/https?:\/\/v\.kuaishou\.com\/[a-zA-Z0-9]+/', $url) ||
            preg_match('/https?:\/\/www\.kuaishou\.com\/short-video\/\d+/', $url) ||
            preg_match('/https?:\/\/www\.kuaishou\.com\/video\/\d+/', $url) ||
            
            // 3. 小红书
            preg_match('/https?:\/\/xhslink\.com\/[a-zA-Z0-9]+/', $url) ||
            preg_match('/https?:\/\/www\.xiaohongshu\.com\/[a-zA-Z0-9\/]+/', $url) ||
            
            // 4. B站(哔哩哔哩)
            preg_match('/https?:\/\/b23\.tv\/[a-zA-Z0-9]+/', $url) ||
            preg_match('/https?:\/\/www\.bilibili\.com\/video\/[a-zA-Z0-9]+/', $url) ||
            preg_match('/https?:\/\/(?:www\.)?bilibili\.com\/video\/[a-zA-Z0-9]+/', $url) ||
            
            // 5. 微博
            preg_match('/https?:\/\/weibo\.com\/tv\/show\/\d+/', $url) ||
            preg_match('/https?:\/\/(?:www\.)?weibo\.com\/\d+\/[a-zA-Z0-9]+/', $url) ||
            preg_match('/https?:\/\/m\.weibo\.cn\/status\/\d+/', $url) ||
            
            // 6. 西瓜视频
            preg_match('/https?:\/\/(?:www\.)?ixigua\.com\/\d+/', $url) ||
            preg_match('/https?:\/\/v\.ixigua\.com\/[a-zA-Z0-9]+/', $url) ||
            
            // 7. 微视
            preg_match('/https?:\/\/(?:www\.)?weishi\.qq\.com\/[a-zA-Z0-9\/]+/', $url) ||
            preg_match('/https?:\/\/h5\.weishi\.qq\.com\/weishi\/feed\/[a-zA-Z0-9]+/', $url) ||
            
            // 8. 皮皮虾
            preg_match('/https?:\/\/h5\.pipix\.com\/s\/[a-zA-Z0-9]+/', $url) ||
            preg_match('/https?:\/\/(?:www\.)?pipix\.com\/[a-zA-Z0-9\/]+/', $url) ||
            
            // 9. 网易云音乐
            preg_match('/https?:\/\/music\.163\.com\/song\/?\?id=\d+/', $url) ||
            preg_match('/https?:\/\/music\.163\.com\/#\/song\?id=\d+/', $url) ||
            preg_match('/https?:\/\/y\.music\.163\.com\/m\/song\/?\?id=\d+/', $url) ||
            
            // 10. 知乎
            preg_match('/https?:\/\/(?:www\.)?zhihu\.com\/question\/\d+\/answer\/\d+/', $url) ||
            preg_match('/https?:\/\/zhuanlan\.zhihu\.com\/p\/\d+/', $url) ||
            preg_match('/https?:\/\/(?:www\.)?zhihu\.com\/zvideo\/\d+/', $url);
    }
    
    // 如果匹配过滤规则,直接调用API,不缓存数据库,不生成ID
    if ($isFilteredUrl) {
        // 直接调用API
        $result = callApi($url);
        
        if (!$result['success']) {
            return $result;
        }
        
        // 返回结果,不包含ID和views字段
        return [
            'success' => true,
            'from_db' => false,
            'data' => [
                'title' => $result['data']['title'],
                'cover' => $result['data']['cover'],
                'url' => $result['data']['url'],
                'input_url' => $url // 添加原始URL
            ]
        ];
    }
    
    // 未匹配过滤规则,走原有逻辑
    // 1. 获取数据库实例和连接
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    // 2. 查询数据库
    $existing = $db->getVideoByUrl($url);
    
    if ($existing) {
        // 数据库命中
        $db->incrementViews($existing['id']);
        
        $result = [
            'success' => true,
            'from_db' => true,
            'data' => [
                'id' => $existing['id'],
                'title' => $existing['title'],
                'cover' => $existing['cover'],
                'url' => $existing['url'],
                'input_url' => $existing['input_url'], // 添加原始URL
                'views' => $existing['views'] + 1
            ]
        ];
        
        // 检查用户关联（如果已登录）
        if ($userId) {
            $relation = checkUserVideoRelation($pdo, $userId, $existing['id']);
            $result['data'] = array_merge($result['data'], $relation);
        }
        
        return $result;
    }
    
    // 3. 调用API
    $result = callApi($url);
    
    if (!$result['success']) {
        return $result;
    }
    
    // 4. 保存到数据库
    $id = $db->saveVideo(
        $url,
        $result['data']['title'],
        $result['data']['cover'],
        $result['data']['url']
    );
    
    // 5. 构建返回结果
    $result['data']['id'] = $id;
    $result['data']['input_url'] = $url; // 添加原始URL
    $result['data']['views'] = 1;
    $result['from_db'] = false;
    
    // 6. 关联用户（如果已登录）
    if ($userId) {
        $relation = checkUserVideoRelation($pdo, $userId, $id);
        $result['data'] = array_merge($result['data'], $relation);
    }
    
    return $result;
}


/**
 * 返回JSON响应
 */
function jsonResponse($code, $message, $data = null) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'code' => $code,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * 检查PHP环境
 */
function checkEnvironment() {
    $checks = [];
    
    // PHP版本
    $checks['php_version'] = [
        'name' => 'PHP版本',
        'required' => '7.2+',
        'current' => PHP_VERSION,
        'status' => version_compare(PHP_VERSION, '7.2.0', '>=')
    ];
    
    // CURL扩展
    $checks['curl'] = [
        'name' => 'CURL扩展',
        'required' => '必须',
        'current' => function_exists('curl_init') ? '已安装' : '未安装',
        'status' => function_exists('curl_init')
    ];
    
    // PDO扩展
    $checks['pdo'] = [
        'name' => 'PDO扩展',
        'required' => '必须',
        'current' => extension_loaded('pdo') ? '已安装' : '未安装',
        'status' => extension_loaded('pdo')
    ];
    
    // PDO MySQL
    $checks['pdo_mysql'] = [
        'name' => 'PDO MySQL',
        'required' => '必须',
        'current' => extension_loaded('pdo_mysql') ? '已安装' : '未安装',
        'status' => extension_loaded('pdo_mysql')
    ];
    
    // JSON扩展
    $checks['json'] = [
        'name' => 'JSON扩展',
        'required' => '必须',
        'current' => function_exists('json_encode') ? '已安装' : '未安装',
        'status' => function_exists('json_encode')
    ];
    
    // 目录权限
    $dataDir = __DIR__ . '/data';
    if (!is_dir($dataDir)) {
        @mkdir($dataDir, 0777, true);
    }
    $checks['data_writable'] = [
        'name' => 'data目录可写',
        'required' => '必须',
        'current' => is_writable($dataDir) ? '可写' : '不可写',
        'status' => is_writable($dataDir)
    ];
    
    return $checks;
}

/**
 * 输出HTML头部
 */
function htmlHeader($title, $includeAssets = true, $extraCss = []) {
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($title); ?> - <?php echo APP_NAME; ?></title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <?php if ($includeAssets): ?>
        <link href="/assets/style.css" rel="stylesheet">
        <?php foreach ($extraCss as $css): ?>
        <link href="/assets/<?php echo $css; ?>.css" rel="stylesheet">
        <?php endforeach; ?>
        <?php endif; ?>
        <meta name="referrer" content="no-referrer">
        <?php if (function_exists('generateCsrfToken')): ?>
        <meta name="csrf-token" content="<?php echo generateCsrfToken(); ?>">
        <?php endif; ?>
    </head>
    <body>
    <div class="container">
    <?php
}

/**
 * 输出HTML导航
 */
function htmlNav($currentPage = '') {
    // 获取当前用户信息
    $isLoggedIn = isset($_SESSION['user_id']);
    $username = $_SESSION['username'] ?? '';
    ?>
    <div class="nav">
        <a href="/" class="btn <?php echo $currentPage === 'index' ? 'btn-primary' : 'btn-secondary'; ?>">
            <i class="fas fa-home"></i> 视频解析
        </a>
        <a href="/random.php" class="btn <?php echo $currentPage === 'random' ? 'btn-primary' : 'btn-secondary'; ?>">
            <i class="fas fa-random"></i> 探索视频
        </a>
        <?php if ($isLoggedIn): ?>
        <a href="/user/" class="btn <?php echo $currentPage === 'user' ? 'btn-primary' : 'btn-secondary'; ?>">
            <i class="fas fa-user"></i> <?php echo htmlspecialchars($username); ?>
        </a>
        <?php else: ?>
        <a href="/user/login.php" class="btn <?php echo $currentPage === 'login' ? 'btn-primary' : 'btn-secondary'; ?>">
            <i class="fas fa-user"></i> 用户中心
        </a>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * 输出HTML尾部
 */
function htmlFooter($includeAssets = true) {
    ?>
    
    <div class="footer">
        <footer class="site-footer">
            <div class="footer-bottom">
                <p>本站仅供视频链接解析服务，不存储任何视频文件 | 请合法合规使用</p>
            </div>
        </footer>
    </div><!-- .footer -->
    
    </div><!-- .container -->
    
    <?php if ($includeAssets): ?>
    <script src="/assets/script.js"></script>
    <script src="/assets/app.js"></script>
    <?php endif; ?>
    </body>
    </html>
    <?php
}



/**
 * 记录信息日志
 */
function logInfo($message, $context = []) {
    if (!APP_DEBUG && !defined('ENABLE_API_LOG')) {
        return; // 生产环境不记录INFO日志
    }
    
    $logFile = __DIR__ . '/data/api.log';
    $timestamp = date('Y-m-d H:i:s');
    $contextStr = !empty($context) ? json_encode($context, JSON_UNESCAPED_UNICODE) : '';
    $logMessage = "[$timestamp] [INFO] $message";
    
    if ($contextStr) {
        $logMessage .= " | Context: $contextStr";
    }
    
    $logMessage .= PHP_EOL;
    
    @file_put_contents($logFile, $logMessage, FILE_APPEND);
}

/**
 * 记录错误日志
 */
function logError($message, $context = []) {
    $logFile = __DIR__ . '/data/error.log';
    $timestamp = date('Y-m-d H:i:s');
    $contextStr = !empty($context) ? json_encode($context, JSON_UNESCAPED_UNICODE) : '';
    $logMessage = "[$timestamp] [ERROR] $message";
    
    if ($contextStr) {
        $logMessage .= " | Context: $contextStr";
    }
    
    // 添加堆栈信息
    $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 3);
    if (isset($backtrace[1])) {
        $caller = $backtrace[1];
        $file = basename($caller['file'] ?? 'unknown');
        $line = $caller['line'] ?? 0;
        $logMessage .= " | Called from: $file:$line";
    }
    
    $logMessage .= PHP_EOL;
    
    @file_put_contents($logFile, $logMessage, FILE_APPEND);
    
    // 同时记录到PHP错误日志
    error_log("[$timestamp] $message");
}

/**
 * 清理旧日志文件
 */
function cleanOldLogs($days = 7) {
    $logFiles = [
        __DIR__ . '/data/api.log',
        __DIR__ . '/data/error.log'
    ];
    
    foreach ($logFiles as $logFile) {
        if (file_exists($logFile)) {
            $fileTime = filemtime($logFile);
            $daysDiff = (time() - $fileTime) / 86400;
            
            if ($daysDiff > $days) {
                @unlink($logFile);
            }
        }
    }
}



/**
 * 清理视频URL,提取纯净链接
 * 
 * 从用户输入中提取纯净的视频URL,去除分享文本中的额外内容
 * 
 * @param string $input 用户输入的文本
 * @return string 清理后的URL
 */
function cleanVideoUrl($input) {
    // 移除首尾空白
    $input = trim($input);
    
    // 定义视频平台URL模式
    $patterns = [
        // 抖音短链接（支持更多字符）
        '/https?:\/\/v\.douyin\.com\/[a-zA-Z0-9\-_]+\/?/',
        // 抖音长链接
        '/https?:\/\/www\.douyin\.com\/video\/\d+/',
        // 快手短链接
        '/https?:\/\/v\.kuaishou\.com\/[a-zA-Z0-9]+/',
        // 快手长链接
        '/https?:\/\/www\.kuaishou\.com\/short-video\/\d+/',
        // B站短链接
        '/https?:\/\/b23\.tv\/[a-zA-Z0-9]+/',
        // B站视频链接
        '/https?:\/\/www\.bilibili\.com\/video\/[a-zA-Z0-9]+/',
        '/https?:\/\/(?:www\.)?bilibili\.com\/video\/[a-zA-Z0-9]+/',
        // 小红书
        '/https?:\/\/xhslink\.com\/[a-zA-Z0-9]+/',
        '/https?:\/\/www\.xiaohongshu\.com\/[a-zA-Z0-9\/]+/',
        // 微博
        '/https?:\/\/weibo\.com\/tv\/show\/\d+/',
        '/https?:\/\/(?:www\.)?weibo\.com\/\d+\/[a-zA-Z0-9]+/',
        // X/Twitter
        '/https?:\/\/(?:x|twitter)\.com\/[a-zA-Z0-9_]+\/status\/\d+/',
        // 皮皮虾
        '/https?:\/\/h5\.pipix\.com\/s\/[a-zA-Z0-9]+/',
        '/https?:\/\/(?:www\.)?pipix\.com\/[a-zA-Z0-9\/]+/',
        // 皮皮搞笑
        '/https?:\/\/(?:www\.)?ippzone\.com\/[a-zA-Z0-9\/]+/',
        // 西瓜视频
        '/https?:\/\/(?:www\.)?ixigua\.com\/\d+/',
        // 火山小视频
        '/https?:\/\/(?:www\.)?huoshan\.com\/[a-zA-Z0-9\/]+/',
        // 微视
        '/https?:\/\/(?:www\.)?weishi\.qq\.com\/[a-zA-Z0-9\/]+/',
        // 最右
        '/https?:\/\/(?:www\.)?zuiyou\.com\/[a-zA-Z0-9\/]+/',
        // 快视频
        '/https?:\/\/(?:www\.)?kuaikanvideo\.com\/[a-zA-Z0-9\/]+/',
        // 通用HTTP(S)链接 (最后匹配)
        '/https?:\/\/[^\s]+/'
    ];
    
    // 尝试匹配每个模式
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $input, $matches)) {
            $cleanUrl = $matches[0];
            
            // 移除末尾可能的标点符号和空格
            $cleanUrl = rtrim($cleanUrl, '.,;:!?。，；：！？ \t\n\r');
            
            // 移除URL中的emoji和特殊字符（保留基本URL字符）
            $cleanUrl = preg_replace('/[^\x00-\x7F]+/', '', $cleanUrl);
            
            // 特别处理：抖音短链接必须以斜杠结尾
            if (preg_match('/^https?:\/\/v\.douyin\.com\/[a-zA-Z0-9\-_]+$/', $cleanUrl)) {
                $cleanUrl .= '/';
            }
            
            return $cleanUrl;
        }
    }
    
    // 没有匹配到任何模式，返回原始输入
    return $input;
}

/**
 * 验证URL格式
 * 
 * @param string $url URL地址
 * @return bool 是否有效
 */
function isValidVideoUrl($url) {
    // 基本URL格式验证
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    
    // 必须是HTTP或HTTPS协议
    $scheme = parse_url($url, PHP_URL_SCHEME);
    if (!in_array($scheme, ['http', 'https'])) {
        return false;
    }
    
    // 必须有域名
    $host = parse_url($url, PHP_URL_HOST);
    if (empty($host)) {
        return false;
    }
    
    return true;
}

