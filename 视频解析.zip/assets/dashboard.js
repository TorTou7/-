/**
 * 用户中心 - 标签页式布局脚本
 */

// 标签页切换
document.addEventListener('DOMContentLoaded', function() {
    const tabBtns = document.querySelectorAll('.tab-btn:not(.logout-btn)');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.dataset.tab;
            
            // 移除所有active类
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            
            // 添加active类
            this.classList.add('active');
            document.getElementById('tab-' + tabId).classList.add('active');
        });
    });
});

// Toast提示函数
function showToast(message, type = 'info') {
    // 移除已存在的toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // 创建toast元素
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    // 图标映射
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    };
    
    toast.innerHTML = `
        <i class="fas ${icons[type]} toast-icon"></i>
        <span class="toast-message">${message}</span>
    `;
    
    document.body.appendChild(toast);
    
    // 3秒后自动消失
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// 复制文本到剪贴板
function copyText(text, successMsg = '复制成功') {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
            showToast(successMsg, 'success');
        }).catch(() => {
            fallbackCopy(text, successMsg);
        });
    } else {
        fallbackCopy(text, successMsg);
    }
}

// 降级复制方案
function fallbackCopy(text, successMsg) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    
    try {
        document.execCommand('copy');
        showToast(successMsg, 'success');
    } catch (err) {
        showToast('复制失败，请手动复制', 'error');
    }
    
    document.body.removeChild(textarea);
}

// 下载视频
function downloadVid(url, title = 'video') {
    const a = document.createElement('a');
    a.href = url;
    a.download = title + '.mp4';
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast('开始下载...', 'success');
}

// 删除视频（解除关联）
function delVideo(videoId) {
    if (!confirm('确定要删除此视频吗？删除后视频将变为无主状态。')) {
        return;
    }
    
    fetch('/user/video_action.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=delete&video_id=${videoId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('删除成功', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message || '删除失败', 'error');
        }
    })
    .catch(() => {
        showToast('网络错误', 'error');
    });
}

// 取消收藏
function unfavVideo(videoId) {
    fetch('/user/video_action.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=unfavorite&video_id=${videoId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('已取消收藏', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message || '操作失败', 'error');
        }
    })
    .catch(() => {
        showToast('网络错误', 'error');
    });
}

// 收藏视频
function favVideo(videoId) {
    fetch('/user/video_action.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=favorite&video_id=${videoId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('收藏成功', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message || '操作失败', 'error');
        }
    })
    .catch(() => {
        showToast('网络错误', 'error');
    });
}

// 账号设置表单切换
function toggleSettingForm(formId) {
    const form = document.getElementById(formId);
    if (form) {
        form.classList.toggle('active');
    }
}

// 修改邮箱
function updateEmail(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    fetch('/user/auth.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('邮箱修改成功', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message || '修改失败', 'error');
        }
    })
    .catch(() => {
        showToast('网络错误', 'error');
    });
}

// 修改密码
function updatePassword(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    // 验证新密码
    const newPassword = formData.get('new_password');
    const confirmPassword = formData.get('confirm_password');
    
    if (newPassword !== confirmPassword) {
        showToast('两次输入的密码不一致', 'error');
        return;
    }
    
    if (newPassword.length < 6) {
        showToast('密码长度至少6位', 'error');
        return;
    }
    
    fetch('/user/auth.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('密码修改成功', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message || '修改失败', 'error');
        }
    })
    .catch(() => {
        showToast('网络错误', 'error');
    });
}

// slideOut动画
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

