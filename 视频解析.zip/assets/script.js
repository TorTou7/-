/**
 * 公共脚本文件
 * 所有页面共用
 */

// 黑暗模式管理
const ThemeManager = {
    init() {
        // 从localStorage读取主题设置
        const savedTheme = localStorage.getItem('theme') || 'light';
        this.setTheme(savedTheme);
        
        // 创建切换按钮
        this.createToggleButton();
    },
    
    createToggleButton() {
        const button = document.createElement('button');
        button.className = 'theme-toggle';
        button.innerHTML = '<i class="fas fa-moon"></i>';
        button.setAttribute('aria-label', '切换主题');
        button.onclick = () => this.toggle();
        document.body.appendChild(button);
        
        this.updateButtonIcon();
    },
    
    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        this.currentTheme = theme;
        this.updateButtonIcon();
    },
    
    toggle() {
        const newTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        this.setTheme(newTheme);
    },
    
    updateButtonIcon() {
        const button = document.querySelector('.theme-toggle');
        if (button) {
            button.innerHTML = this.currentTheme === 'light' 
                ? '<i class="fas fa-moon"></i>' 
                : '<i class="fas fa-sun"></i>';
        }
    }
};

// 页面加载完成后初始化主题
document.addEventListener('DOMContentLoaded', function() {
    ThemeManager.init();
});

/**
 * HTML转义函数
 */
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

/**
 * 属性转义函数
 */
function escapeAttr(text) {
    return text.replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

/**
 * 显示状态消息
 */
function showStatus(message, type = 'info') {
    const statusDiv = document.getElementById('statusMessage');
    if (!statusDiv) return;
    
    statusDiv.className = 'status-message show ' + type;
    statusDiv.textContent = message;
}

/**
 * 隐藏状态消息
 */
function hideStatus() {
    const statusDiv = document.getElementById('statusMessage');
    if (!statusDiv) return;
    
    statusDiv.className = 'status-message';
}

/**
 * 显示加载状态
 */
function showLoading(element) {
    element.innerHTML = `
        <div class="loading">
            <i class="fas fa-spinner fa-spin"></i>
            <p>加载中...</p>
        </div>
    `;
}

/**
 * 显示空状态
 */
function showEmpty(element, message = '暂无数据') {
    element.innerHTML = `
        <div class="empty-state">
            <i class="fas fa-inbox"></i>
            <p>${escapeHtml(message)}</p>
        </div>
    `;
}

/**
 * 复制到剪贴板
 */
function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
            showToast('✓ 已复制到剪贴板');
        }).catch(() => {
            fallbackCopy(text);
        });
    } else {
        fallbackCopy(text);
    }
}

/**
 * 备用复制方法
 */
function fallbackCopy(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    
    try {
        document.execCommand('copy');
        showToast('✓ 已复制到剪贴板');
    } catch (err) {
        showToast('✗ 复制失败');
    }
    
    document.body.removeChild(textarea);
}

/**
 * 显示Toast提示
 */
function showToast(message, duration = 2000) {
    // 移除已存在的toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // 创建toast元素
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        top: 80px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        z-index: 10000;
        animation: fadeIn 0.3s ease;
    `;
    
    document.body.appendChild(toast);
    
    // 自动移除
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// 添加CSS动画
if (!document.getElementById('toast-animations')) {
    const style = document.createElement('style');
    style.id = 'toast-animations';
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; transform: translateX(-50%) translateY(-10px); }
            to { opacity: 1; transform: translateX(-50%) translateY(0); }
        }
        @keyframes fadeOut {
            from { opacity: 1; transform: translateX(-50%) translateY(0); }
            to { opacity: 0; transform: translateX(-50%) translateY(-10px); }
        }
    `;
    document.head.appendChild(style);
}

/**
 * 在新窗口打开预览
 */
function openPreview(url) {
    window.open(url, '_blank');
}



/**
 * 页面加载动画管理器
 */
const PageLoader = {
    loader: null,
    
    /**
     * 初始化加载器
     */
    init() {
        // 创建加载器元素
        this.loader = document.createElement('div');
        this.loader.className = 'page-loader';
        this.loader.innerHTML = `
            <div class="loader-content">
                <div class="ink-loader"></div>
                <div class="loader-text">Loading...</div>
            </div>
        `;
        document.body.appendChild(this.loader);
        
        // 页面加载完成后隐藏
        window.addEventListener('load', () => {
            this.hide();
        });
        
        // 为所有导航链接添加加载效果
        this.attachLinkListeners();
    },
    
    /**
     * 显示加载器
     */
    show() {
        if (this.loader) {
            this.loader.classList.remove('hidden');
        }
    },
    
    /**
     * 隐藏加载器
     */
    hide() {
        if (this.loader) {
            setTimeout(() => {
                this.loader.classList.add('hidden');
            }, 300);
        }
    },
    
    /**
     * 为链接添加加载监听
     */
    attachLinkListeners() {
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a');
            if (link && link.href && !link.target && !link.hasAttribute('data-no-loader')) {
                // 排除外部链接和特殊链接
                const url = new URL(link.href);
                if (url.origin === window.location.origin) {
                    link.classList.add('loading');
                    this.show();
                }
            }
        });
    }
};

// 页面开始加载时立即显示加载器 - 已禁用
// if (document.readyState === 'loading') {
//     PageLoader.init();
// } else {
//     // 如果脚本加载较晚，直接隐藏加载器
//     document.addEventListener('DOMContentLoaded', () => {
//         PageLoader.init();
//         PageLoader.hide();
//     });
// }

/**
 * 页面切换动画
 */
function applyPageTransition() {
    const container = document.querySelector('.container');
    if (container) {
        container.classList.add('page-transition');
    }
}

// 应用页面切换动画
document.addEventListener('DOMContentLoaded', applyPageTransition);

