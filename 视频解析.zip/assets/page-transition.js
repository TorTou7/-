/**
 * 页面切换过渡效果
 * 只在content区域显示加载动画,不影响导航栏
 */

(function() {
    'use strict';
    
    // 在导航链接点击时添加加载效果
    document.addEventListener('DOMContentLoaded', function() {
        // 获取所有导航链接
        const navLinks = document.querySelectorAll('.nav a');
        
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                // 如果是当前页面,不处理
                if (this.classList.contains('btn-primary')) {
                    e.preventDefault();
                    return;
                }
                
                // 显示content区域的加载动画
                const content = document.querySelector('.content');
                if (content) {
                    // 添加加载状态
                    content.style.opacity = '0.5';
                    content.style.pointerEvents = 'none';
                    
                    // 创建加载动画
                    const loadingDiv = document.createElement('div');
                    loadingDiv.className = 'content-loading';
                    loadingDiv.innerHTML = `
                        <div class="ink-loader"></div>
                        <div class="loader-text">加载中...</div>
                    `;
                    content.appendChild(loadingDiv);
                }
                
                // 让浏览器正常跳转
                // 不需要e.preventDefault()
            });
        });
    });
    
    // 页面加载完成后移除加载状态
    window.addEventListener('load', function() {
        const content = document.querySelector('.content');
        if (content) {
            content.style.opacity = '1';
            content.style.pointerEvents = 'auto';
            
            const loading = content.querySelector('.content-loading');
            if (loading) {
                loading.remove();
            }
        }
    });
})();

